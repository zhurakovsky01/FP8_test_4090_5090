// v2 of the bit-exact B200 (Pearl Device = 1) emulation math. Shared by the CUDA kernel
// (emu.cu: prep2 / emu2_*), the CPU check (cpu_check2.cpp) and the fake driver (fake_emu.cpp).
// Author: alex_kodiaq (with Claude).
//
// What changed against v1 (emu_math.cuh, kept unchanged and still used by the v1 kernel):
//  * Limbs are relative to the group: every value of a (row, 32-group) is r * 2^(s-1) (units 2^-9),
//    s = smallest stored exponent E' of the group, so |r| < 2^(4 + span). r is split in two's
//    complement into 8-bit limbs (low limbs u8, top limb s8). Per 16-row block of A and per 8-column
//    block of B the limb count L = 2 or 3 (2 covers span <= 11). On PIP-3 inputs ~98% of the blocks
//    need 2 limbs: 4 IMMA per tile instead of 9. The per-row scale 2^(sA+sB-2) is applied after the
//    tensor cores, exactly (shift of the exact integer dot product).
//  * Path P1 (carry is the anchor) uses a cheap exact pre-test (small-code masks, see cand_maybe)
//    before touching the 16-entry candidate masks.
//  * Path P2 replaces the per-term exact loop: the anchor (largest product exponent) is found with
//    byte-SIMD over biased exponents, and only the products that really lose bits are visited.
//    P2 is the exact B200 group algorithm, so no other fallback is needed.
#pragma once
#ifndef __CUDACC_RTC__
#include <stddef.h>
#endif
#include "emu_math.cuh"

// ---- per (row, group) record (uint64) -------------------------------------------------------
//  bits  0..31 small mask: bit u set when code u is non-zero and E'_u < maxE - 4
//  bits 32..35 maxE (0: all-zero group)   bits 36..39 minE
//  bits 40..43 bigE = min E' over non-zero codes not in the small set
//  bits 44..47 s = limb scale exponent (= minE, 1 for an all-zero group)
HD int rec_max(uint64_t r) { return (int)(r >> 32) & 15; }
HD int rec_min(uint64_t r) { return (int)(r >> 36) & 15; }
HD int rec_big(uint64_t r) { return (int)(r >> 40) & 15; }
HD int rec_s(uint64_t r) { return (int)(r >> 44) & 15; }
HD uint32_t rec_small(uint64_t r) { return (uint32_t)r; }

HD uint64_t make_rec(const uint8_t* codes) {
    int hi = 0, lo = 16;
    for (int u = 0; u < 32; ++u)
        if (code_m(codes[u])) { int E = code_E(codes[u]); hi = E > hi ? E : hi; lo = E < lo ? E : lo; }
    if (!hi) return (uint64_t)1 << 44;
    uint32_t small = 0;
    int big = 15;
    for (int u = 0; u < 32; ++u)
        if (code_m(codes[u])) {
            int E = code_E(codes[u]);
            if (E < hi - 4) small |= 1u << u; else big = E < big ? E : big;
        }
    return (uint64_t)small | ((uint64_t)hi << 32) | ((uint64_t)lo << 36) | ((uint64_t)big << 40) | ((uint64_t)lo << 44);
}

// relative integer of code u: value = r * 2^(s-1) in units 2^-9
HD int rel_r(uint8_t c, int s) {
    if (!code_m(c)) return 0;
    int v = code_m(c) << (code_E(c) - s);
    return (c & 0x80) ? -v : v;
}
// limbs needed for one row-group: 2 if every r fits in 16-bit two's complement, else 3
HD int rel_limbs(const uint8_t* codes, int s) {
    for (int u = 0; u < 32; ++u) { int r = rel_r(codes[u], s); if (r > 32767 || r < -32768) return 3; }
    return 2;
}
// limb p of r for a block with L limbs (two's complement; low limbs unsigned, top limb signed)
HD int8_t rel_limb(int r, int p, int L) {
    if (p >= L) return 0;
    if (p == L - 1) return (int8_t)(r >> (8 * p));            // arithmetic shift: signed top limb
    return (int8_t)(uint8_t)((r >> (8 * p)) & 255);           // stored as a byte, read back as u8
}
// value of a stored limb byte as the tensor core reads it
HD int limb_val(int8_t byte, int p, int L) { return p == L - 1 ? (int)byte : (int)(uint8_t)byte; }

// biased stored exponents for byte-SIMD: E'+16 for non-zero codes, 0 for zeros
HD uint8_t code_eb(uint8_t c) { return code_m(c) ? (uint8_t)(code_E(c) + 16) : (uint8_t)0; }

// ---- candidates: products that can lose bits (E'a + E'b < thr) ----------------------------
// Exact superset test from the two records only (no memory access).
HD bool cand_maybe(uint64_t ra, uint64_t rb, int thr) {
    const int mnA = rec_min(ra), mnB = rec_min(rb);
    if (mnA + mnB >= thr) return false;
    const int bgA = rec_big(ra), bgB = rec_big(rb);
    if (bgA + bgB < thr) return true;
    const uint32_t sa = rec_small(ra), sb = rec_small(rb);
    if (sa & sb) return true;                                 // mnA + mnB < thr already holds
    if ((sa & ~sb) && mnA + bgB < thr) return true;
    if ((sb & ~sa) && bgA + mnB < thr) return true;
    return false;
}

// Sum (units 2^-18) of what B200 drops from every product with E'a + E'b < thr when the grid is
// 2^gu (units 2^-18, gu = thr - 2 > 0). Candidates come from the le-masks (v1 layout).
HD int64_t cand_correction(const uint8_t* a, const uint8_t* b, uint64_t ra, uint64_t rb,
                           const uint32_t* ma16, const uint32_t* mb16, int thr) {
    const int gu = thr - 2;
    if (gu <= 0) return 0;
    int ta = thr - 1 - rec_min(rb), tb = thr - 1 - rec_min(ra);
    uint32_t cand = ma16[ta > 15 ? 15 : ta] & mb16[tb > 15 ? 15 : tb];
    const uint64_t gmask = gu >= 63 ? ~(uint64_t)0 : (((uint64_t)1 << gu) - 1);
    int64_t corr = 0;
    while (cand) {
#ifdef __CUDA_ARCH__
        int u = __ffs((int)cand) - 1;
#else
        int u = __builtin_ctz(cand);
#endif
        cand &= cand - 1;
        const uint8_t ca = a[u], cb = b[u];
        if (code_E(ca) + code_E(cb) >= thr) continue;
        int64_t p = (int64_t)(code_m(ca) << (code_E(ca) - 1)) * (int64_t)(code_m(cb) << (code_E(cb) - 1));
        int64_t r = (int64_t)((uint64_t)p & gmask);
        corr += ((ca ^ cb) & 0x80) ? -r : r;
    }
    return corr;
}

// RZ_fp32(carry + T * 2^-18) for a normal carry; false if the result would be subnormal.
HD bool rz_add(int64_t T, float carry, float* out) {
    const uint32_t bits = emu_f2u(carry);
    if (T == 0) { *out = carry; return true; }
    const int ef = (bits >> 23) & 0xFF;
    int64_t sig = 0x800000 | (bits & 0x7FFFFF);
    const int ulp = ef - 150;                                 // carry = sig * 2^ulp
    const int q = ulp < -18 ? ulp : -18;
    if (bits >> 31) sig = -sig;
    const int64_t S = sig * ((int64_t)1 << (ulp - q)) + T * ((int64_t)1 << (-18 - q));
    if (S == 0) { *out = 0.0f; return true; }
    const uint32_t sign = S < 0 ? 0x80000000u : 0u;
    uint64_t u = (uint64_t)(S < 0 ? -S : S);
    const int nb = 64 - emu_clz64(u);
    const int e = q + nb - 1;
    if (e < -126 || e > 127) return false;
    if (nb > 24) u >>= (nb - 24); else u <<= (24 - nb);
    *out = emu_u2f(sign | ((uint32_t)(e + 127) << 23) | ((uint32_t)u & 0x7FFFFF));
    return true;
}

// max over u of (E'a[u] + E'b[u]) for non-zero products, from biased-exponent words (8 + 8);
// returns -1 when every product is zero.
HD int max_pair_exp(const uint32_t* ea, const uint32_t* eb) {
#ifdef __CUDA_ARCH__
    uint32_t m = 0;
#pragma unroll
    for (int x = 0; x < 8; ++x) m = __vmaxu4(m, __vadd4(__ldg(ea + x), __ldg(eb + x)));
    int M = (int)(m & 255);
    M = max(M, (int)((m >> 8) & 255)); M = max(M, (int)((m >> 16) & 255)); M = max(M, (int)(m >> 24));
#else
    int M = 0;
    for (int x = 0; x < 8; ++x)
        for (int y = 0; y < 4; ++y) {
            int s = (int)((ea[x] >> (8 * y)) & 255) + (int)((eb[x] >> (8 * y)) & 255);
            M = s > M ? s : M;
        }
#endif
    return M >= 34 ? M - 32 : -1;                             // both non-zero: (E'a+16)+(E'b+16) >= 34
}

// P2: the exact B200 group (same result as b200_group_exact), using the exact integer sum T.
HD float group_p2(float carry, int64_t T, uint64_t ra, uint64_t rb, const uint8_t* a, const uint8_t* b,
                  const uint32_t* ma16, const uint32_t* mb16, const uint32_t* ea, const uint32_t* eb) {
    const uint32_t bits = emu_f2u(carry);
    const bool cz = (bits & 0x7FFFFFFF) == 0;
    const int ef = (bits >> 23) & 0xFF;
    const int ecc = ef ? ef - 127 : -126;
    const uint32_t csig = ef ? (0x800000u | (bits & 0x7FFFFF)) : (bits & 0x7FFFFF);
    const int S = (rec_max(ra) && rec_max(rb)) ? max_pair_exp(ea, eb) : -1;
    if (S < 0 && cz) return 0.0f;
    int maxe;
    if (S < 0) maxe = ecc;
    else { maxe = S - 14; if (!cz && ecc > maxe) maxe = ecc; }
    int64_t acc = 0;
    if (!cz) {
        const int sh = maxe - ecc;
        if (sh < 32) { const int64_t al = (int64_t)((csig << 2) >> sh); acc += (bits >> 31) ? -al : al; }
    }
    if (S >= 0) {
        const int gu = maxe - 7, thr = maxe - 5;
        int64_t Tt = T;
        if (gu > 0) {
            if (cand_maybe(ra, rb, thr)) Tt -= cand_correction(a, b, ra, rb, ma16, mb16, thr);
            acc += Tt >> gu;                                  // exact: Tt is a multiple of 2^gu
        } else {
            acc += Tt * ((int64_t)1 << (-gu));
        }
    }
    const int sign = acc < 0;
    uint32_t s = (uint32_t)(acc < 0 ? -acc : acc);
    if (s == 0) return emu_u2f((uint32_t)sign << 31);
    const int w = 32 - emu_clz32(s);
    int e = maxe + w - 26;
    if (w > 26) s >>= (w - 26); else s <<= (26 - w);
    if (e < -126) { const int sh = -126 - e; s = sh >= 32 ? 0 : (s >> sh); e = -126; }
    s >>= 2;
    EmuGF r = {sign, e, s};
    if (s == 0) r.exponent = -139;
    return gf_to_f32(r);
}

// One B200 group step for one cell. T = exact dot product of the group (units 2^-18).
// path (optional): 0 = P1 no candidates, 1 = P1 with candidate scan, 2 = P2.
HD float cell_step(float carry, int64_t T, uint64_t ra, uint64_t rb, const uint8_t* a, const uint8_t* b,
                   const uint32_t* ma16, const uint32_t* mb16, const uint32_t* ea, const uint32_t* eb, int* path) {
    const uint32_t bits = emu_f2u(carry);
    const int ef = (bits >> 23) & 0xFF;
    const int mA = rec_max(ra), mB = rec_max(rb);
    if (ef != 0 && (!mA || !mB || mA + mB - 14 <= ef - 127)) {   // P1: normal carry is the anchor
        const int thr = ef - 127 - 5;
        int64_t corr = 0;
        int p = 0;
        if (mA && mB && cand_maybe(ra, rb, thr)) { corr = cand_correction(a, b, ra, rb, ma16, mb16, thr); p = 1; }
        float out;
        if (rz_add(T - corr, carry, &out)) { if (path) *path = p; return out; }
    }
    if (path) *path = 2;
    return group_p2(carry, T, ra, rb, a, b, ma16, mb16, ea, eb);
}

// ---- operand preparation (one call per block of `blk` rows and one 32-group) ---------------
// Outputs (G = K/32): limbs[3][rows][K] (int8), rec[G][rows] (u64), blkL[G][rows/blk] (u8),
// masks[rows][G][16] (u32, v1 le-masks), eb[rows][K] (u8 biased exponents).
HD void prep2_block(const uint8_t* codes, int rows, int K, int blk, int bi, int grp,
                    int8_t* limbs, uint64_t* rec, uint8_t* blkL, uint32_t* masks, uint8_t* eb) {
    const int G = K / 32;
    const size_t plane = (size_t)rows * K;
    int L = 2;
    for (int i = 0; i < blk; ++i) {
        const int row = bi * blk + i;
        const uint8_t* c = codes + (size_t)row * K + 32 * grp;
        const uint64_t r = make_rec(c);
        rec[(size_t)grp * rows + row] = r;
        const int l = rel_limbs(c, rec_s(r));
        L = l > L ? l : L;
        group_masks(c, masks + ((size_t)row * G + grp) * 16);
        for (int u = 0; u < 32; ++u) eb[(size_t)row * K + 32 * grp + u] = code_eb(c[u]);
    }
    blkL[(size_t)grp * (rows / blk) + bi] = (uint8_t)L;
    for (int i = 0; i < blk; ++i) {
        const int row = bi * blk + i;
        const uint8_t* c = codes + (size_t)row * K + 32 * grp;
        const int s = rec_s(rec[(size_t)grp * rows + row]);
        for (int u = 0; u < 32; ++u) {
            const int r = rel_r(c[u], s);
            for (int p = 0; p < 3; ++p) limbs[p * plane + (size_t)row * K + 32 * grp + u] = rel_limb(r, p, L);
        }
    }
}

// ---- lazy access to the per-cell data that only rare paths need ----------------------------
struct CellSrc {
    const uint8_t* A; const uint8_t* B; const uint32_t* MA; const uint32_t* MB; const uint8_t* EA; const uint8_t* EB;
    int r, c, grp, K, G;
    HD const uint8_t* a() const { return A + (size_t)r * K + 32 * grp; }
    HD const uint8_t* b() const { return B + (size_t)c * K + 32 * grp; }
    HD const uint32_t* ma() const { return MA + ((size_t)r * G + grp) * 16; }
    HD const uint32_t* mb() const { return MB + ((size_t)c * G + grp) * 16; }
    HD const uint32_t* ea() const { return reinterpret_cast<const uint32_t*>(EA + (size_t)r * K + 32 * grp); }
    HD const uint32_t* eb() const { return reinterpret_cast<const uint32_t*>(EB + (size_t)c * K + 32 * grp); }
};

// Same as cell_step, but the pointers are formed only inside the paths that use them.
HD float cell_step_src(float carry, int64_t T, uint64_t ra, uint64_t rb, const CellSrc& s, int* path) {
    const uint32_t bits = emu_f2u(carry);
    const int ef = (bits >> 23) & 0xFF;
    const int mA = rec_max(ra), mB = rec_max(rb);
    if (ef != 0 && (!mA || !mB || mA + mB - 14 <= ef - 127)) {
        const int thr = ef - 127 - 5;
        int64_t corr = 0;
        int p = 0;
        if (mA && mB && cand_maybe(ra, rb, thr)) { corr = cand_correction(s.a(), s.b(), ra, rb, s.ma(), s.mb(), thr); p = 1; }
        float out;
        if (rz_add(T - corr, carry, &out)) { if (path) *path = p; return out; }
    }
    if (path) *path = 2;
    return group_p2(carry, T, ra, rb, s.a(), s.b(), s.ma(), s.mb(), s.ea(), s.eb());
}
