// Bit-exact B200 (Pearl Device = 1) FP8 matmul emulator for RTX 40 (sm_89), plus reference
// tensor-core throughput kernels. Build: python3 build.py (NVRTC 12.8 -> PTX, ptxas -arch=sm_89 -O3)
// v1: emu_b200 (unchanged). v2: prep2 + emu2_<WM><WN> (see emu2_math.cuh). Edits: alex_kodiaq.
//
// emu_b200: C[i][j] = B200 chain over k of A row i and B row j (both e4m3, k-contiguous).
//   1) INT8 tensor cores compute the exact integer dot product of every 32-group
//      (3 x 3 signed 6-bit limbs per value, 9 IMMA per 16x8 tile, accumulated in 5 buckets).
//   2) CUDA cores apply B200's per-group rounding: fast path 2 (carry is the anchor, subtract
//      the remainders of small products), fast path 1 (nothing can be truncated), otherwise the
//      exact per-term algorithm. Slow cells are queued per warp and processed lane-parallel.
//   mode = 1 forces the exact per-term algorithm for every cell (a plain CUDA-core emulator).
#include "emu2_math.cuh"

extern "C" __global__ void prep(const uint8_t* __restrict__ codes, int rows, int K,
                                int8_t* __restrict__ limbs, uint8_t* __restrict__ summ, uint32_t* __restrict__ masks) {
    int G = K / 32;
    long long idx = (long long)blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= (long long)rows * G) return;
    int row = (int)(idx / G), grp = (int)(idx % G);
    const uint8_t* c = codes + (size_t)row * K + 32 * grp;
    uint8_t loc[32];
    for (int u = 0; u < 32; ++u) loc[u] = c[u];
    size_t plane = (size_t)rows * K;
    for (int l = 0; l < 3; ++l)
        for (int u = 0; u < 32; ++u) limbs[l * plane + (size_t)row * K + 32 * grp + u] = code_limb(loc[u], l);
    summ[idx] = group_summary(loc);
    uint32_t m[16];
    group_masks(loc, m);
    for (int t = 0; t < 16; ++t) masks[idx * 16 + t] = m[t];
}

__device__ __forceinline__ void imma(int (&d)[4], const uint32_t (&a)[4], uint32_t b0, uint32_t b1) {
    asm volatile("mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
                 : "+r"(d[0]), "+r"(d[1]), "+r"(d[2]), "+r"(d[3])
                 : "r"(a[0]), "r"(a[1]), "r"(a[2]), "r"(a[3]), "r"(b0), "r"(b1));
}

__device__ __forceinline__ uint32_t ld32(const void* p) { return __ldg(reinterpret_cast<const unsigned int*>(p)); }

// CTA: 4 warps, 32 x 32 output tile; warp (wm, wn) owns rows 16*wm.., columns 16*wn.. (two 16x8 mma tiles).
extern "C" __global__ void __launch_bounds__(128) emu_b200(
        const uint8_t* __restrict__ A, const uint8_t* __restrict__ B,
        const int8_t* __restrict__ AL, const int8_t* __restrict__ BL,
        const uint8_t* __restrict__ SA, const uint8_t* __restrict__ SB,
        const uint32_t* __restrict__ MA, const uint32_t* __restrict__ MB,
        float* __restrict__ C, int M, int N, int K, int mode) {
    __shared__ float qcarry[4][256];
    __shared__ unsigned short qitem[4][256];
    const int lane = threadIdx.x & 31, warp = threadIdx.x >> 5;
    const int g = lane >> 2, t = lane & 3;
    const int row0 = blockIdx.y * 32 + (warp >> 1) * 16;
    const int col0 = blockIdx.x * 32 + (warp & 1) * 16;
    const int G = K / 32;
    const size_t planeA = (size_t)M * K, planeB = (size_t)N * K;
    // the 8 cells of this lane: slot = nt*4 + v ; v: 0 (g, 2t) 1 (g, 2t+1) 2 (g+8, 2t) 3 (g+8, 2t+1)
    int crow[8], ccol[8];
    for (int nt = 0; nt < 2; ++nt)
        for (int v = 0; v < 4; ++v) {
            crow[nt * 4 + v] = row0 + g + (v >> 1) * 8;
            ccol[nt * 4 + v] = col0 + nt * 8 + 2 * t + (v & 1);
        }
    float carry[8];
    for (int s = 0; s < 8; ++s) carry[s] = 0.0f;

    for (int grp = 0; grp < G; ++grp) {
        const int k0 = grp * 32;
        uint32_t a[3][4];
        for (int l = 0; l < 3; ++l) {
            const int8_t* p0 = AL + l * planeA + (size_t)(row0 + g) * K + k0 + t * 4;
            const int8_t* p1 = p0 + (size_t)8 * K;
            a[l][0] = ld32(p0); a[l][1] = ld32(p1); a[l][2] = ld32(p0 + 16); a[l][3] = ld32(p1 + 16);
        }
        int s[2][5][4];
        for (int nt = 0; nt < 2; ++nt) {
            uint32_t b[3][2];
            for (int l = 0; l < 3; ++l) {
                const int8_t* q = BL + l * planeB + (size_t)(col0 + nt * 8 + g) * K + k0 + t * 4;
                b[l][0] = ld32(q); b[l][1] = ld32(q + 16);
            }
            for (int x = 0; x < 5; ++x) for (int v = 0; v < 4; ++v) s[nt][x][v] = 0;
            for (int i = 0; i < 3; ++i)
                for (int j = 0; j < 3; ++j) imma(s[nt][i + j], a[i], b[j][0], b[j][1]);
        }
        unsigned slow = 0;
#pragma unroll
        for (int slot = 0; slot < 8; ++slot) {
            const int nt = slot >> 2, v = slot & 3;
            const int r = crow[slot], c = ccol[slot];
            const float cy = carry[slot];
            if (mode == 1) { slow |= 1u << slot; continue; }
            const uint8_t sa = __ldg(SA + (size_t)r * G + grp), sb = __ldg(SB + (size_t)c * G + grp);
            const int64_t T = combine_buckets(s[nt][0][v], s[nt][1][v], s[nt][2][v], s[nt][3][v], s[nt][4][v]);
            int ec, nc = 0;
            if (carry_anchored(sa, sb, cy, &ec)) {
                int64_t corr = 0;
                if (sa && sb && ec > 7 && (sa & 15) + (sb & 15) < ec - 5)
                    corr = truncation_correction(A + (size_t)r * K + k0, B + (size_t)c * K + k0, sa, sb,
                                                 MA + ((size_t)r * G + grp) * 16, MB + ((size_t)c * G + grp) * 16, ec, &nc);
                carry[slot] = fast_result(T - corr, cy);
            } else if (fast_ok(sa, sb, cy)) {
                carry[slot] = fast_result(T, cy);
            } else {
                slow |= 1u << slot;
            }
        }
        // ---- queue the slow cells of the whole warp and process them lane-parallel ----
        int cnt = __popc(slow), off = cnt;
        for (int d = 1; d < 32; d <<= 1) { int x = __shfl_up_sync(0xffffffffu, off, d); if (lane >= d) off += x; }
        int total = __shfl_sync(0xffffffffu, off, 31);
        off -= cnt;
        if (total) {
            int w = off;
#pragma unroll
            for (int slot = 0; slot < 8; ++slot)
                if (slow & (1u << slot)) { qitem[warp][w] = (unsigned short)((lane << 3) | slot); qcarry[warp][w] = carry[slot]; ++w; }
            __syncwarp();
            for (int idx = lane; idx < total; idx += 32) {
                const int it = qitem[warp][idx], src = it >> 3, slot = it & 7;
                const int sg = src >> 2, st = src & 3, nt = slot >> 2, v = slot & 3;
                const int r = row0 + sg + (v >> 1) * 8, c = col0 + nt * 8 + 2 * st + (v & 1);
                uint32_t aw[8], bw[8];
                const uint8_t* pa = A + (size_t)r * K + k0;
                const uint8_t* pb = B + (size_t)c * K + k0;
                for (int x = 0; x < 8; ++x) { aw[x] = ld32(pa + 4 * x); bw[x] = ld32(pb + 4 * x); }
                qcarry[warp][idx] = b200_group_exact(qcarry[warp][idx], reinterpret_cast<const uint8_t*>(aw),
                                                     reinterpret_cast<const uint8_t*>(bw));
            }
            __syncwarp();
            w = off;
#pragma unroll
            for (int slot = 0; slot < 8; ++slot)
                if (slow & (1u << slot)) carry[slot] = qcarry[warp][w++];
            __syncwarp();
        }
    }
    for (int slot = 0; slot < 8; ++slot) {
        float out = (emu_f2u(carry[slot]) & 0x7FFFFFFF) ? carry[slot] : 0.0f;   // final re-sum: -0 -> +0
        C[(size_t)crow[slot] * N + ccol[slot]] = out;
    }
}

// ---- reference throughput: native INT8 and native (non-bit-exact) FP8 tensor cores ----
extern "C" __global__ void __launch_bounds__(128) bench_int8(unsigned iters, unsigned seed, unsigned* out) {
    uint32_t a = (seed & 0x07070707u) | 0x30303030u;
    int acc[8][4];
    for (int s = 0; s < 8; ++s) for (int v = 0; v < 4; ++v) acc[s][v] = 0;
    for (unsigned it = 0; it < iters; ++it) {
#pragma unroll
        for (int s = 0; s < 8; ++s)
            asm volatile("mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32 {%0,%1,%2,%3}, {%4,%4,%4,%4}, {%4,%4}, {%0,%1,%2,%3};"
                         : "+r"(acc[s][0]), "+r"(acc[s][1]), "+r"(acc[s][2]), "+r"(acc[s][3]) : "r"(a));
    }
    int x = 0;
    for (int s = 0; s < 8; ++s) for (int v = 0; v < 4; ++v) x ^= acc[s][v];
    atomicXor(out, (unsigned)x);
}
extern "C" __global__ void __launch_bounds__(128) bench_fp8(unsigned iters, unsigned seed, unsigned* out) {
    uint32_t a = (seed & 0x07070707u) | 0x30303030u;
    float acc[8][4];
    for (int s = 0; s < 8; ++s) for (int v = 0; v < 4; ++v) acc[s][v] = 0.0f;
    for (unsigned it = 0; it < iters; ++it) {
#pragma unroll
        for (int s = 0; s < 8; ++s)
            asm volatile("mma.sync.aligned.m16n8k32.row.col.f32.e4m3.e4m3.f32 {%0,%1,%2,%3}, {%4,%4,%4,%4}, {%4,%4}, {%0,%1,%2,%3};"
                         : "+f"(acc[s][0]), "+f"(acc[s][1]), "+f"(acc[s][2]), "+f"(acc[s][3]) : "r"(a));
    }
    unsigned x = 0;
    for (int s = 0; s < 8; ++s) for (int v = 0; v < 4; ++v) x ^= __float_as_uint(acc[s][v]);
    atomicXor(out, x);
}

// ============================================================================================
// v2. prep2: one thread per (block of `blk` rows, 32-group). Layouts in emu2_math.cuh.
extern "C" __global__ void prep2(const uint8_t* __restrict__ codes, int rows, int K, int blk,
                                 int8_t* __restrict__ limbs, uint64_t* __restrict__ rec, uint8_t* __restrict__ blkL,
                                 uint32_t* __restrict__ masks, uint8_t* __restrict__ eb) {
    const int G = K / 32, nb = rows / blk;
    long long idx = (long long)blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= (long long)nb * G) return;
    prep2_block(codes, rows, K, blk, (int)(idx / G), (int)(idx % G), limbs, rec, blkL, masks, eb);
}

// IMMA m16n8k32 with per-operand signedness (u8 for low limbs, s8 for the top limb)
template <bool SA, bool SB>
__device__ __forceinline__ void im(int (&d)[4], const uint32_t (&a)[4], const uint32_t (&b)[2]);
#define EMU2_IM(SA, SB, TA, TB)                                                                                  \
    template <> __device__ __forceinline__ void im<SA, SB>(int (&d)[4], const uint32_t (&a)[4], const uint32_t (&b)[2]) { \
        asm volatile("mma.sync.aligned.m16n8k32.row.col.s32." TA "." TB ".s32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};" \
                     : "+r"(d[0]), "+r"(d[1]), "+r"(d[2]), "+r"(d[3])                                        \
                     : "r"(a[0]), "r"(a[1]), "r"(a[2]), "r"(a[3]), "r"(b[0]), "r"(b[1]));                      \
    }
EMU2_IM(false, false, "u8", "u8")
EMU2_IM(false, true, "u8", "s8")
EMU2_IM(true, false, "s8", "u8")
EMU2_IM(true, true, "s8", "s8")

// exact integer dot products of one 16x8x32 tile: acc[x] = sum over limb pairs with p + q = x
__device__ __forceinline__ void tile_mma(int (&acc)[5][4], const uint32_t (&a)[3][4], const uint32_t (&b)[3][2], int LA, int LB) {
#pragma unroll
    for (int x = 0; x < 5; ++x)
#pragma unroll
        for (int v = 0; v < 4; ++v) acc[x][v] = 0;
    if (LA == 2) {
        if (LB == 2) {
            im<false, false>(acc[0], a[0], b[0]); im<false, true>(acc[1], a[0], b[1]);
            im<true, false>(acc[1], a[1], b[0]); im<true, true>(acc[2], a[1], b[1]);
        } else {
            im<false, false>(acc[0], a[0], b[0]); im<false, false>(acc[1], a[0], b[1]); im<false, true>(acc[2], a[0], b[2]);
            im<true, false>(acc[1], a[1], b[0]); im<true, false>(acc[2], a[1], b[1]); im<true, true>(acc[3], a[1], b[2]);
        }
    } else {
        if (LB == 2) {
            im<false, false>(acc[0], a[0], b[0]); im<false, true>(acc[1], a[0], b[1]);
            im<false, false>(acc[1], a[1], b[0]); im<false, true>(acc[2], a[1], b[1]);
            im<true, false>(acc[2], a[2], b[0]); im<true, true>(acc[3], a[2], b[1]);
        } else {
            im<false, false>(acc[0], a[0], b[0]); im<false, false>(acc[1], a[0], b[1]); im<false, true>(acc[2], a[0], b[2]);
            im<false, false>(acc[1], a[1], b[0]); im<false, false>(acc[2], a[1], b[1]); im<false, true>(acc[3], a[1], b[2]);
            im<true, false>(acc[2], a[2], b[0]); im<true, false>(acc[3], a[2], b[1]); im<true, true>(acc[4], a[2], b[2]);
        }
    }
}

// CTA: 4 warps (2 x 2); warp tile = WM row blocks of 16 x WN column blocks of 8.
// RND = false: diagnostic only (tensor cores + loads, no B200 rounding; NOT bit-exact).
template <int WM, int WN, bool RND>
__device__ __forceinline__ void emu2_body(
        const uint8_t* __restrict__ A, const uint8_t* __restrict__ B,
        const int8_t* __restrict__ AL, const int8_t* __restrict__ BL,
        const uint64_t* __restrict__ RA, const uint64_t* __restrict__ RB,
        const uint8_t* __restrict__ LAb, const uint8_t* __restrict__ LBb,
        const uint32_t* __restrict__ MA, const uint32_t* __restrict__ MB,
        const uint8_t* __restrict__ EA, const uint8_t* __restrict__ EB,
        float* __restrict__ C, int M, int N, int K) {
    const int lane = threadIdx.x & 31, warp = threadIdx.x >> 5;
    const int g = lane >> 2, t = lane & 3;
    const int row0 = blockIdx.y * (32 * WM) + (warp >> 1) * (16 * WM);
    const int col0 = blockIdx.x * (16 * WN) + (warp & 1) * (8 * WN);
    const int G = K / 32, MB16 = M / 16, NB8 = N / 8;
    const size_t planeA = (size_t)M * K, planeB = (size_t)N * K;
    float carry[WM][WN][4];
#pragma unroll
    for (int i = 0; i < WM; ++i)
#pragma unroll
        for (int j = 0; j < WN; ++j)
#pragma unroll
            for (int v = 0; v < 4; ++v) carry[i][j][v] = 0.0f;

    for (int grp = 0; grp < G; ++grp) {
        const int k0 = grp * 32;
        uint32_t a[WM][3][4];
        uint64_t ra[WM][2];
        int LA[WM];
#pragma unroll
        for (int rb = 0; rb < WM; ++rb) {
            const int rowb = row0 + rb * 16;
            LA[rb] = __ldg(LAb + (size_t)grp * MB16 + rowb / 16);
#pragma unroll
            for (int p = 0; p < 3; ++p) {
                if (p < LA[rb]) {
                    const int8_t* p0 = AL + p * planeA + (size_t)(rowb + g) * K + k0 + t * 4;
                    const int8_t* p1 = p0 + (size_t)8 * K;
                    a[rb][p][0] = ld32(p0); a[rb][p][1] = ld32(p1); a[rb][p][2] = ld32(p0 + 16); a[rb][p][3] = ld32(p1 + 16);
                } else {
                    a[rb][p][0] = a[rb][p][1] = a[rb][p][2] = a[rb][p][3] = 0u;
                }
            }
            ra[rb][0] = __ldg(reinterpret_cast<const unsigned long long*>(RA) + (size_t)grp * M + rowb + g);
            ra[rb][1] = __ldg(reinterpret_cast<const unsigned long long*>(RA) + (size_t)grp * M + rowb + g + 8);
        }
#pragma unroll
        for (int cb = 0; cb < WN; ++cb) {
            const int colb = col0 + cb * 8;
            const int LB = __ldg(LBb + (size_t)grp * NB8 + colb / 8);
            uint32_t b[3][2];
#pragma unroll
            for (int p = 0; p < 3; ++p) {
                if (p < LB) {
                    const int8_t* q = BL + p * planeB + (size_t)(colb + g) * K + k0 + t * 4;
                    b[p][0] = ld32(q); b[p][1] = ld32(q + 16);
                } else {
                    b[p][0] = b[p][1] = 0u;
                }
            }
            uint64_t rbv[2];
            rbv[0] = __ldg(reinterpret_cast<const unsigned long long*>(RB) + (size_t)grp * N + colb + 2 * t);
            rbv[1] = __ldg(reinterpret_cast<const unsigned long long*>(RB) + (size_t)grp * N + colb + 2 * t + 1);
#pragma unroll
            for (int rb = 0; rb < WM; ++rb) {
                int acc[5][4];
                tile_mma(acc, a[rb], b, LA[rb], LB);
#pragma unroll
                for (int v = 0; v < 4; ++v) {
                    const int h = v >> 1, j = v & 1;
                    int64_t Tp = (int64_t)acc[0][v] + ((int64_t)acc[1][v] << 8) + ((int64_t)acc[2][v] << 16);
                    if (LA[rb] + LB > 4) Tp += ((int64_t)acc[3][v] << 24) + ((int64_t)acc[4][v] << 32);
                    const uint64_t rA = ra[rb][h], rB = rbv[j];
                    const int64_t T = Tp << (rec_s(rA) + rec_s(rB) - 2);
                    if (RND) {
                        CellSrc s{A, B, MA, MB, EA, EB, row0 + rb * 16 + g + 8 * h, colb + 2 * t + j, grp, K, G};
                        carry[rb][cb][v] = cell_step_src(carry[rb][cb][v], T, rA, rB, s, nullptr);
                    } else {
                        carry[rb][cb][v] += (float)T;
                    }
                }
            }
        }
    }
#pragma unroll
    for (int rb = 0; rb < WM; ++rb)
#pragma unroll
        for (int cb = 0; cb < WN; ++cb)
#pragma unroll
            for (int v = 0; v < 4; ++v) {
                const float cy = carry[rb][cb][v];
                const int r = row0 + rb * 16 + g + 8 * (v >> 1), c = col0 + cb * 8 + 2 * t + (v & 1);
                C[(size_t)r * N + c] = (emu_f2u(cy) & 0x7FFFFFFF) ? cy : 0.0f;   // final re-sum: -0 -> +0
            }
}

#define EMU2_KERNEL(WM, WN, RND, SUFFIX)                                                                          \
    extern "C" __global__ void __launch_bounds__(128) emu2_##WM##WN##SUFFIX(                                      \
            const uint8_t* __restrict__ A, const uint8_t* __restrict__ B, const int8_t* __restrict__ AL,          \
            const int8_t* __restrict__ BL, const uint64_t* __restrict__ RA, const uint64_t* __restrict__ RB,      \
            const uint8_t* __restrict__ LAb, const uint8_t* __restrict__ LBb, const uint32_t* __restrict__ MA,    \
            const uint32_t* __restrict__ MB, const uint8_t* __restrict__ EA, const uint8_t* __restrict__ EB,      \
            float* __restrict__ C, int M, int N, int K) {                                                         \
        emu2_body<WM, WN, RND>(A, B, AL, BL, RA, RB, LAb, LBb, MA, MB, EA, EB, C, M, N, K);                       \
    }
EMU2_KERNEL(1, 2, true, )
EMU2_KERNEL(2, 2, true, )
EMU2_KERNEL(1, 4, true, )
EMU2_KERNEL(2, 4, true, )
EMU2_KERNEL(1, 2, false, _noround)
EMU2_KERNEL(2, 4, false, _noround)

// ============================================================================================
// v3 (alex_kodiaq, with Claude): same math as v2 (emu2_math.cuh), restructured for the GPU.
//  * Cheap path inline for every cell: carry anchored by the records, no possible truncation
//    candidate (record test), RZ add. ~83% of the groups on PIP-3 inputs.
//  * Every other cell goes to a per-warp queue in shared memory (T and carry at a fixed place per
//    (slot, lane), compacted list of ids). After the whole warp tile of the group the queue is
//    processed by all 32 lanes with the exact v2 step (cell_step_src). In v2 one such cell stalled
//    the whole warp in 98.8% of the steps; here the rare work is spread over the lanes.
//  * The fragments and records of the next group are loaded while the current one is computed.
template <int WM, int WN>
struct Frag3 {
    uint32_t a[WM][2][4];
    uint64_t ra[WM][2];
    int LA[WM];
    uint32_t b[WN][2][2];
    uint64_t rb[WN][2];
    int LB[WN];
};

template <int WM, int WN>
__device__ __forceinline__ void load3(Frag3<WM, WN>& F, int grp, int row0, int col0, int g, int t,
                                      const int8_t* __restrict__ AL, const int8_t* __restrict__ BL,
                                      const uint64_t* __restrict__ RA, const uint64_t* __restrict__ RB,
                                      const uint8_t* __restrict__ LAb, const uint8_t* __restrict__ LBb,
                                      int M, int N, int K, size_t planeA, size_t planeB) {
    const int k0 = grp * 32;
    const unsigned long long* ra64 = reinterpret_cast<const unsigned long long*>(RA);
    const unsigned long long* rb64 = reinterpret_cast<const unsigned long long*>(RB);
#pragma unroll
    for (int rb = 0; rb < WM; ++rb) {
        const int rowb = row0 + rb * 16;
        F.LA[rb] = __ldg(LAb + (size_t)grp * (M / 16) + rowb / 16);
#pragma unroll
        for (int p = 0; p < 2; ++p) {
            const int8_t* p0 = AL + p * planeA + (size_t)(rowb + g) * K + k0 + t * 4;
            const int8_t* p1 = p0 + (size_t)8 * K;
            F.a[rb][p][0] = ld32(p0); F.a[rb][p][1] = ld32(p1); F.a[rb][p][2] = ld32(p0 + 16); F.a[rb][p][3] = ld32(p1 + 16);
        }
        F.ra[rb][0] = __ldg(ra64 + (size_t)grp * M + rowb + g);
        F.ra[rb][1] = __ldg(ra64 + (size_t)grp * M + rowb + g + 8);
    }
#pragma unroll
    for (int cb = 0; cb < WN; ++cb) {
        const int colb = col0 + cb * 8;
        F.LB[cb] = __ldg(LBb + (size_t)grp * (N / 8) + colb / 8);
#pragma unroll
        for (int p = 0; p < 2; ++p) {
            const int8_t* q = BL + p * planeB + (size_t)(colb + g) * K + k0 + t * 4;
            F.b[cb][p][0] = ld32(q); F.b[cb][p][1] = ld32(q + 16);
        }
        F.rb[cb][0] = __ldg(rb64 + (size_t)grp * N + colb + 2 * t);
        F.rb[cb][1] = __ldg(rb64 + (size_t)grp * N + colb + 2 * t + 1);
    }
}

template <int WM, int WN, bool RND>
__device__ __forceinline__ void step3(const Frag3<WM, WN>& F, float (&carry)[WM][WN][4], int grp, int row0, int col0,
                                      int lane, int g, int t,
                                      const uint8_t* __restrict__ A, const uint8_t* __restrict__ B,
                                      const int8_t* __restrict__ AL, const int8_t* __restrict__ BL,
                                      const uint64_t* __restrict__ RA, const uint64_t* __restrict__ RB,
                                      const uint32_t* __restrict__ MA, const uint32_t* __restrict__ MB,
                                      const uint8_t* __restrict__ EA, const uint8_t* __restrict__ EB,
                                      int M, int N, int K, size_t planeA, size_t planeB,
                                      long long* qT, float* qC, unsigned short* qid) {
    constexpr int SLOTS = WM * WN * 4;
    const int k0 = grp * 32, G = K / 32;
    // plane 2 only for blocks that need 3 limbs (rare, warp-uniform)
    uint32_t a2[WM][4];
#pragma unroll
    for (int rb = 0; rb < WM; ++rb) {
        if (F.LA[rb] == 3) {
            const int8_t* p0 = AL + 2 * planeA + (size_t)(row0 + rb * 16 + g) * K + k0 + t * 4;
            const int8_t* p1 = p0 + (size_t)8 * K;
            a2[rb][0] = ld32(p0); a2[rb][1] = ld32(p1); a2[rb][2] = ld32(p0 + 16); a2[rb][3] = ld32(p1 + 16);
        } else {
            a2[rb][0] = a2[rb][1] = a2[rb][2] = a2[rb][3] = 0u;
        }
    }
    uint32_t slow = 0;
#pragma unroll
    for (int cb = 0; cb < WN; ++cb) {
        uint32_t b[3][2];
        b[0][0] = F.b[cb][0][0]; b[0][1] = F.b[cb][0][1]; b[1][0] = F.b[cb][1][0]; b[1][1] = F.b[cb][1][1];
        if (F.LB[cb] == 3) {
            const int8_t* q = BL + 2 * planeB + (size_t)(col0 + cb * 8 + g) * K + k0 + t * 4;
            b[2][0] = ld32(q); b[2][1] = ld32(q + 16);
        } else {
            b[2][0] = b[2][1] = 0u;
        }
#pragma unroll
        for (int rb = 0; rb < WM; ++rb) {
            uint32_t a[3][4];
#pragma unroll
            for (int x = 0; x < 4; ++x) { a[0][x] = F.a[rb][0][x]; a[1][x] = F.a[rb][1][x]; a[2][x] = a2[rb][x]; }
            int acc[5][4];
            tile_mma(acc, a, b, F.LA[rb], F.LB[cb]);
#pragma unroll
            for (int v = 0; v < 4; ++v) {
                const int slot = (cb * WM + rb) * 4 + v;
                int64_t Tp = (int64_t)acc[0][v] + ((int64_t)acc[1][v] << 8) + ((int64_t)acc[2][v] << 16);
                if (F.LA[rb] + F.LB[cb] > 4) Tp += ((int64_t)acc[3][v] << 24) + ((int64_t)acc[4][v] << 32);
                const uint64_t rA = F.ra[rb][v >> 1], rB = F.rb[cb][v & 1];
                const int64_t T = Tp << (rec_s(rA) + rec_s(rB) - 2);
                const float cy = carry[rb][cb][v];
                if (!RND) { carry[rb][cb][v] = cy + (float)T; continue; }
                const uint32_t bits = emu_f2u(cy);
                const int ef = (bits >> 23) & 0xFF;
                const int mA = rec_max(rA), mB = rec_max(rB);
                bool fast = ef != 0 && (!mA || !mB || mA + mB - 14 <= ef - 127);
                if (fast && mA && mB) fast = !cand_maybe(rA, rB, ef - 132);
                float out;
                if (fast && rz_add(T, cy, &out)) {
                    carry[rb][cb][v] = out;
                } else {
                    slow |= 1u << slot;
                    qT[slot * 32 + lane] = (long long)T;
                    qC[slot * 32 + lane] = cy;
                }
            }
        }
    }
    if (!RND) return;
    // compacted id list of the slow cells of the whole warp tile
    int n = 0;
    const uint32_t lt = (1u << lane) - 1u;
#pragma unroll
    for (int s = 0; s < SLOTS; ++s) {
        const uint32_t m = __ballot_sync(0xffffffffu, (slow >> s) & 1u);
        if (m) {
            if ((slow >> s) & 1u) qid[n + __popc(m & lt)] = (unsigned short)(s * 32 + lane);
            n += __popc(m);
        }
    }
    if (n == 0) return;
    __syncwarp();
    for (int idx = lane; idx < n; idx += 32) {
        const int id = qid[idx], s = id >> 5, ln = id & 31;
        const int v = s & 3, rb = (s >> 2) % WM, cb = (s >> 2) / WM;
        const int r = row0 + rb * 16 + (ln >> 2) + 8 * (v >> 1);
        const int c = col0 + cb * 8 + 2 * (ln & 3) + (v & 1);
        const uint64_t rA = __ldg(reinterpret_cast<const unsigned long long*>(RA) + (size_t)grp * M + r);
        const uint64_t rB = __ldg(reinterpret_cast<const unsigned long long*>(RB) + (size_t)grp * N + c);
        CellSrc src{A, B, MA, MB, EA, EB, r, c, grp, K, G};
        qC[id] = cell_step_src(qC[id], (int64_t)qT[id], rA, rB, src, nullptr);
    }
    __syncwarp();
#pragma unroll
    for (int cb = 0; cb < WN; ++cb)
#pragma unroll
        for (int rb = 0; rb < WM; ++rb)
#pragma unroll
            for (int v = 0; v < 4; ++v) {
                const int s = (cb * WM + rb) * 4 + v;
                if ((slow >> s) & 1u) carry[rb][cb][v] = qC[s * 32 + lane];
            }
    __syncwarp();
}

template <int WM, int WN, bool RND>
__device__ __forceinline__ void emu3_body(
        const uint8_t* __restrict__ A, const uint8_t* __restrict__ B,
        const int8_t* __restrict__ AL, const int8_t* __restrict__ BL,
        const uint64_t* __restrict__ RA, const uint64_t* __restrict__ RB,
        const uint8_t* __restrict__ LAb, const uint8_t* __restrict__ LBb,
        const uint32_t* __restrict__ MA, const uint32_t* __restrict__ MB,
        const uint8_t* __restrict__ EA, const uint8_t* __restrict__ EB,
        float* __restrict__ C, int M, int N, int K) {
    constexpr int CAP = WM * WN * 4 * 32;
    __shared__ long long sT[4][RND ? CAP : 1];
    __shared__ float sC[4][RND ? CAP : 1];
    __shared__ unsigned short sI[4][RND ? CAP : 1];
    const int lane = threadIdx.x & 31, warp = threadIdx.x >> 5;
    const int g = lane >> 2, t = lane & 3;
    const int row0 = blockIdx.y * (32 * WM) + (warp >> 1) * (16 * WM);
    const int col0 = blockIdx.x * (16 * WN) + (warp & 1) * (8 * WN);
    const int G = K / 32;
    const size_t planeA = (size_t)M * K, planeB = (size_t)N * K;
    float carry[WM][WN][4];
#pragma unroll
    for (int i = 0; i < WM; ++i)
#pragma unroll
        for (int j = 0; j < WN; ++j)
#pragma unroll
            for (int v = 0; v < 4; ++v) carry[i][j][v] = 0.0f;
    Frag3<WM, WN> F0, F1;
    load3<WM, WN>(F0, 0, row0, col0, g, t, AL, BL, RA, RB, LAb, LBb, M, N, K, planeA, planeB);
    for (int grp = 0; grp < G; grp += 2) {
        if (grp + 1 < G) load3<WM, WN>(F1, grp + 1, row0, col0, g, t, AL, BL, RA, RB, LAb, LBb, M, N, K, planeA, planeB);
        step3<WM, WN, RND>(F0, carry, grp, row0, col0, lane, g, t, A, B, AL, BL, RA, RB, MA, MB, EA, EB, M, N, K,
                           planeA, planeB, sT[warp], sC[warp], sI[warp]);
        if (grp + 1 >= G) break;
        if (grp + 2 < G) load3<WM, WN>(F0, grp + 2, row0, col0, g, t, AL, BL, RA, RB, LAb, LBb, M, N, K, planeA, planeB);
        step3<WM, WN, RND>(F1, carry, grp + 1, row0, col0, lane, g, t, A, B, AL, BL, RA, RB, MA, MB, EA, EB, M, N, K,
                           planeA, planeB, sT[warp], sC[warp], sI[warp]);
    }
#pragma unroll
    for (int rb = 0; rb < WM; ++rb)
#pragma unroll
        for (int cb = 0; cb < WN; ++cb)
#pragma unroll
            for (int v = 0; v < 4; ++v) {
                const float cy = carry[rb][cb][v];
                const int r = row0 + rb * 16 + g + 8 * (v >> 1), c = col0 + cb * 8 + 2 * t + (v & 1);
                C[(size_t)r * N + c] = (emu_f2u(cy) & 0x7FFFFFFF) ? cy : 0.0f;   // final re-sum: -0 -> +0
            }
}

#define EMU3_KERNEL(WM, WN, RND, SUFFIX)                                                                          \
    extern "C" __global__ void __launch_bounds__(128) emu3_##WM##WN##SUFFIX(                                      \
            const uint8_t* __restrict__ A, const uint8_t* __restrict__ B, const int8_t* __restrict__ AL,          \
            const int8_t* __restrict__ BL, const uint64_t* __restrict__ RA, const uint64_t* __restrict__ RB,      \
            const uint8_t* __restrict__ LAb, const uint8_t* __restrict__ LBb, const uint32_t* __restrict__ MA,    \
            const uint32_t* __restrict__ MB, const uint8_t* __restrict__ EA, const uint8_t* __restrict__ EB,      \
            float* __restrict__ C, int M, int N, int K) {                                                         \
        emu3_body<WM, WN, RND>(A, B, AL, BL, RA, RB, LAb, LBb, MA, MB, EA, EB, C, M, N, K);                       \
    }
EMU3_KERNEL(1, 2, true, )
EMU3_KERNEL(2, 1, true, )
EMU3_KERNEL(2, 2, true, )
EMU3_KERNEL(1, 4, true, )
EMU3_KERNEL(1, 2, false, _noround)
EMU3_KERNEL(2, 2, false, _noround)
