// Fake libcuda for dry-running fp8emu.py: kernels are executed on the CPU with emu_math.cuh (v1)
// and emu2_math.cuh (v2: prep2, emu2_<WM><WN>). Checks the host plumbing, not the GPU fragment layout.
#include "emu2_math.cuh"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
static int sm() { return 89; }
extern "C" {
int cuInit(unsigned) { return 0; }
int cuDriverGetVersion(int* v) { *v = 12080; return 0; }
int cuDeviceGetCount(int* c) { *c = 1; return 0; }
int cuDeviceGet(int* d, int i) { *d = i; return 0; }
int cuDeviceGetName(char* s, int n, int) { std::snprintf(s, n, "%s", sm() == 89 ? "FAKE GeForce RTX 4090" : "FAKE GeForce RTX 5090"); return 0; }
int cuDeviceGetAttribute(int* v, int attr, int) {
    if (attr == 75) *v = sm() == 89 ? 8 : 12;
    else if (attr == 76) *v = sm() == 89 ? 9 : 0;
    else if (attr == 16) *v = sm() == 89 ? 128 : 170;
    else return 1;
    return 0;
}
int cuDevicePrimaryCtxRetain(void** c, int) { *c = (void*)0x1; return 0; }
int cuDevicePrimaryCtxRelease_v2(int) { return 0; }
int cuCtxSetCurrent(void*) { return 0; }
int cuCtxSynchronize() { return 0; }
int cuModuleLoadData(void** m, const char* image) {
    if (std::memcmp(image, "\x7f" "ELF", 4) != 0) return 200;   // CUDA_ERROR_INVALID_IMAGE
    uint64_t shoff; uint16_t shentsize, shnum;   // copy the image, as the real driver does
    std::memcpy(&shoff, image + 0x28, 8); std::memcpy(&shentsize, image + 0x3A, 2); std::memcpy(&shnum, image + 0x3C, 2);
    size_t size = size_t(shoff) + size_t(shnum) * shentsize;
    char* copy = (char*)std::malloc(size); std::memcpy(copy, image, size);
    *m = copy; return 0;
}
int cuModuleUnload(void*) { return 0; }
int cuModuleGetFunction(void** f, void* mod, const char* name) {
    // the cubin's symbol table must contain the name
    const char* img = (const char*)mod;
    std::string needle(name);
    bool found = false;
    uint64_t shoff; uint16_t shentsize, shnum;   // ELF64: size = e_shoff + e_shnum * e_shentsize
    std::memcpy(&shoff, img + 0x28, 8); std::memcpy(&shentsize, img + 0x3A, 2); std::memcpy(&shnum, img + 0x3C, 2);
    size_t size = size_t(shoff) + size_t(shnum) * shentsize;
    for (size_t i = 0; i + needle.size() + 1 <= size && !found; ++i) found = std::memcmp(img + i, needle.c_str(), needle.size() + 1) == 0;
    if (!found) return 500;  // CUDA_ERROR_NOT_FOUND
    *f = strdup(name); return 0;
}
int cuMemAlloc_v2(uint64_t* p, size_t n) { *p = (uint64_t)std::malloc(n); return 0; }
int cuMemFree_v2(uint64_t p) { std::free((void*)p); return 0; }
int cuMemcpyHtoD_v2(uint64_t d, const void* h, size_t n) { std::memcpy((void*)d, h, n); return 0; }
int cuMemcpyDtoH_v2(void* h, uint64_t d, size_t n) { std::memcpy(h, (void*)d, n); return 0; }
int cuMemsetD8_v2(uint64_t d, unsigned char v, size_t n) { std::memset((void*)d, v, n); return 0; }
int cuLaunchKernel(void* f, unsigned gx, unsigned gy, unsigned, unsigned bx, unsigned, unsigned, unsigned, void*, void** params, void**) {
    std::string name((const char*)f);
    if (name == "prep") {
        const uint8_t* codes = *(const uint8_t**)params[0]; int rows = *(int*)params[1], K = *(int*)params[2];
        int8_t* limbs = *(int8_t**)params[3]; uint8_t* summ = *(uint8_t**)params[4]; uint32_t* masks = *(uint32_t**)params[5];
        int G = K / 32; size_t plane = size_t(rows) * K;
        for (int r = 0; r < rows; ++r) for (int g = 0; g < G; ++g) {
            const uint8_t* c = codes + size_t(r) * K + 32 * g;
            for (int l = 0; l < 3; ++l) for (int u = 0; u < 32; ++u) limbs[l * plane + size_t(r) * K + 32 * g + u] = code_limb(c[u], l);
            summ[size_t(r) * G + g] = group_summary(c); group_masks(c, masks + (size_t(r) * G + g) * 16);
        }
    } else if (name == "prep2") {
        const uint8_t* codes = *(const uint8_t**)params[0]; int rows = *(int*)params[1], K = *(int*)params[2], blk = *(int*)params[3];
        int8_t* limbs = *(int8_t**)params[4]; uint64_t* rec = *(uint64_t**)params[5]; uint8_t* blkL = *(uint8_t**)params[6];
        uint32_t* masks = *(uint32_t**)params[7]; uint8_t* eb = *(uint8_t**)params[8];
        if (rows % blk) return 1;
        for (int bi = 0; bi < rows / blk; ++bi) for (int g = 0; g < K / 32; ++g) prep2_block(codes, rows, K, blk, bi, g, limbs, rec, blkL, masks, eb);
    } else if (name.rfind("emu2_", 0) == 0 || name.rfind("emu3_", 0) == 0) {
        const int WM = name[5] - '0', WN = name[6] - '0';
        const uint8_t* A = *(const uint8_t**)params[0]; const uint8_t* B = *(const uint8_t**)params[1];
        const int8_t* AL = *(const int8_t**)params[2]; const int8_t* BL = *(const int8_t**)params[3];
        const uint64_t* RA = *(const uint64_t**)params[4]; const uint64_t* RB = *(const uint64_t**)params[5];
        const uint8_t* LAb = *(const uint8_t**)params[6]; const uint8_t* LBb = *(const uint8_t**)params[7];
        const uint32_t* MA = *(const uint32_t**)params[8]; const uint32_t* MB = *(const uint32_t**)params[9];
        const uint8_t* EA = *(const uint8_t**)params[10]; const uint8_t* EB = *(const uint8_t**)params[11];
        float* C = *(float**)params[12]; int M = *(int*)params[13], N = *(int*)params[14], K = *(int*)params[15];
        if (gx * 16 * WN != unsigned(N) || gy * 32 * WM != unsigned(M) || bx != 128) return 1;
        const int G = K / 32; const size_t pa = size_t(M) * K, pb = size_t(N) * K;
        for (int i = 0; i < M; ++i) for (int j = 0; j < N; ++j) {
            float cy = 0.0f;
            for (int g = 0; g < G; ++g) {
                const int LA = LAb[size_t(g) * (M / 16) + i / 16], LB = LBb[size_t(g) * (N / 8) + j / 8];
                int64_t Tp = 0;
                for (int p = 0; p < LA; ++p) for (int q = 0; q < LB; ++q) {
                    int d = 0;
                    for (int u = 0; u < 32; ++u) d += limb_val(AL[p * pa + size_t(i) * K + 32 * g + u], p, LA) * limb_val(BL[q * pb + size_t(j) * K + 32 * g + u], q, LB);
                    Tp += (int64_t)d * ((int64_t)1 << (8 * (p + q)));
                }
                const uint64_t ra = RA[size_t(g) * M + i], rb = RB[size_t(g) * N + j];
                const int64_t T = Tp * ((int64_t)1 << (rec_s(ra) + rec_s(rb) - 2));
                CellSrc s{A, B, MA, MB, EA, EB, i, j, g, K, G};
                cy = cell_step_src(cy, T, ra, rb, s, nullptr);
            }
            C[size_t(i) * N + j] = (emu_f2u(cy) & 0x7FFFFFFF) ? cy : 0.0f;
        }
    } else if (name == "emu_b200") {
        const uint8_t* A = *(const uint8_t**)params[0]; const uint8_t* B = *(const uint8_t**)params[1];
        const int8_t* AL = *(const int8_t**)params[2]; const int8_t* BL = *(const int8_t**)params[3];
        const uint8_t* SA = *(const uint8_t**)params[4]; const uint8_t* SB = *(const uint8_t**)params[5];
        const uint32_t* MA = *(const uint32_t**)params[6]; const uint32_t* MB = *(const uint32_t**)params[7];
        float* C = *(float**)params[8]; int M = *(int*)params[9], N = *(int*)params[10], K = *(int*)params[11], mode = *(int*)params[12];
        if (gx * 32 != unsigned(N) || gy * 32 != unsigned(M) || bx != 128) return 1;
        int G = K / 32; size_t pa = size_t(M) * K, pb = size_t(N) * K;
        for (int i = 0; i < M; ++i) for (int j = 0; j < N; ++j) {
            float cy = 0.0f;
            for (int g = 0; g < G; ++g) {
                const uint8_t* ag = A + size_t(i) * K + 32 * g; const uint8_t* bg = B + size_t(j) * K + 32 * g;
                if (mode == 1) { cy = b200_group_exact(cy, ag, bg); continue; }
                int s[5] = {0,0,0,0,0};
                for (int li = 0; li < 3; ++li) for (int lj = 0; lj < 3; ++lj) { int d = 0; for (int u = 0; u < 32; ++u) d += int(AL[li*pa + size_t(i)*K + 32*g + u]) * int(BL[lj*pb + size_t(j)*K + 32*g + u]); s[li+lj] += d; }
                int64_t T = combine_buckets(s[0], s[1], s[2], s[3], s[4]);
                uint8_t sa = SA[size_t(i)*G+g], sb = SB[size_t(j)*G+g]; int ec, nc;
                if (carry_anchored(sa, sb, cy, &ec)) {
                    int64_t corr = 0;
                    if (sa && sb && ec > 7 && (sa & 15) + (sb & 15) < ec - 5) corr = truncation_correction(ag, bg, sa, sb, MA + (size_t(i)*G+g)*16, MB + (size_t(j)*G+g)*16, ec, &nc);
                    cy = fast_result(T - corr, cy);
                } else if (fast_ok(sa, sb, cy)) cy = fast_result(T, cy);
                else cy = b200_group_exact(cy, ag, bg);
            }
            C[size_t(i) * N + j] = (emu_f2u(cy) & 0x7FFFFFFF) ? cy : 0.0f;
        }
    }
    return 0;
}
int cuEventCreate(void** e, unsigned) { *e = std::malloc(1); return 0; }
int cuEventRecord(void*, void*) { return 0; }
int cuEventSynchronize(void*) { return 0; }
int cuEventElapsedTime(float* ms, void*, void*) { *ms = 10.0f; return 0; }
int cuEventDestroy_v2(void* e) { std::free(e); return 0; }
int cuGetErrorString(int, const char** s) { *s = "fake error"; return 0; }
}
