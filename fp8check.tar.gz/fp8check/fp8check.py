#!/usr/bin/env python3
"""FP8 bit-exactness check for Pearl's FP8 fork (PIP-3): can an RTX 4090 (Ada, sm_89)
produce the bits the validator replays for Device = 1 (B200) or Device = 0 (H100)?

What it does, on every NVIDIA GPU it finds (or only on --gpu N):
  * runs the GPU's own FP8 tensor-core instruction on fixed test matrices
      - RTX 40 (sm_89):  both FP32-accumulating FP8 MMA shapes Ada has: m16n8k32 and m16n8k16
                         (the f16-accumulating forms return 16-bit values and cannot give FP32 bits)
      - RTX 50 (sm_120): the same instruction AND Cyberminer's block-scale instruction
  * compares every output value bit-for-bit with the arithmetic models:
      B200 (Device = 1), H100 (Device = 0), and Ada (pips#16)
  * optional --bench: measures INT8 vs FP8 tensor-core throughput of the card.

Needs only the NVIDIA driver (libcuda.so.1) and Python 3.6+. Nothing is installed and no
files are written (only a very old driver that rejects the cubin would JIT the PTX and may
fill the driver's JIT cache). The miner does not need to be stopped for the check (it takes
a few seconds). Stop the miner before --bench, or the numbers are low.
"""
import argparse
import ctypes
import hashlib
import io
import os
import struct
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data")

CU_DEVICE_ATTRIBUTE_MULTIPROCESSOR_COUNT = 16
CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR = 75
CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR = 76


class Cuda:
    def __init__(self, path):
        self.lib = ctypes.CDLL(path)
        L = self.lib
        vp, sz, i32, u32 = ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int, ctypes.c_uint
        P = ctypes.POINTER
        sig = {
            "cuInit": [u32],
            "cuDriverGetVersion": [P(i32)],
            "cuDeviceGetCount": [P(i32)],
            "cuDeviceGet": [P(i32), i32],
            "cuDeviceGetName": [ctypes.c_char_p, i32, i32],
            "cuDeviceGetAttribute": [P(i32), i32, i32],
            "cuDevicePrimaryCtxRetain": [P(vp), i32],
            "cuDevicePrimaryCtxRelease_v2": [i32],
            "cuCtxSetCurrent": [vp],
            "cuCtxSynchronize": [],
            "cuModuleLoadData": [P(vp), ctypes.c_char_p],
            "cuModuleUnload": [vp],
            "cuModuleGetFunction": [P(vp), vp, ctypes.c_char_p],
            "cuMemAlloc_v2": [P(ctypes.c_uint64), sz],
            "cuMemFree_v2": [ctypes.c_uint64],
            "cuMemcpyHtoD_v2": [ctypes.c_uint64, vp, sz],
            "cuMemcpyDtoH_v2": [vp, ctypes.c_uint64, sz],
            "cuMemsetD8_v2": [ctypes.c_uint64, ctypes.c_ubyte, sz],
            "cuLaunchKernel": [vp, u32, u32, u32, u32, u32, u32, u32, vp, P(vp), P(vp)],
            "cuEventCreate": [P(vp), u32],
            "cuEventRecord": [vp, vp],
            "cuEventSynchronize": [vp],
            "cuEventElapsedTime": [P(ctypes.c_float), vp, vp],
            "cuEventDestroy_v2": [vp],
            "cuGetErrorString": [i32, P(ctypes.c_char_p)],
        }
        for name, args in sig.items():
            fn = getattr(L, name)
            fn.argtypes = args
            fn.restype = i32

    def check(self, res, what):
        if res != 0:
            msg = ctypes.c_char_p()
            self.lib.cuGetErrorString(res, ctypes.byref(msg))
            raise RuntimeError("%s failed: CUDA error %d (%s)" % (what, res, (msg.value or b"?").decode()))

    def __getattr__(self, name):
        fn = getattr(self.lib, name)

        def call(*args):
            self.check(fn(*args), name)
        return call


def read(path):
    with open(path, "rb") as f:
        return f.read()


def load_manifest():
    suites = []
    for line in read(os.path.join(DATA, "manifest.txt")).decode().splitlines():
        if not line or line.startswith("#"):
            continue
        name, M, N, K, mv, nv, note = line.split(" ", 6)
        suites.append((name, int(M), int(N), int(K), int(mv), int(nv), note))
    return suites


def verify_sha256():
    sums = os.path.join(HERE, "SHA256SUMS.txt")
    if not os.path.exists(sums):
        return
    bad = 0
    for line in read(sums).decode().splitlines():
        digest, name = line.split(None, 1)
        name = name.lstrip("*")
        if name in ("SHA256SUMS.txt",):
            continue
        p = os.path.join(HERE, name)
        if not os.path.exists(p) or hashlib.sha256(read(p)).hexdigest() != digest:
            print("  ! file changed or missing: %s" % name)
            bad += 1
    if bad:
        print("  ! %d file(s) differ from SHA256SUMS.txt -- results are not trustworthy" % bad)
    else:
        print("  files: SHA256 OK")


def compare(got, want, M, N, mv, nv):
    """Compare the real (unpadded) mv x nv region bit-for-bit.
    Return (cells_equal, cells, tiles_equal, tiles). Tiles are 16x16 (Pearl's smallest lottery
    tile has 256 values); a small official vector counts as one tile."""
    g = struct.unpack("<%dI" % (M * N), got)
    w = struct.unpack("<%dI" % (M * N), want)
    eq = [[g[i * N + j] == w[i * N + j] for j in range(nv)] for i in range(mv)]
    th, tw = (16, 16) if (mv >= 16 and nv >= 16) else (mv, nv)
    tiles = tiles_eq = 0
    for ti in range(0, mv - th + 1, th):
        for tj in range(0, nv - tw + 1, tw):
            ok = all(eq[i][j] for i in range(ti, ti + th) for j in range(tj, tj + tw))
            tiles += 1
            tiles_eq += ok
    return sum(sum(r) for r in eq), mv * nv, tiles_eq, tiles


def run_check(cu, func, suite, window):
    name, M, N, K, mv, nv, note = suite
    assert M % 16 == 0 and N % 8 == 0 and K % 32 == 0, suite
    a = read(os.path.join(DATA, name + ".a"))
    b = read(os.path.join(DATA, name + ".b"))
    assert len(a) == M * K and len(b) == N * K
    dA, dB, dC = ctypes.c_uint64(), ctypes.c_uint64(), ctypes.c_uint64()
    cu.cuMemAlloc_v2(ctypes.byref(dA), len(a))
    cu.cuMemAlloc_v2(ctypes.byref(dB), len(b))
    cu.cuMemAlloc_v2(ctypes.byref(dC), M * N * 4)
    try:
        cu.cuMemcpyHtoD_v2(dA, a, len(a))
        cu.cuMemcpyHtoD_v2(dB, b, len(b))
        cu.cuMemsetD8_v2(dC, 0xFF, M * N * 4)  # NaN pattern: an unwritten cell can never match
        args = [ctypes.c_uint64(dA.value), ctypes.c_uint64(dB.value), ctypes.c_uint64(dC.value),
                ctypes.c_uint32(K), ctypes.c_uint32(N), ctypes.c_uint32(window)]
        params = (ctypes.c_void_p * len(args))(*[ctypes.cast(ctypes.pointer(x), ctypes.c_void_p) for x in args])
        cu.cuLaunchKernel(func, N // 8, M // 16, 1, 32, 1, 1, 0, None, params, None)
        cu.cuCtxSynchronize()
        out = ctypes.create_string_buffer(M * N * 4)
        cu.cuMemcpyDtoH_v2(out, dC, M * N * 4)
        return out.raw
    finally:
        for d in (dA, dB, dC):
            cu.cuMemFree_v2(d)


def bench(cu, func, sms, iters=1 << 18):
    out = ctypes.c_uint64()
    cu.cuMemAlloc_v2(ctypes.byref(out), 4)
    cu.cuMemsetD8_v2(out, 0, 4)
    blocks, threads = sms * 8, 128
    args = [ctypes.c_uint32(iters), ctypes.c_uint32(0x01020304), ctypes.c_uint64(out.value)]
    params = (ctypes.c_void_p * 3)(*[ctypes.cast(ctypes.pointer(x), ctypes.c_void_p) for x in args])
    e0, e1 = ctypes.c_void_p(), ctypes.c_void_p()
    cu.cuEventCreate(ctypes.byref(e0), 0)
    cu.cuEventCreate(ctypes.byref(e1), 0)
    cu.cuLaunchKernel(func, blocks, 1, 1, threads, 1, 1, 0, None, params, None)  # warm-up
    cu.cuCtxSynchronize()
    best = None
    for _ in range(3):
        cu.cuEventRecord(e0, None)
        cu.cuLaunchKernel(func, blocks, 1, 1, threads, 1, 1, 0, None, params, None)
        cu.cuEventRecord(e1, None)
        cu.cuEventSynchronize(e1)
        ms = ctypes.c_float()
        cu.cuEventElapsedTime(ctypes.byref(ms), e0, e1)
        best = ms.value if best is None else min(best, ms.value)
    cu.cuEventDestroy_v2(e0)
    cu.cuEventDestroy_v2(e1)
    cu.cuMemFree_v2(out)
    macs = blocks * (threads // 32) * iters * 8 * (16 * 8 * 32)
    return macs / (best * 1e-3) / 1e12


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--gpu", type=int, default=None, help="test only this GPU index (driver order)")
    ap.add_argument("--bench", action="store_true", help="also measure INT8 vs FP8 tensor throughput (stop the miner first)")
    ap.add_argument("--libcuda", default="libcuda.so.1", help=argparse.SUPPRESS)
    opt = ap.parse_args()

    if (sys.stdout.encoding or "").lower().replace("-", "") != "utf8":   # C/POSIX locale on Python 3.6
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace", line_buffering=True)
    print("FP8 bit-exactness check (Pearl PIP-3).  Python %s" % sys.version.split()[0])
    verify_sha256()
    cu = Cuda(opt.libcuda)
    cu.cuInit(0)
    ver = ctypes.c_int()
    cu.cuDriverGetVersion(ctypes.byref(ver))
    count = ctypes.c_int()
    cu.cuDeviceGetCount(ctypes.byref(count))
    print("  CUDA driver API %d.%d, %d GPU(s)" % (ver.value // 1000, ver.value % 1000 // 10, count.value))
    suites = load_manifest()
    indices = [opt.gpu] if opt.gpu is not None else list(range(count.value))
    for idx in indices:
        dev = ctypes.c_int()
        cu.cuDeviceGet(ctypes.byref(dev), idx)
        nm = ctypes.create_string_buffer(256)
        cu.cuDeviceGetName(nm, 256, dev.value)
        attr = ctypes.c_int()
        cu.cuDeviceGetAttribute(ctypes.byref(attr), CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, dev.value)
        major = attr.value
        cu.cuDeviceGetAttribute(ctypes.byref(attr), CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, dev.value)
        minor = attr.value
        cu.cuDeviceGetAttribute(ctypes.byref(attr), CU_DEVICE_ATTRIBUTE_MULTIPROCESSOR_COUNT, dev.value)
        sms = attr.value
        print("\n=== GPU %d: %s  (sm_%d%d, %d SM) ===" % (idx, nm.value.decode(errors="replace"), major, minor, sms))
        if (major, minor) == (8, 9):
            cubin, benches = "fp8check_sm89.cubin", ["int8", "ada"]
            variants = [("ada", "mma.sync m16n8k32 e4m3 -> f32 (native Ada FP8)"),
                        ("ada16", "mma.sync m16n8k16 e4m3 -> f32 (native Ada FP8, other shape)")]
        elif (major, minor) == (12, 0):
            cubin = "fp8check_sm120a.cubin"
            variants = [("ada", "mma.sync m16n8k32 e4m3 -> f32 (plain)"), ("cyber", "Cyberminer block-scale mma (multiply32)")]
            benches = ["int8", "ada", "cyber"]
        else:
            print("  skipped: this test is built for sm_89 (RTX 40) and sm_120 (RTX 50) only")
            continue
        ctx = ctypes.c_void_p()
        cu.cuDevicePrimaryCtxRetain(ctypes.byref(ctx), dev.value)
        cu.cuCtxSetCurrent(ctx)
        mod = ctypes.c_void_p()
        try:
            cu.cuModuleLoadData(ctypes.byref(mod), read(os.path.join(HERE, cubin)))
        except RuntimeError as e:  # very old driver: let it JIT the PTX source instead
            print("  cubin not accepted (%s), trying the PTX source" % e)
            cu.cuModuleLoadData(ctypes.byref(mod), read(os.path.join(HERE, cubin.replace(".cubin", ".ptx"))) + b"\0")
        summary = {}
        for vname, vdesc in variants:
            fn = ctypes.c_void_p()
            cu.cuModuleGetFunction(ctypes.byref(fn), mod, ("check_" + vname).encode())
            print("\n  -- instruction: %s" % vdesc)
            print("  %-31s %-8s %-21s %-21s %-21s" % ("suite", "kernel", "= B200 arithmetic", "= H100 (Device 0)", "= Ada model (pips#16)"))
            for suite in suites:
                name, M, N, K, mv, nv, note = suite
                randomized = not (name.startswith("control") or name.startswith("pearl_") or name.startswith("pips16"))
                for window, kname, models in ((0, "chain", ("b200", None, "ada_chain")),
                                              (1, "128-win", ("b200_windowed", "h100", "ada_windowed"))):
                    got = run_check(cu, fn, suite, window)
                    cols = []
                    for tag in models:
                        if tag is None:
                            cols.append("-")
                            continue
                        c, n, t, tn = compare(got, read(os.path.join(DATA, "%s.%s.f32" % (name, tag))), M, N, mv, nv)
                        s = summary.setdefault((vname, tag), [0, 0, 0, 0, 0, 0])
                        s[0] += c; s[1] += n
                        if randomized:
                            s[2] += c; s[3] += n; s[4] += t; s[5] += tn
                        cols.append("%7.3f%% tiles %d/%d" % (100.0 * c / n, t, tn))
                    print("  %-31s %-8s %-21s %-21s %-21s" % (name[:31], kname, cols[0], cols[1], cols[2]))
        print("\n  RESULT for GPU %d (%s):" % (idx, nm.value.decode(errors="replace")))
        for vname, vdesc in variants:
            S = lambda tag: summary[(vname, tag)]
            def all_equal(tag):
                return S(tag)[0] == S(tag)[1]
            b, h = S("b200"), S("h100")
            print("    [%s]" % vdesc)
            print("      as Device=1 (B200, chained kernel): random data %.4f%% of values equal, tiles valid %d/%d"
                  % (100.0 * b[2] / b[3], b[4], b[5]))
            print("      as Device=0 (H100, 128-window kernel): random data %.4f%% of values equal, tiles valid %d/%d"
                  % (100.0 * h[2] / h[3], h[4], h[5]))
            a1, a2 = S("ada_chain"), S("ada_windowed")
            print("      Ada model (pips#16), all suites: chain %.4f%%, windowed %.4f%% of values equal"
                  % (100.0 * a1[0] / a1[1], 100.0 * a2[0] / a2[1]))
            if all_equal("b200"):
                verdict = ("VALID as Device=1 (B200): bit-exact on every value.\n"
                           "         ВЫВОД: карта считает бит в бит как B200 -> её FP8-работа годится для Device=1")
            elif all_equal("h100"):
                verdict = ("VALID as Device=0 (H100): bit-exact on every value.\n"
                           "         ВЫВОД: карта считает бит в бит как H100 -> её FP8-работа годится для Device=0")
            else:
                verdict = ("NOT VALID as Device=0 or Device=1: %d/%d and %d/%d random-data tiles would pass.\n"
                           "         ВЫВОД: FP8-результаты этой инструкции НЕ проходят проверку ни как Device=0 (H100), "
                           "ни как Device=1 (B200)" % (h[4], h[5], b[4], b[5]))
                if all_equal("ada_chain") and all_equal("ada_windowed"):
                    verdict += "\n         (карта считает ровно по модели Ada из pips#16)"
            print("      => " + verdict)
        if opt.bench:
            print("\n  tensor-core throughput, T MAC/s (1 MAC = 2 ops, so TOPS = 2 x this); stop the miner for real numbers:")
            rates = {}
            for bn in benches:
                fn = ctypes.c_void_p()
                cu.cuModuleGetFunction(ctypes.byref(fn), mod, ("bench_" + bn).encode())
                rates[bn] = bench(cu, fn, sms)
                print("    %-6s %8.1f T MAC/s" % (bn, rates[bn]))
            for bn in benches[1:]:
                print("    fp8 (%s) / int8 = %.2f" % (bn, rates[bn] / rates["int8"]))
        cu.cuModuleUnload(mod)
        cu.cuDevicePrimaryCtxRelease_v2(dev.value)
    return 0


if __name__ == "__main__":
    sys.exit(main())
