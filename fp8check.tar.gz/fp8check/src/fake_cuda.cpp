// Fake libcuda.so for testing fp8check.py without a GPU.
// The check kernels are simulated lane by lane: operand loads follow the PTX
// kernel's own address arithmetic (gen_ptx.py), and the mma instruction maps
// registers to matrix elements with NVIDIA CuTe's SM89_16x8x32 E4M3 layouts
// (an independent source). FAKE_SM=89 -> Ada instruction semantics (2 x 16
// products, 14-bit window); FAKE_SM=120 -> Blackwell (32 products, 26-bit window).
#include "fp8models.hpp"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

using namespace fp8;

static int sm() { const char* s = std::getenv("FAKE_SM"); return s ? std::atoi(s) : 89; }
static std::vector<std::string> g_cubin_text;

static float instr(float carry, const uint8_t* a, const uint8_t* b) {  // one m16n8k32 instruction, one cell
    GF v[33];
    v[0] = from_f32(carry);
    if (sm() == 89) {
        for (int u = 0; u < 16; ++u) v[1 + u] = product(a[u], b[u]);
        float s1 = to_f32(group_sum(v, 17, 14));
        v[0] = from_f32(s1);
        for (int u = 0; u < 16; ++u) v[1 + u] = product(a[16 + u], b[16 + u]);
        return to_f32(group_sum(v, 17, 14));
    }
    for (int u = 0; u < 32; ++u) v[1 + u] = product(a[u], b[u]);
    return to_f32(group_sum(v, 33, 26));
}

static float instr16(float carry, const uint8_t* a, const uint8_t* b) {  // one m16n8k16 instruction (sm_89)
    GF v[17];
    v[0] = from_f32(carry);
    for (int u = 0; u < 16; ++u) v[1 + u] = product(a[u], b[u]);
    return to_f32(group_sum(v, 17, 14));
}

static uint32_t ld32(const uint8_t* p) { uint32_t x; std::memcpy(&x, p, 4); return x; }
static uint8_t byte_of(uint32_t r, int i) { return uint8_t(r >> (8 * i)); }

// One warp = one 16x8 tile; mirrors check_<variant> in gen_ptx.py.
static void sim_check16(const uint8_t* A, const uint8_t* B, float* C, uint32_t K, uint32_t N, uint32_t window,
                        unsigned ntile, unsigned mtile);

static void sim_check(const uint8_t* A, const uint8_t* B, float* C, uint32_t K, uint32_t N, uint32_t window,
                      unsigned ntile, unsigned mtile) {
    float d[32][4] = {}, tot[32][4] = {};
    uint32_t atoms = 0;
    for (uint32_t kk = 0; kk < K; kk += 32) {
        uint32_t ra[32][4], rb[32][2];
        for (int lane = 0; lane < 32; ++lane) {          // PTX address arithmetic
            uint32_t g = lane >> 2, t = lane & 3;
            uint32_t row0 = mtile * 16 + g, row1 = row0 + 8, colb = ntile * 8 + g;
            const uint8_t* pa0 = A + uint64_t(row0) * K + t * 4;
            const uint8_t* pa1 = A + uint64_t(row1) * K + t * 4;
            const uint8_t* pb = B + uint64_t(colb) * K + t * 4;
            ra[lane][0] = ld32(pa0 + kk); ra[lane][2] = ld32(pa0 + kk + 16);
            ra[lane][1] = ld32(pa1 + kk); ra[lane][3] = ld32(pa1 + kk + 16);
            rb[lane][0] = ld32(pb + kk);  rb[lane][1] = ld32(pb + kk + 16);
        }
        // CuTe SM89_16x8x32_F32E4M3E4M3F32_TN: thread T = t0 + 4*t1.
        uint8_t At[16][32], Bt[8][32];
        float Cc[16][8];
        for (int T = 0; T < 32; ++T) {
            int t0 = T % 4, t1 = T / 4;
            for (int v = 0; v < 16; ++v) {   // ALayout ((4,8),(4,2,2)) : ((64,1),(16,8,256)) over (M16,K32) col-major
                int v0 = v % 4, v1 = (v / 4) % 2, v2 = v / 8;
                int off = 64 * t0 + 1 * t1 + 16 * v0 + 8 * v1 + 256 * v2;
                At[off % 16][off / 16] = byte_of(ra[T][v / 4], v % 4);
            }
            for (int v = 0; v < 8; ++v) {    // BLayout ((4,8),(4,2)) : ((32,1),(8,128)) over (N8,K32) col-major
                int v0 = v % 4, v1 = v / 4;
                int off = 32 * t0 + 1 * t1 + 8 * v0 + 128 * v1;
                Bt[off % 8][off / 8] = byte_of(rb[T][v / 4], v % 4);
            }
            for (int v = 0; v < 4; ++v) {    // CLayout SM80_16x8_Row ((4,8),(2,2)) : ((32,1),(16,8)) over (M16,N8)
                int v0 = v % 2, v1 = v / 2;
                int off = 32 * t0 + 1 * t1 + 16 * v0 + 8 * v1;
                Cc[off % 16][off / 16] = d[T][v];
            }
        }
        float Dd[16][8];
        for (int m = 0; m < 16; ++m)
            for (int n = 0; n < 8; ++n) Dd[m][n] = instr(Cc[m][n], At[m], Bt[n]);
        for (int T = 0; T < 32; ++T) {
            int t0 = T % 4, t1 = T / 4;
            for (int v = 0; v < 4; ++v) {
                int v0 = v % 2, v1 = v / 2;
                int off = 32 * t0 + 1 * t1 + 16 * v0 + 8 * v1;
                d[T][v] = Dd[off % 16][off / 16];
            }
        }
        if (window) {
            if (++atoms == 4) {
                for (int T = 0; T < 32; ++T)
                    for (int v = 0; v < 4; ++v) { volatile float s = tot[T][v] + d[T][v]; tot[T][v] = s; d[T][v] = 0.0f; }
                atoms = 0;
            }
        }
    }
    if (window) {
        for (int T = 0; T < 32; ++T)
            for (int v = 0; v < 4; ++v) {
                if (atoms) { volatile float s = tot[T][v] + d[T][v]; tot[T][v] = s; }
                d[T][v] = tot[T][v];
            }
    }
    for (int lane = 0; lane < 32; ++lane) {             // PTX store arithmetic
        uint32_t g = lane >> 2, t = lane & 3;
        uint32_t row0 = mtile * 16 + g, row1 = row0 + 8, col = ntile * 8 + t * 2;
        C[uint64_t(row0) * N + col] = d[lane][0];
        C[uint64_t(row0) * N + col + 1] = d[lane][1];
        C[uint64_t(row1) * N + col] = d[lane][2];
        C[uint64_t(row1) * N + col + 1] = d[lane][3];
    }
}

// check_ada16: m16n8k16, CuTe SM80_16x8x16 8-bit layouts: A ((4,8),(4,2)):((64,1),(16,8)) over (M16,K16),
// B SM80_8x16_Row ((4,8),4):((32,1),8) over (N8,K16), C SM80_16x8_Row. 8 instructions per 128-product window.
static void sim_check16(const uint8_t* A, const uint8_t* B, float* C, uint32_t K, uint32_t N, uint32_t window,
                        unsigned ntile, unsigned mtile) {
    float d[32][4] = {}, tot[32][4] = {};
    uint32_t atoms = 0;
    for (uint32_t kk = 0; kk < K; kk += 16) {
        uint32_t ra[32][2], rb[32];
        for (int lane = 0; lane < 32; ++lane) {
            uint32_t g = lane >> 2, t = lane & 3;
            uint32_t row0 = mtile * 16 + g, row1 = row0 + 8, colb = ntile * 8 + g;
            ra[lane][0] = ld32(A + uint64_t(row0) * K + t * 4 + kk);
            ra[lane][1] = ld32(A + uint64_t(row1) * K + t * 4 + kk);
            rb[lane] = ld32(B + uint64_t(colb) * K + t * 4 + kk);
        }
        uint8_t At[16][16], Bt[8][16];
        float Cc[16][8];
        for (int T = 0; T < 32; ++T) {
            int t0 = T % 4, t1 = T / 4;
            for (int v = 0; v < 8; ++v) {
                int v0 = v % 4, v1 = v / 4;
                int off = 64 * t0 + t1 + 16 * v0 + 8 * v1;
                At[off % 16][off / 16] = byte_of(ra[T][v / 4], v % 4);
            }
            for (int v = 0; v < 4; ++v) {
                int off = 32 * t0 + t1 + 8 * v;
                Bt[off % 8][off / 8] = byte_of(rb[T], v);
            }
            for (int v = 0; v < 4; ++v) {
                int v0 = v % 2, v1 = v / 2;
                int off = 32 * t0 + t1 + 16 * v0 + 8 * v1;
                Cc[off % 16][off / 16] = d[T][v];
            }
        }
        float Dd[16][8];
        for (int m = 0; m < 16; ++m)
            for (int n = 0; n < 8; ++n) Dd[m][n] = instr16(Cc[m][n], At[m], Bt[n]);
        for (int T = 0; T < 32; ++T) {
            int t0 = T % 4, t1 = T / 4;
            for (int v = 0; v < 4; ++v) {
                int v0 = v % 2, v1 = v / 2;
                int off = 32 * t0 + t1 + 16 * v0 + 8 * v1;
                d[T][v] = Dd[off % 16][off / 16];
            }
        }
        if (window && ++atoms == 8) {
            for (int T = 0; T < 32; ++T)
                for (int v = 0; v < 4; ++v) { volatile float s = tot[T][v] + d[T][v]; tot[T][v] = s; d[T][v] = 0.0f; }
            atoms = 0;
        }
    }
    if (window)
        for (int T = 0; T < 32; ++T)
            for (int v = 0; v < 4; ++v) {
                if (atoms) { volatile float s = tot[T][v] + d[T][v]; tot[T][v] = s; }
                d[T][v] = tot[T][v];
            }
    for (int lane = 0; lane < 32; ++lane) {
        uint32_t g = lane >> 2, t = lane & 3;
        uint32_t row0 = mtile * 16 + g, row1 = row0 + 8, col = ntile * 8 + t * 2;
        C[uint64_t(row0) * N + col] = d[lane][0];
        C[uint64_t(row0) * N + col + 1] = d[lane][1];
        C[uint64_t(row1) * N + col] = d[lane][2];
        C[uint64_t(row1) * N + col + 1] = d[lane][3];
    }
}

extern "C" {
int cuInit(unsigned) { return 0; }
int cuDriverGetVersion(int* v) { *v = 12080; return 0; }
int cuDeviceGetCount(int* c) { *c = 1; return 0; }
int cuDeviceGet(int* d, int i) { *d = i; return 0; }
int cuDeviceGetName(char* s, int n, int) { std::snprintf(s, n, "%s", sm() == 89 ? "FAKE GeForce RTX 4090" : "FAKE GeForce RTX 5090"); return 0; }
int cuDeviceGetAttribute(int* v, int attr, int) {
    if (attr == 75) *v = sm() == 89 ? 8 : 12;
    else if (attr == 76) *v = sm() == 89 ? 9 : 0;
    else if (attr == 16) *v = sm() == 89 ? 128 : 170;
    else return 1;
    return 0;
}
int cuDevicePrimaryCtxRetain(void** c, int) { *c = (void*)0x1; return 0; }
int cuDevicePrimaryCtxRelease_v2(int) { return 0; }
int cuCtxSetCurrent(void*) { return 0; }
int cuCtxSynchronize() { return 0; }
int cuModuleLoadData(void** m, const char* image) {
    if (std::memcmp(image, "\x7f" "ELF", 4) != 0) return 200;   // CUDA_ERROR_INVALID_IMAGE
    uint64_t shoff; uint16_t shentsize, shnum;   // copy the image, as the real driver does
    std::memcpy(&shoff, image + 0x28, 8); std::memcpy(&shentsize, image + 0x3A, 2); std::memcpy(&shnum, image + 0x3C, 2);
    size_t size = size_t(shoff) + size_t(shnum) * shentsize;
    char* copy = (char*)std::malloc(size); std::memcpy(copy, image, size);
    *m = copy; return 0;
}
int cuModuleUnload(void*) { return 0; }
int cuModuleGetFunction(void** f, void* mod, const char* name) {
    // the cubin's symbol table must contain the name
    const char* img = (const char*)mod;
    std::string needle(name);
    bool found = false;
    uint64_t shoff; uint16_t shentsize, shnum;   // ELF64: size = e_shoff + e_shnum * e_shentsize
    std::memcpy(&shoff, img + 0x28, 8); std::memcpy(&shentsize, img + 0x3A, 2); std::memcpy(&shnum, img + 0x3C, 2);
    size_t size = size_t(shoff) + size_t(shnum) * shentsize;
    for (size_t i = 0; i + needle.size() + 1 <= size && !found; ++i) found = std::memcmp(img + i, needle.c_str(), needle.size() + 1) == 0;
    if (!found) return 500;  // CUDA_ERROR_NOT_FOUND
    *f = strdup(name); return 0;
}
int cuMemAlloc_v2(uint64_t* p, size_t n) { *p = (uint64_t)std::malloc(n); return 0; }
int cuMemFree_v2(uint64_t p) { std::free((void*)p); return 0; }
int cuMemcpyHtoD_v2(uint64_t d, const void* h, size_t n) { std::memcpy((void*)d, h, n); return 0; }
int cuMemcpyDtoH_v2(void* h, uint64_t d, size_t n) { std::memcpy(h, (void*)d, n); return 0; }
int cuMemsetD8_v2(uint64_t d, unsigned char v, size_t n) { std::memset((void*)d, v, n); return 0; }
int cuLaunchKernel(void* f, unsigned gx, unsigned gy, unsigned, unsigned bx, unsigned, unsigned, unsigned, void*, void** params, void**) {
    std::string name((const char*)f);
    if (name.rfind("check_", 0) == 0) {
        if (bx != 32) return 1;
        const uint8_t* A = *(const uint8_t**)params[0];
        const uint8_t* B = *(const uint8_t**)params[1];
        float* C = *(float**)params[2];
        uint32_t K = *(uint32_t*)params[3], N = *(uint32_t*)params[4], W = *(uint32_t*)params[5];
        for (unsigned y = 0; y < gy; ++y)
            for (unsigned x = 0; x < gx; ++x) {
                if (name == "check_ada16") sim_check16(A, B, C, K, N, W, x, y);
                else sim_check(A, B, C, K, N, W, x, y);
            }
    }
    return 0;
}
int cuEventCreate(void** e, unsigned) { *e = std::malloc(1); return 0; }
int cuEventRecord(void*, void*) { return 0; }
int cuEventSynchronize(void*) { return 0; }
int cuEventElapsedTime(float* ms, void*, void*) { *ms = 10.0f; return 0; }
int cuEventDestroy_v2(void* e) { std::free(e); return 0; }
int cuGetErrorString(int, const char** s) { *s = "fake error"; return 0; }
}
