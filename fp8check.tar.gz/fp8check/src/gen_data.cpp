// Generate test inputs and the expected outputs of every arithmetic model.
// usage: gen_data <vectors.txt> <outdir>
#include "fp8models.hpp"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <random>
#include <sstream>
#include <string>

using namespace fp8;

static uint8_t encode_e4m3_rne(double x) {
    static double lv[127];
    static bool init = false;
    if (!init) { for (int c = 0; c < 127; ++c) lv[c] = decode_e4m3(uint8_t(c)); init = true; }
    double mag = std::fabs(x);
    uint8_t code;
    if (mag >= lv[126]) code = 126;
    else {
        int lo = int(std::upper_bound(lv, lv + 127, mag) - lv) - 1;
        double mid = 0.5 * (lv[lo] + lv[lo + 1]);
        code = mag < mid ? uint8_t(lo) : mag > mid ? uint8_t(lo + 1) : uint8_t((lo & 1) ? lo + 1 : lo);
    }
    if (std::signbit(x) && code != 0) code |= 0x80;
    return code;
}

static std::vector<uint8_t> hexbytes(const std::string& s) {
    std::vector<uint8_t> v;
    for (size_t i = 0; i + 1 < s.size(); i += 2) v.push_back(uint8_t(std::stoul(s.substr(i, 2), nullptr, 16)));
    return v;
}

struct Suite { std::string name, note; int M, N, K, mv, nv; std::vector<uint8_t> a, b; };

static void write_file(const std::string& path, const void* p, size_t n) {
    std::ofstream f(path, std::ios::binary); f.write(static_cast<const char*>(p), std::streamsize(n));
}

int main(int argc, char** argv) {
    if (argc < 3) { std::fprintf(stderr, "usage: gen_data vectors.txt outdir\n"); return 2; }
    std::string out = argv[2];
    std::vector<Suite> suites;

    // Official vectors, each zero-padded into one 16 x 8 mma tile (padding cells are +0 in every model).
    {
        std::ifstream in(argv[1]); std::string head; int nb = 0, na = 0;
        while (std::getline(in, head)) {
            std::istringstream hs(head); std::string kind; int m, n, k; hs >> kind >> m >> n >> k;
            std::string sa, sb, s3, s4; std::getline(in, sa); std::getline(in, sb); std::getline(in, s3); std::getline(in, s4);
            bool use = (kind == "ADA") || (kind == "B200" && s3 == "-" && k % 32 == 0);
            int idx = kind == "ADA" ? na++ : nb++;
            if (!use) continue;
            Suite s; s.M = 16; s.N = 8; s.K = k; s.mv = m; s.nv = n;
            s.name = (kind == "ADA" ? "pips16_ada_silicon_" : "pearl_b200_vector_") + std::to_string(idx);
            s.note = kind == "ADA" ? "pips#16 vector measured on RTX 4070 Ti SUPER" : "Pearl utils.rs B200_FP8_VECTORS";
            s.a.assign(size_t(16) * k, 0); s.b.assign(size_t(8) * k, 0);
            auto a = hexbytes(sa), b = hexbytes(sb);
            for (int i = 0; i < m; ++i) std::copy(a.begin() + size_t(i) * k, a.begin() + size_t(i + 1) * k, s.a.begin() + size_t(i) * k);
            for (int j = 0; j < n; ++j) std::copy(b.begin() + size_t(j) * k, b.begin() + size_t(j + 1) * k, s.b.begin() + size_t(j) * k);
            suites.push_back(s);
        }
    }
    auto random_suite = [&](const std::string& name, const std::string& dist, int M, int N, int K, uint64_t seed) {
        Suite s; s.name = name; s.note = dist; s.M = M; s.N = N; s.K = K; s.mv = M; s.nv = N;
        s.a.resize(size_t(M) * K); s.b.resize(size_t(N) * K);
        std::mt19937_64 rng(seed); std::normal_distribution<double> g(0.0, 1.0);
        for (auto* v : {&s.a, &s.b})
            for (auto& c : *v) {
                if (dist == "ints") { const uint8_t t[7] = {0x00, 0x38, 0xB8, 0x40, 0xC0, 0x48, 0xC8}; c = t[rng() % 7]; }
                else if (dist == "gauss1") c = encode_e4m3_rne(g(rng));
                else if (dist == "gauss100") c = encode_e4m3_rne(100.0 * g(rng));
                else { do { c = uint8_t(rng()); } while ((c & 0x7F) == 0x7F); }
            }
        suites.push_back(s);
    };
    random_suite("control_small_integers_k4096", "ints", 64, 64, 4096, 11);
    random_suite("gauss_sigma1_k4096", "gauss1", 64, 64, 4096, 12);
    random_suite("gauss_sigma100_k4096", "gauss100", 128, 128, 4096, 13);
    random_suite("uniform_codes_k4096", "uniform", 64, 64, 4096, 14);
    random_suite("gauss_sigma100_k16384", "gauss100", 64, 64, 16384, 15);

    const Model models[] = {Model::B200, Model::AdaChain, Model::H100, Model::AdaWindowed, Model::B200Windowed};
    const char* tags[] = {"b200", "ada_chain", "h100", "ada_windowed", "b200_windowed"};
    std::ofstream man(out + "/manifest.txt");
    man << "# name M N K m_valid n_valid note\n";
    for (auto& s : suites) {
        write_file(out + "/" + s.name + ".a", s.a.data(), s.a.size());
        write_file(out + "/" + s.name + ".b", s.b.data(), s.b.size());
        for (int mi = 0; mi < 5; ++mi) {
            std::vector<float> c(size_t(s.M) * s.N);
            #pragma omp parallel for schedule(dynamic)
            for (int i = 0; i < s.M; ++i)
                for (int j = 0; j < s.N; ++j)
                    c[size_t(i) * s.N + j] = cell(models[mi], &s.a[size_t(i) * s.K], &s.b[size_t(j) * s.K], s.K);
            write_file(out + "/" + s.name + "." + tags[mi] + ".f32", c.data(), c.size() * 4);
        }
        man << s.name << " " << s.M << " " << s.N << " " << s.K << " " << s.mv << " " << s.nv << " " << s.note << "\n";
        std::printf("%-34s %4d x %4d x %5d  %s\n", s.name.c_str(), s.M, s.N, s.K, s.note.c_str());
    }
    return 0;
}
