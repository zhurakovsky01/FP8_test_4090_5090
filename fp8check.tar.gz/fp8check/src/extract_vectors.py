"""Extract official test vectors (data only) from Pearl utils.rs and pips#16 ada_fp8_vectors.rs into JSON.

Nothing from the source files is executed: the Rust text is parsed with regexes.
"""
import json
import re
import sys

def parse_struct_blocks(text, struct_name):
    blocks = []
    for m in re.finditer(struct_name + r"\s*\{", text):
        i = m.end()
        depth = 1
        j = i
        while depth:
            c = text[j]
            if c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
            j += 1
        blocks.append(text[i:j - 1])
    return blocks

def field_int(block, name):
    return int(re.search(r"\b" + name + r":\s*(\d+)", block).group(1))

def field_arr(block, name):
    m = re.search(r"\b" + name + r":\s*(?:Some\()?&\[(.*?)\]", block, re.S)
    if not m:
        return None
    return [int(x, 16) for x in re.findall(r"0x[0-9A-Fa-f]+", m.group(1))]

def field_is_none(block, name):
    return re.search(r"\b" + name + r":\s*None", block) is not None

out = {}
utils = open(sys.argv[1]).read()
start = utils.index("const B200_FP8_VECTORS")
seg = utils[start:utils.index("];", start)]
b200 = []
for blk in parse_struct_blocks(seg, "B200Vector"):
    v = dict(m=field_int(blk, "m"), n=field_int(blk, "n"), k=field_int(blk, "k"),
             a=field_arr(blk, "a"), b=field_arr(blk, "b"),
             c=None if field_is_none(blk, "c") else field_arr(blk, "c"),
             expected=field_arr(blk, "expected"))
    assert len(v["a"]) == v["m"] * v["k"] and len(v["b"]) == v["n"] * v["k"], v
    assert len(v["expected"]) == v["m"] * v["n"]
    if v["c"] is not None:
        assert len(v["c"]) == v["m"] * v["n"]
    b200.append(v)
out["b200"] = b200

ada_text = open(sys.argv[2]).read()
ada = []
for blk in parse_struct_blocks(ada_text, "AdaVector"):
    v = dict(m=field_int(blk, "m"), n=field_int(blk, "n"), k=field_int(blk, "k"),
             a=field_arr(blk, "a"), b=field_arr(blk, "b"),
             expected=field_arr(blk, "expected"), h100=field_arr(blk, "h100"))
    assert len(v["a"]) == v["m"] * v["k"] and len(v["b"]) == v["n"] * v["k"], (v["m"], v["n"], v["k"], len(v["a"]))
    assert len(v["expected"]) == v["m"] * v["n"] == len(v["h100"])
    ada.append(v)
out["ada_silicon"] = ada
json.dump(out, open(sys.argv[3], "w"))
print("b200 vectors:", len(b200), [(v["m"], v["n"], v["k"], v["c"] is not None) for v in b200])
print("ada silicon vectors:", len(ada), [(v["m"], v["n"], v["k"]) for v in ada])
