// Sanity check that the official vectors actually discriminate: deliberately wrong
// model parameters must FAIL them (otherwise "passes the vectors" would mean nothing).
#include "fp8models.hpp"
#include <cstdio>
#include <fstream>
#include <sstream>
#include <string>
using namespace fp8;
static std::vector<uint8_t> hb(const std::string& s) { std::vector<uint8_t> v; for (size_t i = 0; i + 1 < s.size(); i += 2) v.push_back(uint8_t(std::stoul(s.substr(i, 2), nullptr, 16))); return v; }
static std::vector<uint32_t> hw(const std::string& s) { std::vector<uint32_t> v; std::istringstream is(s); std::string w; while (is >> w) v.push_back(uint32_t(std::stoul(w, nullptr, 16))); return v; }
int main() {
    struct V { std::string kind; int m, n, k; std::vector<uint8_t> a, b; std::vector<uint32_t> c, e3, e4; bool hasc; };
    std::vector<V> vs; std::ifstream in("vectors.txt"); std::string h;
    while (std::getline(in, h)) { V v; std::istringstream hs(h); hs >> v.kind >> v.m >> v.n >> v.k; std::string a, b, s3, s4; std::getline(in, a); std::getline(in, b); std::getline(in, s3); std::getline(in, s4);
        v.a = hb(a); v.b = hb(b); v.hasc = s3 != "-"; if (v.hasc) v.c = hw(s3); v.e4 = hw(s4); vs.push_back(v); }
    struct P { const char* name; int group, width, window; };
    const P b200[] = {{"B200 official (32, w26, chain)", 32, 26, 0}, {"group 16", 16, 26, 0}, {"width 25", 32, 25, 0}, {"width 27", 32, 27, 0}, {"width 24", 32, 24, 0}};
    for (auto& p : b200) {
        int bad = 0, tot = 0;
        for (auto& v : vs) if (v.kind == "B200")
            for (int i = 0; i < v.m; ++i) for (int j = 0; j < v.n; ++j) {
                float carry = v.hasc ? u2f(v.c[i * v.n + j]) : 0.0f;
                float r = chain_cell(&v.a[i * v.k], &v.b[j * v.k], v.k, p.group, p.width, carry);
                ++tot; bad += f2u(r) != v.e4[i * v.n + j];
            }
        std::printf("%-34s vs official B200 vectors: %d/%d cells wrong\n", p.name, bad, tot);
    }
    const P ada[] = {{"Ada pips#16 (16, w14, 128-win)", 16, 14, 128}, {"group 32 (= H100)", 32, 14, 128}, {"group 8", 8, 14, 128}, {"width 13", 16, 13, 128}, {"width 15", 16, 15, 128}, {"window 256", 16, 14, 256}};
    for (auto& p : ada) {
        int bad = 0, tot = 0;
        for (auto& v : vs) if (v.kind == "ADA")
            for (int i = 0; i < v.m; ++i) for (int j = 0; j < v.n; ++j) {
                float r = windowed_cell(&v.a[i * v.k], &v.b[j * v.k], v.k, p.group, p.width, p.window);
                ++tot; bad += f2u(r) != v.e4[i * v.n + j];
            }
        std::printf("%-34s vs Ada silicon vectors:    %d/%d cells wrong\n", p.name, bad, tot);
    }
}
