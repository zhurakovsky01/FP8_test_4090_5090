// Validate fp8models.hpp against official vectors and Pearl/pips#16 unit tests.
#include "fp8models.hpp"
#include <cstdio>
#include <fstream>
#include <sstream>
#include <string>

using namespace fp8;

static int failures = 0, checks = 0;
static void expect_bits(const char* what, float got, uint32_t want) {
    ++checks;
    if (f2u(got) != want) { ++failures; std::printf("FAIL %s: got %08x want %08x\n", what, f2u(got), want); }
}
static std::vector<uint8_t> hexbytes(const std::string& s) {
    std::vector<uint8_t> v;
    for (size_t i = 0; i + 1 < s.size(); i += 2) v.push_back(uint8_t(std::stoul(s.substr(i, 2), nullptr, 16)));
    return v;
}
static std::vector<uint32_t> hexwords(const std::string& s) {
    std::vector<uint32_t> v; std::istringstream is(s); std::string w;
    while (is >> w) v.push_back(uint32_t(std::stoul(w, nullptr, 16)));
    return v;
}

int main(int argc, char** argv) {
    // 1) Official vectors (B200 from Pearl utils.rs; Ada silicon + H100 from pips#16).
    std::ifstream in(argc > 1 ? argv[1] : "vectors.txt");
    std::string head;
    int nb = 0, na = 0;
    while (std::getline(in, head)) {
        std::istringstream hs(head); std::string kind; int m, n, k; hs >> kind >> m >> n >> k;
        std::string sa, sb, s3, s4;
        std::getline(in, sa); std::getline(in, sb); std::getline(in, s3); std::getline(in, s4);
        auto a = hexbytes(sa), b = hexbytes(sb);
        if (kind == "B200") {
            std::vector<float> c; bool has_c = s3 != "-";
            if (has_c) for (auto w : hexwords(s3)) c.push_back(u2f(w));
            auto exp = hexwords(s4);
            auto out = matmul(Model::B200, a, b, m, n, k, has_c ? &c : nullptr);
            for (size_t i = 0; i < out.size(); ++i) {
                char what[96]; std::snprintf(what, sizeof what, "B200 vector %d cell %zu", nb, i);
                expect_bits(what, out[i], exp[i]);
            }
            ++nb;
        } else {
            auto h100 = hexwords(s3), silicon = hexwords(s4);
            auto ada = matmul(Model::AdaWindowed, a, b, m, n, k);
            auto hop = matmul(Model::H100, a, b, m, n, k);
            bool differs = false;
            for (size_t i = 0; i < ada.size(); ++i) {
                char what[96];
                std::snprintf(what, sizeof what, "Ada silicon vector %d cell %zu", na, i);
                expect_bits(what, ada[i], silicon[i]);
                std::snprintf(what, sizeof what, "H100 replay of Ada vector %d cell %zu", na, i);
                expect_bits(what, hop[i], h100[i]);
                differs |= f2u(hop[i]) != silicon[i];
            }
            ++checks; if (!differs) { ++failures; std::printf("FAIL Ada vector %d does not separate Ada from H100\n", na); }
            ++na;
        }
    }
    std::printf("official vectors: %d B200, %d Ada-silicon\n", nb, na);

    // 2) Pearl's own H100 unit tests (utils.rs).
    {
        int k = 1024; std::vector<uint8_t> a(k, 0), b(k, 0x38);
        for (int i = 0; i < 128; ++i) a[i] = 0x78;
        for (int i = 128; i < 256; ++i) a[i] = 0x38;
        expect_bits("h100 resets every four atoms (32896)", cell(Model::H100, a.data(), b.data(), k), f2u(32896.0f));
        expect_bits("old continuous 14-bit chain (32768)", chain_cell(a.data(), b.data(), k, 32, 14, 0.0f), f2u(32768.0f));
        expect_bits("pips#16: Ada agrees on Pearl promotion vector", cell(Model::AdaWindowed, a.data(), b.data(), k), f2u(32896.0f));
    }
    for (auto [k, expected] : {std::pair{1056, 32.0f}, {1088, 64.0f}, {1120, 96.0f}, {1152, 128.0f}}) {
        std::vector<uint8_t> a(k, 0), b(k, 0x38);
        for (int i = 1024; i < k; ++i) a[i] = 0x38;
        expect_bits("h100 partial windows", cell(Model::H100, a.data(), b.data(), k), f2u(expected));
    }
    {
        int k = 1024; std::vector<uint8_t> a(k, 0), b(k, 0x38); a[0] = 0x78; a[1] = 0xF8;
        expect_bits("h100 canonical zero", cell(Model::H100, a.data(), b.data(), k), 0);
    }
    {
        int k = 256; std::vector<uint8_t> a(k, 0x38), b(k, 0x38);
        expect_bits("h100 256 ones", cell(Model::H100, a.data(), b.data(), k), f2u(256.0f));
    }
    // 3) Pearl's own B200 unit tests (utils.rs).
    {
        std::vector<uint8_t> a(32, 0), b(32, 0); a[0] = 0x38; a[1] = 0x01; b[0] = 0x38; b[1] = 0x01;
        expect_bits("b200 keeps 1 + 2^-18", cell(Model::B200, a.data(), b.data(), 32), 0x3F800020);
        std::vector<uint8_t> z(32, 0);
        expect_bits("b200 subnormal carry 2^-127", chain_cell(z.data(), z.data(), 32, 32, 26, u2f(0x00400000)), 0x00400000);
        expect_bits("b200 subnormal carry 2^-140", chain_cell(z.data(), z.data(), 32, 32, 26, u2f(0x00000200)), 0x00000200);
    }
    {   // group boundaries align to 32 products: full == chained per 32 with carry-in
        int m = 2, n = 2, k = 96; std::vector<uint8_t> a(m * k), b(n * k);
        const uint8_t pa[5] = {0x00, 0x38, 0xB0, 0x42, 0x2C}, pb[5] = {0x38, 0x00, 0x3C, 0xB4, 0x29};
        for (int i = 0; i < m * k; ++i) a[i] = pa[i % 5];
        for (int i = 0; i < n * k; ++i) b[i] = pb[i % 5];
        auto full = matmul(Model::B200, a, b, m, n, k);
        std::vector<float> acc(m * n, 0.0f);
        for (int col = 0; col < k; col += 32) {
            std::vector<uint8_t> at, bt;
            for (int i = 0; i < m; ++i) at.insert(at.end(), a.begin() + i * k + col, a.begin() + i * k + col + 32);
            for (int j = 0; j < n; ++j) bt.insert(bt.end(), b.begin() + j * k + col, b.begin() + j * k + col + 32);
            acc = matmul(Model::B200, at, bt, m, n, 32, &acc);
        }
        for (int i = 0; i < m * n; ++i) expect_bits("b200 chained == full", acc[i], f2u(full[i]));
    }
    // 4) pips#16 single-atom silicon vector and noise atom.
    {
        auto a = hexbytes("3234b828bbc59a38a62a3f1a3bb9a6bc36a9b6b4223a3b88aaba3b3c2b363bab");
        auto b = hexbytes("b0382a291c3da4a7b133bcb93c360eab3d39afb5ae123db5289737211d2ab9b5");
        expect_bits("pips#16 single atom silicon (Ada)", cell(Model::AdaWindowed, a.data(), b.data(), 32), 0xBFC2B000);
        expect_bits("pips#16 single atom silicon (Ada chain)", cell(Model::AdaChain, a.data(), b.data(), 32), 0xBFC2B000);
        expect_bits("pips#16 single atom (H100)", cell(Model::H100, a.data(), b.data(), 32), 0xBFC2A800);
        auto e = hexbytes("be3adfead867e55be469dd50e9e85c50dfdc64e2dfe4eae2e8d6596a6746dd65");
        auto f = hexbytes("c65268603369d96362e16a5f6ae6615fe6db43eae463e2d3eae55ae3bb5f54e3");
        expect_bits("pips#16 noise atom (H100)", cell(Model::H100, e.data(), f.data(), 32), 1161306112u);
        expect_bits("pips#16 noise atom (Ada)", cell(Model::AdaWindowed, e.data(), f.data(), 32), 1161306112u);
    }
    std::printf("%d checks, %d failures\n", checks, failures);
    return failures ? 1 : 0;
}
