"""Generate the PTX for the FP8 MMA bit-exactness test and the MMA throughput bench.

Kernels (one warp per 16x8 output tile, operands read straight from global memory
in the PTX-documented m16n8k32 fragment layout):

  check_<v>(A, B, C, K, N, window)
      A: M x K e4m3 bytes, row-major.  B: N x K e4m3 bytes, row-major (transposed operand).
      C: M x N float32.  window = 0: chain d = mma(a, b, d) over all of k (what Cyberminer does).
      window = 1: H100-style structure, restart every 128 products and add to an FP32 total.
  bench_<v>(iters, out)      tensor-core throughput, 8 independent accumulators per warp.

Variants:
  ada    mma.sync.aligned.m16n8k32.row.col.f32.e4m3.e4m3.f32            (sm_89 and sm_120)
  cyber  Cyberminer's multiply32(): kind::mxf8f6f4.block_scale, unit scales (sm_120a only)
  ada16  mma.sync.aligned.m16n8k16.row.col.f32.e4m3.e4m3.f32            (sm_89; the other FP32-accumulate FP8 shape)
  int8   mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32 (bench only, reference rate)
"""
import sys

MMA = {
    "ada": "mma.sync.aligned.m16n8k32.row.col.f32.e4m3.e4m3.f32 {D}, {A}, {B}, {C};",
    # Copied from Cyberminer src/sm120_primitives.cuh multiply32(): scale bytes 0x7f = 2^0, selector 0.
    "cyber": ("mma.sync.aligned.kind::mxf8f6f4.block_scale.scale_vec::1X.m16n8k32.row.col.f32.e4m3.e4m3.f32.ue8m0 "
              "{D}, {A}, {B}, {C}, {{%rones}}, {{%hsel, %hsel}}, {{%rones}}, {{%hsel, %hsel}};"),
    "int8": "mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32 {D}, {A}, {B}, {C};",
    # the other FP32-accumulating FP8 MMA shape that sm_89 has (16 products per instruction)
    "ada16": "mma.sync.aligned.m16n8k16.row.col.f32.e4m3.e4m3.f32 {D}, {A}, {B}, {C};",
}

def mma(variant, d, a, b, c):
    return MMA[variant].format(D=d, A=a, B=b, C=c)

def check_kernel(variant):
    acc = "{%f1, %f2, %f3, %f4}"
    if variant == "ada16":   # m16n8k16: A = 2 regs (rows g, g+8; k = t*4..), B = 1 reg (col g; k = t*4..)
        body = f"""    add.u64 %rd12, %rd6, %rd11;
    ld.global.u32 %r20, [%rd12];      // a0: row g,   k = t*4 .. t*4+3
    add.u64 %rd13, %rd8, %rd11;
    ld.global.u32 %r21, [%rd13];      // a1: row g+8, k = t*4 ..
    add.u64 %rd14, %rd10, %rd11;
    ld.global.u32 %r24, [%rd14];      // b0: col g,   k = t*4 ..
    {mma(variant, acc, "{%r20, %r21}", "{%r24}", acc)}
    add.u32 %r13, %r13, 16;"""
        per_window = 8               # 128 products = 8 instructions
    else:
        body = f"""    add.u64 %rd12, %rd6, %rd11;
    ld.global.u32 %r20, [%rd12];      // a0: row g,   k = t*4 .. t*4+3
    ld.global.u32 %r22, [%rd12+16];   // a2: row g,   k = 16+t*4 ..
    add.u64 %rd13, %rd8, %rd11;
    ld.global.u32 %r21, [%rd13];      // a1: row g+8, k = t*4 ..
    ld.global.u32 %r23, [%rd13+16];   // a3: row g+8, k = 16+t*4 ..
    add.u64 %rd14, %rd10, %rd11;
    ld.global.u32 %r24, [%rd14];      // b0: col g,   k = t*4 ..
    ld.global.u32 %r25, [%rd14+16];   // b1: col g,   k = 16+t*4 ..
    {mma(variant, acc, "{%r20, %r21, %r22, %r23}", "{%r24, %r25}", acc)}
    add.u32 %r13, %r13, 32;"""
        per_window = 4               # 128 products = 4 instructions
    return f"""
.visible .entry check_{variant}(
    .param .u64 pA, .param .u64 pB, .param .u64 pC,
    .param .u32 pK, .param .u32 pN, .param .u32 pWindow)
{{
    .reg .b32 %r<40>;
    .reg .b64 %rd<24>;
    .reg .f32 %f<12>;
    .reg .pred %p<6>;
    .reg .b32 %rones;
    .reg .b16 %hsel;
    mov.b32 %rones, 0x7f7f7f7f;
    mov.b16 %hsel, 0;

    ld.param.u64 %rd1, [pA];
    ld.param.u64 %rd2, [pB];
    ld.param.u64 %rd3, [pC];
    ld.param.u32 %r1, [pK];
    ld.param.u32 %r2, [pN];
    ld.param.u32 %r3, [pWindow];
    cvta.to.global.u64 %rd1, %rd1;
    cvta.to.global.u64 %rd2, %rd2;
    cvta.to.global.u64 %rd3, %rd3;

    mov.u32 %r4, %tid.x;          // lane
    shr.u32 %r5, %r4, 2;          // groupID g
    and.b32 %r6, %r4, 3;          // threadID_in_group t
    mov.u32 %r7, %ctaid.x;        // tile column (n / 8)
    mov.u32 %r8, %ctaid.y;        // tile row    (m / 16)
    mad.lo.u32 %r9, %r8, 16, %r5; // row g
    add.u32 %r10, %r9, 8;         // row g + 8
    mad.lo.u32 %r11, %r7, 8, %r5; // column g (row g of the transposed B)
    shl.b32 %r12, %r6, 2;         // t * 4
    cvt.u64.u32 %rd5, %r12;
    mul.wide.u32 %rd4, %r9, %r1;
    add.u64 %rd4, %rd4, %rd5;
    add.u64 %rd6, %rd1, %rd4;     // &A[g][t*4]
    mul.wide.u32 %rd7, %r10, %r1;
    add.u64 %rd7, %rd7, %rd5;
    add.u64 %rd8, %rd1, %rd7;     // &A[g+8][t*4]
    mul.wide.u32 %rd9, %r11, %r1;
    add.u64 %rd9, %rd9, %rd5;
    add.u64 %rd10, %rd2, %rd9;    // &Bt[g][t*4]

    mov.f32 %f1, 0f00000000; mov.f32 %f2, 0f00000000; mov.f32 %f3, 0f00000000; mov.f32 %f4, 0f00000000;
    mov.f32 %f5, 0f00000000; mov.f32 %f6, 0f00000000; mov.f32 %f7, 0f00000000; mov.f32 %f8, 0f00000000;
    mov.u32 %r13, 0;              // k offset
    mov.u32 %r14, 0;              // atoms in the current 128-product window
LOOP:
    setp.ge.u32 %p1, %r13, %r1;
    @%p1 bra DONE;
    cvt.u64.u32 %rd11, %r13;
{body}
    setp.eq.u32 %p2, %r3, 0;
    @%p2 bra LOOP;                     // chain mode
    add.u32 %r14, %r14, 1;
    setp.lt.u32 %p3, %r14, {per_window};
    @%p3 bra LOOP;
    add.rn.f32 %f5, %f5, %f1; add.rn.f32 %f6, %f6, %f2; add.rn.f32 %f7, %f7, %f3; add.rn.f32 %f8, %f8, %f4;
    mov.f32 %f1, 0f00000000; mov.f32 %f2, 0f00000000; mov.f32 %f3, 0f00000000; mov.f32 %f4, 0f00000000;
    mov.u32 %r14, 0;
    bra LOOP;
DONE:
    setp.eq.u32 %p2, %r3, 0;
    @%p2 bra STORE;
    setp.eq.u32 %p3, %r14, 0;
    @%p3 bra TOTAL;
    add.rn.f32 %f5, %f5, %f1; add.rn.f32 %f6, %f6, %f2; add.rn.f32 %f7, %f7, %f3; add.rn.f32 %f8, %f8, %f4;
TOTAL:
    mov.f32 %f1, %f5; mov.f32 %f2, %f6; mov.f32 %f3, %f7; mov.f32 %f4, %f8;
STORE:
    // c0,c1: row g, cols t*2, t*2+1;  c2,c3: row g+8, same cols
    mul.lo.u32 %r30, %r7, 8;          // n0 = tile column * 8
    shl.b32 %r31, %r6, 1;             // t*2
    add.u32 %r30, %r30, %r31;         // column n0 + t*2
    mad.lo.u32 %r32, %r9, %r2, %r30;  // row g * N + col
    mad.lo.u32 %r33, %r10, %r2, %r30; // row (g+8) * N + col
    mul.wide.u32 %rd15, %r32, 4;
    add.u64 %rd16, %rd3, %rd15;
    st.global.f32 [%rd16], %f1;
    st.global.f32 [%rd16+4], %f2;
    mul.wide.u32 %rd17, %r33, 4;
    add.u64 %rd18, %rd3, %rd17;
    st.global.f32 [%rd18], %f3;
    st.global.f32 [%rd18+4], %f4;
    ret;
}}
"""

def bench_kernel(variant):
    is_int = variant == "int8"
    regtype = "b32"
    lines = []
    for s in range(8):
        lines.append("    " + mma(variant, f"{{%x{s}a, %x{s}b, %x{s}c, %x{s}d}}", "{%a0, %a1, %a2, %a3}", "{%b0, %b1}",
                                     f"{{%x{s}a, %x{s}b, %x{s}c, %x{s}d}}"))
    regs = "\n".join(f"    .reg .{regtype} %x{s}a, %x{s}b, %x{s}c, %x{s}d;" for s in range(8))
    zero = "\n".join(f"    mov.b32 %x{s}a, 0; mov.b32 %x{s}b, 0; mov.b32 %x{s}c, 0; mov.b32 %x{s}d, 0;" for s in range(8))
    fold = []
    for s in range(8):
        for q in "abcd":
            fold.append(f"    xor.b32 %acc, %acc, %x{s}{q};")
    body = "\n".join(lines)
    return f"""
.visible .entry bench_{variant}(.param .u32 pIters, .param .u32 pSeed, .param .u64 pOut)
{{
    .reg .b32 %a0, %a1, %a2, %a3, %b0, %b1, %it, %n, %acc, %seed, %rones;
    .reg .b16 %hsel;
    .reg .b64 %o, %idx;
    .reg .pred %p;
{regs}
    mov.b32 %rones, 0x7f7f7f7f;
    mov.b16 %hsel, 0;
    ld.param.u32 %n, [pIters];
    ld.param.u32 %seed, [pSeed];
    // operands: small finite values derived from the seed (never NaN): 0x3a3a3a3a-like codes
    and.b32 %seed, %seed, 0x07070707;
    or.b32  %a0, %seed, 0x30303030; mov.b32 %a1, %a0; mov.b32 %a2, %a0; mov.b32 %a3, %a0;
    mov.b32 %b0, %a0; mov.b32 %b1, %a0;
{zero}
    mov.u32 %it, 0;
BL:
{body}
    add.u32 %it, %it, 1;
    setp.lt.u32 %p, %it, %n;
    @%p bra BL;
    mov.b32 %acc, 0;
{chr(10).join(fold)}
    ld.param.u64 %o, [pOut];
    cvta.to.global.u64 %o, %o;
    atom.global.xor.b32 %acc, [%o], %acc;
    ret;
}}
"""

def module(target, version, variants, bench):
    out = [f"//\n// FP8 MMA check, generated by gen_ptx.py\n//\n.version {version}\n.target {target}\n.address_size 64\n"]
    for v in variants:
        out.append(check_kernel(v))
    for v in bench:
        out.append(bench_kernel(v))
    return "\n".join(out)

if __name__ == "__main__":
    which = sys.argv[1]
    if which == "sm89":
        print(module("sm_89", "8.7", ["ada", "ada16"], ["ada", "int8"]))
    elif which == "sm120a":
        print(module("sm_120a", "8.7", ["ada", "cyber"], ["ada", "cyber", "int8"]))
    elif which == "sm89_cyber":   # expected to FAIL: Cyberminer's instruction does not exist on Ada
        print(module("sm_89", "8.7", ["cyber"], []))
    else:
        raise SystemExit("usage: gen_ptx.py sm89|sm120a|sm89_cyber")
