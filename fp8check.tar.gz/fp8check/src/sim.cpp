// CPU simulation: what an Ada (RTX 4090) port computes vs what Pearl's
// validator replays for Device = 1 (B200) and Device = 0 (H100).
//
//  * "Cyberminer ported to Ada": the kernel chains d = mma(a, b, d) over k, as
//    Cyberminer does on Blackwell. On Ada each mma collapses 2 x 16 products at a
//    14-bit window (pips#16, verified on silicon) -> Model::AdaChain.
//    The validator for Device = 1 replays Model::B200.
//  * "Hopper-structured kernel on Ada": restart every 128 products and promote
//    in FP32 -> Model::AdaWindowed. The validator for Device = 0 replays Model::H100.
//
// usage: sim <dist> <k> <seeds> [m n]
#include "fp8models.hpp"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <random>
#include <string>

using namespace fp8;

static uint8_t encode_e4m3_rne(double x) {
    // finite, saturating to +-448; round to nearest, ties to even code
    static double lv[127];
    static bool init = false;
    if (!init) { for (int c = 0; c < 127; ++c) lv[c] = decode_e4m3(uint8_t(c)); init = true; }
    double mag = std::fabs(x);
    uint8_t code;
    if (mag >= lv[126]) code = 126;
    else {
        int lo = int(std::upper_bound(lv, lv + 127, mag) - lv) - 1;  // lv[lo] <= mag < lv[lo+1]
        double mid = 0.5 * (lv[lo] + lv[lo + 1]);
        if (mag < mid) code = uint8_t(lo);
        else if (mag > mid) code = uint8_t(lo + 1);
        else code = uint8_t((lo & 1) ? lo + 1 : lo);
    }
    if (std::signbit(x) && code != 0) code |= 0x80;
    return code;
}

static void fill(std::vector<uint8_t>& v, const std::string& dist, std::mt19937_64& rng) {
    std::normal_distribution<double> g(0.0, 1.0);
    for (auto& c : v) {
        if (dist == "gauss1") c = encode_e4m3_rne(g(rng));
        else if (dist == "gauss100") c = encode_e4m3_rne(100.0 * g(rng));
        else if (dist == "uniform") { do { c = uint8_t(rng()); } while ((c & 0x7F) == 0x7F); }
        else if (dist == "ints") { const uint8_t t[7] = {0x00, 0x38, 0xB8, 0x40, 0xC0, 0x48, 0xC8}; c = t[rng() % 7]; }  // 0, +-1, +-2, +-4
        else { std::fprintf(stderr, "unknown dist\n"); std::exit(2); }
    }
}

int main(int argc, char** argv) {
    if (argc < 4) { std::fprintf(stderr, "usage: sim <gauss1|gauss100|uniform|ints> <k> <seeds> [m n]\n"); return 2; }
    std::string dist = argv[1];
    int k = std::atoi(argv[2]), seeds = std::atoi(argv[3]);
    int m = argc > 4 ? std::atoi(argv[4]) : 64, n = argc > 5 ? std::atoi(argv[5]) : 64;
    const int T = 16;  // 16 x 16 = 256 cells: the smallest lottery tile Pearl accepts
    long long cells = 0, b200_eq = 0, h100_eq = 0, tiles = 0, b200_tiles = 0, h100_tiles = 0;
    long long seeds_any_b200_tile = 0, seeds_any_h100_tile = 0;
    std::vector<double> ulp_b200;
    for (int s = 0; s < seeds; ++s) {
        std::mt19937_64 rng(0x4090ADA0ULL * 1000003ULL + uint64_t(s) * 7919ULL + uint64_t(k));
        std::vector<uint8_t> a(size_t(m) * k), b(size_t(n) * k);
        fill(a, dist, rng); fill(b, dist, rng);
        std::vector<float> ob(size_t(m) * n), oh(ob.size()), oac(ob.size()), oaw(ob.size());
        #pragma omp parallel for schedule(dynamic)
        for (int i = 0; i < m; ++i)
            for (int j = 0; j < n; ++j) {
                const uint8_t* ar = &a[size_t(i) * k]; const uint8_t* br = &b[size_t(j) * k];
                size_t o = size_t(i) * n + j;
                ob[o] = cell(Model::B200, ar, br, k);
                oh[o] = cell(Model::H100, ar, br, k);
                oac[o] = cell(Model::AdaChain, ar, br, k);
                oaw[o] = cell(Model::AdaWindowed, ar, br, k);
            }
        for (size_t o = 0; o < ob.size(); ++o) {
            ++cells;
            b200_eq += f2u(oac[o]) == f2u(ob[o]);
            h100_eq += f2u(oaw[o]) == f2u(oh[o]);
            if (f2u(oac[o]) != f2u(ob[o]) && ob[o] != 0.0f)
                ulp_b200.push_back(std::fabs(double(oac[o]) - double(ob[o])) / std::ldexp(1.0, std::ilogb(ob[o]) - 23));
        }
        bool any_b = false, any_h = false;
        for (int ti = 0; ti + T <= m; ti += T)
            for (int tj = 0; tj + T <= n; tj += T) {
                bool okb = true, okh = true;
                for (int i = ti; i < ti + T; ++i)
                    for (int j = tj; j < tj + T; ++j) {
                        size_t o = size_t(i) * n + j;
                        okb &= f2u(oac[o]) == f2u(ob[o]);
                        okh &= f2u(oaw[o]) == f2u(oh[o]);
                    }
                ++tiles; b200_tiles += okb; h100_tiles += okh; any_b |= okb; any_h |= okh;
            }
        seeds_any_b200_tile += any_b; seeds_any_h100_tile += any_h;
    }
    std::sort(ulp_b200.begin(), ulp_b200.end());
    double med = ulp_b200.empty() ? 0 : ulp_b200[ulp_b200.size() / 2];
    std::printf("dist=%s k=%d seeds=%d matrix=%dx%d cells=%lld tiles(16x16)=%lld\n", dist.c_str(), k, seeds, m, n, cells, tiles);
    std::printf("  Ada chain   vs B200 (Device=1): cells equal %.4f%%, tiles fully equal %lld/%lld, median error %.0f ulp\n",
                100.0 * b200_eq / cells, b200_tiles, tiles, med);
    std::printf("  Ada windowed vs H100 (Device=0): cells equal %.4f%%, tiles fully equal %lld/%lld\n",
                100.0 * h100_eq / cells, h100_tiles, tiles);
    return 0;
}
