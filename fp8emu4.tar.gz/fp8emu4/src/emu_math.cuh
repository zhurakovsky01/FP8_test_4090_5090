// Bit-exact B200 (Pearl Device = 1) FP8 matmul emulation for GPUs without B200 arithmetic.
// Shared by the CUDA kernel (emu.cu) and the CPU check (cpu_check.cpp).
//
// B200 group (official model, zk-pow/src/v4/api/utils.rs): FP32 carry + 32 exact e4m3 products,
// every term aligned to the largest stored exponent `maxe` and truncated toward zero to the
// grid 2^(maxe-25), summed exactly, result truncated to FP32 (round toward zero).
//
// Fast path: if no term loses bits on that grid, the group result is simply
// RZ_fp32(carry + exact sum of products). The exact sum comes from INT8 tensor cores:
// every e4m3 value is an integer I in units of 2^-9 (|I| < 2^18), split into three signed
// 6-bit limbs, so the dot product is 9 exact INT8 dot products combined with shifts.
// Whether any term could lose bits is decided conservatively from per-(row, 32-group)
// exponent bounds; if it might, the exact per-term algorithm runs instead (slow path).
#pragma once
#include <stdint.h>

#ifdef __CUDACC__
#define HD __host__ __device__ __forceinline__
#else
#define HD inline
#endif

HD uint32_t emu_f2u(float f) {
#ifdef __CUDA_ARCH__
    return __float_as_uint(f);
#else
    union { float f; uint32_t u; } x; x.f = f; return x.u;
#endif
}
HD float emu_u2f(uint32_t u) {
#ifdef __CUDA_ARCH__
    return __uint_as_float(u);
#else
    union { float f; uint32_t u; } x; x.u = u; return x.f;
#endif
}
HD int emu_clz64(uint64_t x) {
#ifdef __CUDA_ARCH__
    return __clzll((long long)x);
#else
    return __builtin_clzll(x);
#endif
}
HD int emu_clz32(uint32_t x) {
#ifdef __CUDA_ARCH__
    return __clz((int)x);
#else
    return __builtin_clz(x);
#endif
}

// e4m3 decode: stored exponent E' = max(E, 1), significand with the implicit bit for normals.
HD int code_E(uint8_t c) { int E = (c >> 3) & 15; return E ? E : 1; }
HD int code_m(uint8_t c) { int E = (c >> 3) & 15; int m = c & 7; return E ? (m | 8) : m; }
HD int code_I(uint8_t c) { int v = code_m(c) << (code_E(c) - 1); return (c & 0x80) ? -v : v; }  // units 2^-9
HD int8_t code_limb(uint8_t c, int l) {
    int v = code_m(c) << (code_E(c) - 1);
    int limb = (v >> (6 * l)) & 63;
    return (int8_t)((c & 0x80) ? -limb : limb);
}

// ---- exact official group (slow path) -------------------------------------------------
struct EmuGF { int sign; int exponent; uint32_t sig; };

HD EmuGF gf_from_f32(float v) {
    uint32_t bits = emu_f2u(v);
    int sign = bits >> 31, e = (bits >> 23) & 0xFF;
    uint32_t s = bits & 0x7FFFFF;
    if (e == 0 && s == 0) { EmuGF g = {sign, -133, 0}; return g; }
    if (e != 0) s |= 0x800000; else e = 1;
    EmuGF g = {sign, e - 127, s};
    return g;
}
HD float gf_to_f32(EmuGF v) {
    if (v.sig == 0) return emu_u2f((uint32_t)v.sign << 31);
    int e = v.exponent + 127;
    if ((v.sig & 0x800000) == 0) e -= 1;
    return emu_u2f(((uint32_t)v.sign << 31) | ((uint32_t)(e & 0xFF) << 23) | (v.sig & 0x7FFFFF));
}

// carry + 32 products, width 26 (25 fractional bits below the anchor), result toward zero.
HD float b200_group_exact(float carry, const uint8_t* a, const uint8_t* b) {
    EmuGF c = gf_from_f32(carry);
    int maxe = -100000;
    bool any = false;
    if (c.sig) { maxe = c.exponent; any = true; }
    for (int u = 0; u < 32; ++u) {
        int ma = code_m(a[u]), mb = code_m(b[u]);
        if (ma && mb) { int e = code_E(a[u]) + code_E(b[u]) - 14; if (!any || e > maxe) maxe = e; any = true; }
    }
    if (!any) return 0.0f;
    int64_t acc = 0;
    if (c.sig) {
        int shift = maxe - c.exponent;
        if (shift < 32) { int64_t al = (int64_t)((c.sig << 2) >> shift); acc += c.sign ? -al : al; }
    }
    for (int u = 0; u < 32; ++u) {
        int ma = code_m(a[u]), mb = code_m(b[u]);
        if (!(ma && mb)) continue;
        int e = code_E(a[u]) + code_E(b[u]) - 14;
        int shift = maxe - e;
        if (shift >= 32) continue;
        uint32_t sig = (uint32_t)(ma * mb) << 17;
        int64_t al = (int64_t)((sig << 2) >> shift);
        acc += ((a[u] ^ b[u]) & 0x80) ? -al : al;
    }
    int sign = acc < 0;
    uint32_t s = (uint32_t)(acc < 0 ? -acc : acc);
    if (s == 0) { EmuGF z = {sign, -139, 0}; return gf_to_f32(z); }
    int w = 32 - emu_clz32(s);
    int e = maxe + w - 26;
    if (w > 26) s >>= (w - 26); else s <<= (26 - w);
    if (e < -126) { int sh = -126 - e; s = sh >= 32 ? 0 : (s >> sh); e = -126; }
    s >>= 2;
    EmuGF r = {sign, e, s};
    if (s == 0) r.exponent = -139;
    return gf_to_f32(r);
}

// ---- fast path ----------------------------------------------------------------------------
// Per (row, 32-group) exponent summary byte: high nibble = max E', low nibble = min E' over
// non-zero codes; 0x00 means the group is all zero.
HD uint8_t group_summary(const uint8_t* codes) {
    int hi = 0, lo = 16;
    for (int u = 0; u < 32; ++u)
        if (code_m(codes[u])) { int E = code_E(codes[u]); hi = E > hi ? E : hi; lo = E < lo ? E : lo; }
    return hi ? (uint8_t)((hi << 4) | lo) : (uint8_t)0;
}

// True when no term of the group can lose bits on the B200 grid (sufficient condition).
HD bool fast_ok(uint8_t sa, uint8_t sb, float carry) {
    if (sa == 0 || sb == 0) return true;                 // no products: the result is the carry
    int pmax = (sa >> 4) + (sb >> 4) - 14, pmin = (sa & 15) + (sb & 15) - 14;
    uint32_t bits = emu_f2u(carry);
    if ((bits & 0x7FFFFFFF) == 0) return pmin >= pmax - 19;
    int ef = (bits >> 23) & 0xFF;
    int ec = ef ? ef - 127 : -126;
    int maxe = pmax > ec ? pmax : ec;
    if (pmin < maxe - 19) return false;                  // a small product could be truncated
    int shift = maxe - ec;                                // carry alignment shift (upper bound)
    if (shift <= 2) return true;
    if (shift >= 26) return false;
    uint32_t sig = ef ? (0x800000u | (bits & 0x7FFFFF)) : (bits & 0x7FFFFF);
    return (sig & ((1u << (shift - 2)) - 1)) == 0;        // the bits that would be dropped are zero
}

// RZ_fp32(carry + T * 2^-18), valid when fast_ok() holds.
HD float fast_result(int64_t T, float carry) {
    uint32_t bits = emu_f2u(carry);
    if (T == 0) return (bits & 0x7FFFFFFF) ? carry : 0.0f;
    int64_t S;
    int q;
    if ((bits & 0x7FFFFFFF) == 0) { S = T; q = -18; }
    else {
        int ef = (bits >> 23) & 0xFF;
        int64_t sig = ef ? (0x800000 | (bits & 0x7FFFFF)) : (bits & 0x7FFFFF);
        int ulp = (ef ? ef : 1) - 150;                    // carry = sig * 2^ulp
        q = ulp < -18 ? ulp : -18;
        if (bits >> 31) sig = -sig;
        S = sig * ((int64_t)1 << (ulp - q)) + T * ((int64_t)1 << (-18 - q));
    }
    if (S == 0) return 0.0f;
    uint32_t sign = S < 0 ? 0x80000000u : 0u;
    uint64_t u = (uint64_t)(S < 0 ? -S : S);
    int nb = 64 - emu_clz64(u);
    if (nb > 24) u >>= (nb - 24); else u <<= (24 - nb);
    int e = q + nb - 1;
    return emu_u2f(sign | ((uint32_t)(e + 127) << 23) | ((uint32_t)u & 0x7FFFFF));
}

HD int64_t combine_buckets(int s0, int s1, int s2, int s3, int s4) {
    return (int64_t)s0 + ((int64_t)s1 << 6) + ((int64_t)s2 << 12) + ((int64_t)s3 << 18) + ((int64_t)s4 << 24);
}

// ---- fast path 2: the carry is certainly the anchor ----------------------------------------
// Then the grid is 2^(ec-25), the carry is exact, and only products with stored exponent
// e_p < ec - 19 can lose bits; their dropped remainders are subtracted from the exact sum.
// le-masks: mask[t] has bit u set when code u is non-zero and its E' <= t (t = 0..15).
HD void group_masks(const uint8_t* codes, uint32_t* mask16) {
    for (int t = 0; t < 16; ++t) mask16[t] = 0;
    for (int u = 0; u < 32; ++u)
        if (code_m(codes[u])) for (int t = code_E(codes[u]); t < 16; ++t) mask16[t] |= 1u << u;
}

// Returns true and sets *ec when the carry is a normal non-zero FP32 whose exponent is >= every
// possible product exponent of the group (so it is the alignment anchor).
HD bool carry_anchored(uint8_t sa, uint8_t sb, float carry, int* ec) {
    uint32_t bits = emu_f2u(carry);
    int ef = (bits >> 23) & 0xFF;
    if (ef == 0) return false;                     // zero or subnormal carry
    *ec = ef - 127;
    if (sa == 0 || sb == 0) return true;
    return (sa >> 4) + (sb >> 4) - 14 <= *ec;
}

// Sum of the remainders B200 drops from small products (units 2^-18), candidates from masks.
HD int64_t truncation_correction(const uint8_t* a, const uint8_t* b, uint8_t sa, uint8_t sb,
                                 const uint32_t* ma16, const uint32_t* mb16, int ec, int* ncand) {
    *ncand = 0;
    if (sa == 0 || sb == 0 || ec <= 7) return 0;   // grid is not coarser than 2^-18: nothing to drop
    int thr = ec - 5;                              // truncated iff E'a + E'b < thr  (e_p < ec - 19)
    int la = sa & 15, lb = sb & 15;
    if (la + lb >= thr) return 0;
    int ta = thr - 1 - lb, tb = thr - 1 - la;
    uint32_t cand = ma16[ta > 15 ? 15 : ta] & mb16[tb > 15 ? 15 : tb];
    int64_t corr = 0;
    uint64_t gmask = ((uint64_t)1 << (ec - 7)) - 1;
    while (cand) {
#ifdef __CUDA_ARCH__
        int u = __ffs((int)cand) - 1;
#else
        int u = __builtin_ctz(cand);
#endif
        cand &= cand - 1;
        ++*ncand;
        if (code_E(a[u]) + code_E(b[u]) >= thr) continue;
        int64_t p = (int64_t)(code_m(a[u]) << (code_E(a[u]) - 1)) * (int64_t)(code_m(b[u]) << (code_E(b[u]) - 1));
        int64_t r = (int64_t)((uint64_t)p & gmask);
        corr += ((a[u] ^ b[u]) & 0x80) ? -r : r;
    }
    return corr;
}
