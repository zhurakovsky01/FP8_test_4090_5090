// CPU check of the v2 emulation math (emu2_math.cuh), the way the GPU kernel uses it:
// relative two's-complement limbs per (row, group) with per-block limb count, exact integer dot
// products per limb pair (u8/s8 as the tensor core reads them), scale shift, then cell_step_src.
// Every group step is also compared with the exact v1 group (b200_group_exact), and every final
// value with the expected B200 output (data/*.b200.f32) or with fp8models.hpp.
// Usage: cpu_check2 DATA_DIR [stress]
#include "emu2_math.cuh"
#include "fp8models.hpp"
#include <cstdio>
#include <cstring>
#include <fstream>
#include <random>
#include <sstream>
#include <string>
#include <vector>

static std::vector<uint8_t> rd(const std::string& p) {
    std::ifstream f(p, std::ios::binary);
    return std::vector<uint8_t>((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
}

struct Prep {
    int rows, K, G, blk;
    std::vector<int8_t> limbs; std::vector<uint64_t> rec; std::vector<uint8_t> blkL; std::vector<uint32_t> masks; std::vector<uint8_t> eb;
};
static Prep prep(const std::vector<uint8_t>& codes, int rows, int K, int blk) {
    Prep p{rows, K, K / 32, blk};
    p.limbs.resize(3 * size_t(rows) * K); p.rec.resize(size_t(p.G) * rows); p.blkL.resize(size_t(p.G) * (rows / blk));
    p.masks.resize(size_t(rows) * p.G * 16); p.eb.resize(size_t(rows) * K);
    for (int bi = 0; bi < rows / blk; ++bi)
        for (int g = 0; g < p.G; ++g)
            prep2_block(codes.data(), rows, K, blk, bi, g, p.limbs.data(), p.rec.data(), p.blkL.data(), p.masks.data(), p.eb.data());
    return p;
}

struct Stats { long long groups = 0, p0 = 0, p1 = 0, p2 = 0, step_bad = 0, l3a = 0, l3b = 0, tiles = 0; };

// returns number of wrong final values among the mv x nv valid cells
static long long run(const std::vector<uint8_t>& A, const std::vector<uint8_t>& B, int M, int N, int K, int mv, int nv,
                     const std::vector<float>& want, Stats& st) {
    Prep pa = prep(A, M, K, 16), pb = prep(B, N, K, 8);
    const int G = K / 32;
    const size_t planeA = size_t(M) * K, planeB = size_t(N) * K;
    long long bad = 0;
    for (int g = 0; g < G; ++g)
        for (int bi = 0; bi < mv; bi += 16)
            for (int bj = 0; bj < nv; bj += 8) {
                ++st.tiles;
                st.l3a += pa.blkL[size_t(g) * (M / 16) + bi / 16] == 3;
                st.l3b += pb.blkL[size_t(g) * (N / 8) + bj / 8] == 3;
            }
    for (int i = 0; i < mv; ++i)
        for (int j = 0; j < nv; ++j) {
            float carry = 0.0f;
            for (int g = 0; g < G; ++g) {
                const int LA = pa.blkL[size_t(g) * (M / 16) + i / 16], LB = pb.blkL[size_t(g) * (N / 8) + j / 8];
                int64_t Tp = 0;
                for (int p = 0; p < LA; ++p)
                    for (int q = 0; q < LB; ++q) {
                        int dot = 0;
                        for (int u = 0; u < 32; ++u)
                            dot += limb_val(pa.limbs[p * planeA + size_t(i) * K + 32 * g + u], p, LA) *
                                   limb_val(pb.limbs[q * planeB + size_t(j) * K + 32 * g + u], q, LB);
                        Tp += (int64_t)dot * ((int64_t)1 << (8 * (p + q)));
                    }
                const uint64_t ra = pa.rec[size_t(g) * M + i], rb = pb.rec[size_t(g) * N + j];
                const int64_t T = Tp * ((int64_t)1 << (rec_s(ra) + rec_s(rb) - 2));
                const uint8_t* ag = &A[size_t(i) * K + 32 * g];
                const uint8_t* bg = &B[size_t(j) * K + 32 * g];
                int64_t T2 = 0;
                for (int u = 0; u < 32; ++u) T2 += int64_t(code_I(ag[u])) * code_I(bg[u]);
                if (T != T2) { std::printf("LIMB ERROR row %d col %d grp %d\n", i, j, g); std::exit(1); }
                CellSrc s{A.data(), B.data(), pa.masks.data(), pb.masks.data(), pa.eb.data(), pb.eb.data(), i, j, g, K, G};
                int path = -1;
                const float f = cell_step_src(carry, T, ra, rb, s, &path);
                const float ex = b200_group_exact(carry, ag, bg);
                ++st.groups;
                (path == 0 ? st.p0 : path == 1 ? st.p1 : st.p2)++;
                if (emu_f2u(f) != emu_f2u(ex)) ++st.step_bad;
                carry = f;
            }
            const float out = (emu_f2u(carry) & 0x7FFFFFFF) ? carry : 0.0f;
            bad += emu_f2u(out) != emu_f2u(want[size_t(i) * nv + j]);
        }
    return bad;
}

static std::vector<uint8_t> pad(const std::vector<uint8_t>& c, int rows, int K, int to) {
    std::vector<uint8_t> o(size_t(to) * K, 0);
    std::memcpy(o.data(), c.data(), size_t(rows) * K);
    return o;
}

static void report(const char* name, long long cells, long long bad, const Stats& st) {
    std::printf("%-30s cells %6lld  bad %lld  step!=exact %lld  P1 %.2f%%  P1+scan %.2f%%  P2 %.2f%%  3-limb blocks A %.1f%% B %.1f%%\n",
                name, cells, bad, st.step_bad, 100.0 * st.p0 / st.groups, 100.0 * st.p1 / st.groups, 100.0 * st.p2 / st.groups,
                100.0 * st.l3a / st.tiles, 100.0 * st.l3b / st.tiles);
}

int main(int argc, char** argv) {
    const std::string dir = argc > 1 ? argv[1] : "data";
    const bool stress = argc > 2 && std::string(argv[2]) == "stress";
    long long total_bad = 0, total_cells = 0, total_step = 0;
    std::ifstream man(dir + "/manifest.txt");
    std::string line;
    while (std::getline(man, line)) {
        if (line.empty() || line[0] == '#') continue;
        std::istringstream is(line);
        std::string name; int M0, N0, K, mv, nv; is >> name >> M0 >> N0 >> K >> mv >> nv;
        auto A = rd(dir + "/" + name + ".a"), B = rd(dir + "/" + name + ".b"), E = rd(dir + "/" + name + ".b200.f32");
        const int M = (mv + 63) / 64 * 64, N = (nv + 63) / 64 * 64;
        std::vector<float> want(size_t(mv) * nv);
        for (int i = 0; i < mv; ++i) for (int j = 0; j < nv; ++j) std::memcpy(&want[size_t(i) * nv + j], &E[(size_t(i) * N0 + j) * 4], 4);
        Stats st;
        const long long bad = run(pad(A, mv, K, M), pad(B, nv, K, N), M, N, K, mv, nv, want, st);
        report(name.c_str(), (long long)mv * nv, bad, st);
        total_bad += bad; total_cells += (long long)mv * nv; total_step += st.step_bad;
    }
    // benchmark inputs (subsets), expected values from the independent model in fp8models.hpp
    for (const char* bn : {"bench_pearl_like_k4096", "bench_gauss_sigma100_k4096", "bench_uniform_codes_k4096"}) {
        const int K = 4096, rows = 64;
        auto A = rd(dir + "/" + bn + ".a"), B = rd(dir + "/" + bn + ".b");
        A.resize(size_t(rows) * K); B.resize(size_t(rows) * K);
        std::vector<float> want = fp8::matmul(fp8::Model::B200, A, B, rows, rows, K);
        Stats st;
        const long long bad = run(A, B, rows, rows, K, rows, rows, want, st);
        report(bn, (long long)rows * rows, bad, st);
        total_bad += bad; total_cells += (long long)rows * rows; total_step += st.step_bad;
    }
    if (stress) {
        // random operands with zeros, subnormals, narrow and wide exponent ranges, odd k
        std::mt19937_64 rng(12345);
        for (int trial = 0; trial < 24; ++trial) {
            const int K = 32 * (1 + int(rng() % 40)), rows = 64;
            const int kind = trial % 6;
            auto gen = [&](std::vector<uint8_t>& v) {
                v.resize(size_t(rows) * K);
                for (auto& c : v) {
                    uint8_t x = uint8_t(rng());
                    switch (kind) {
                        case 0: c = x == 0x7F || x == 0xFF ? 0x7E : x; break;                        // any finite code
                        case 1: c = (x & 0x87) | ((rng() % 3) << 3); break;                           // subnormal-heavy
                        case 2: c = (rng() % 4 == 0) ? 0 : ((x & 0x87) | ((12 + rng() % 3) << 3)); break; // narrow, zeros
                        case 3: c = (x & 0x87) | ((rng() % 2 ? 1 : 14) << 3); break;                  // two far levels
                        case 4: c = (x & 0x87) | ((4 + (rng() % 11)) << 3); break;                   // PIP-3-like range
                        default: c = (rng() % 8) ? ((x & 0x87) | (14 << 3)) : ((x & 0x87) | ((rng() % 15) << 3)); break;
                    }
                    if ((c & 0x7F) == 0x7F) c = (c & 0x80) | 0x7E;
                }
            };
            std::vector<uint8_t> A, B; gen(A); gen(B);
            std::vector<float> want = fp8::matmul(fp8::Model::B200, A, B, rows, rows, K);
            Stats st;
            const long long bad = run(A, B, rows, rows, K, rows, rows, want, st);
            char nm[64]; std::snprintf(nm, sizeof nm, "stress%02d_kind%d_k%d", trial, kind, K);
            report(nm, (long long)rows * rows, bad, st);
            total_bad += bad; total_cells += (long long)rows * rows; total_step += st.step_bad;
        }
    }
    std::printf("TOTAL: %lld cells, %lld wrong values, %lld group steps != exact\n", total_cells, total_bad, total_step);
    return (total_bad || total_step) ? 1 : 0;
}
