// Independent C++ re-implementation of the FP8 MMA arithmetic models used by
// Pearl's FP8 protocol (PIP-3) and by the Ada proposal (pips#16).
//
// Written from the semantics of pearl-research-labs/pearl (branch fp8-scheme)
// zk-pow/src/v4/api/utils.rs: GFloat, multiply_fp8_to_gfloat,
// windowed_group_sum, matmul_fp8_windowed (B200) and the H100 replay, and of
// pips#16 (MatMul_ADA). Validated against the official vectors by validate.cpp.
//
//   B200 (Device = 1): carry + 32 products per group, 26-bit window
//                      (25 fractional bits below the anchor), result truncated
//                      to FP32, groups chained over the whole k.
//   H100 (Device = 0): carry + 32 products per group, 14-bit window, local
//                      accumulator restarted from +0 every 128 products and
//                      added to the running total with one FP32 RNE add.
//   Ada  (pips#16)   : like H100 but every 16 products form a group
//                      (two groups per 32-product mma instruction).
#pragma once
#include <cmath>
#include <cstdint>
#include <cstring>
#include <stdexcept>
#include <vector>

namespace fp8 {

constexpr int kFp32MinNonzeroExp = -126;
constexpr int kZeroExp = -139;  // FP8_PRODUCT_ZERO_EXP

struct GF {
    bool sign;
    int exponent;
    uint32_t significand;  // canonically zero iff significand == 0
};

inline uint32_t f2u(float f) { uint32_t u; std::memcpy(&u, &f, 4); return u; }
inline float u2f(uint32_t u) { float f; std::memcpy(&f, &u, 4); return f; }

inline GF from_f32(float value) {
    uint32_t bits = f2u(value);
    if (((bits >> 23) & 0xFF) == 0xFF) throw std::runtime_error("non-finite f32");
    bool sign = (bits >> 31) & 1;
    int e = (bits >> 23) & 0xFF;
    uint32_t sig = bits & 0x7FFFFF;
    if (e == 0 && sig == 0) return GF{sign, -133, 0};
    if (e != 0) { sig |= 0x800000; } else { e = 1; }
    return GF{sign, e - 127, sig};
}

inline float to_f32(GF v) {
    if (v.significand == 0) return u2f(uint32_t(v.sign) << 31);
    int e = v.exponent + 127;
    if ((v.significand & 0x800000) == 0) e -= 1;
    if (e < 0) throw std::runtime_error("GF exponent below f32 range");
    uint32_t bits = (uint32_t(v.sign) << 31) | (uint32_t(e & 0xFF) << 23) | (v.significand & 0x7FFFFF);
    float f = u2f(bits);
    if (((bits >> 23) & 0xFF) == 0xFF) throw std::runtime_error("non-finite result");
    return f;
}

inline GF product(uint8_t a, uint8_t b) {
    bool sa = (a >> 7) & 1, sb = (b >> 7) & 1;
    int ea = (a >> 3) & 0xF, eb = (b >> 3) & 0xF;
    uint32_t ma = a & 7, mb = b & 7;
    if (ea != 0) ma |= 8;
    if (eb != 0) mb |= 8;
    if (ea == 0) ea = 1;
    if (eb == 0) eb = 1;
    uint32_t sig = (ma * mb) << 17;
    if (sig == 0) return GF{bool(sa ^ sb), kZeroExp, 0};
    return GF{bool(sa ^ sb), ea + eb - 14, sig};
}

// One accumulation group: align every non-zero term to the largest stored
// exponent, truncate each toward zero to the window, sum exactly, renormalize
// to `width` bits (truncating), then to the FP32 scale.
inline GF group_sum(const GF* v, int count, int width) {
    const int base = 24;
    const bool neg_shift = width < base;
    const uint32_t diff = neg_shift ? base - width : width - base;
    bool any = false;
    int maxe = 0;
    for (int i = 0; i < count; ++i)
        if (v[i].significand != 0 && (!any || v[i].exponent > maxe)) { maxe = v[i].exponent; any = true; }
    if (!any) return GF{false, kZeroExp, 0};
    int64_t acc = 0;
    for (int i = 0; i < count; ++i) {
        if (v[i].significand == 0) continue;
        int shift = maxe - v[i].exponent;
        if (shift >= 32) continue;
        uint32_t shifted = neg_shift ? (v[i].significand >> diff) : (v[i].significand << diff);
        int64_t aligned = int64_t(shifted >> shift);
        acc += v[i].sign ? -aligned : aligned;
    }
    bool sign = acc < 0;
    uint32_t sig = uint32_t(acc < 0 ? -acc : acc);
    if (sig == 0) return GF{sign, kZeroExp, 0};
    int w = 32 - __builtin_clz(sig);
    int e = maxe + w - width;
    if (w > width) sig >>= (w - width); else sig <<= (width - w);
    if (e < kFp32MinNonzeroExp) {
        int s = kFp32MinNonzeroExp - e;
        sig = s >= 32 ? 0 : (sig >> s);
        e = kFp32MinNonzeroExp;
    }
    sig = neg_shift ? (sig << diff) : (sig >> diff);
    if (sig == 0) return GF{sign, kZeroExp, 0};
    return GF{sign, e, sig};
}

// Continuous chain over the whole k: carry + `group` products per collapse.
// This is what a kernel computes when it chains d = mma(a, b, d) over k.
// B200 official model = chain(group 32, width 26).
inline float chain_cell(const uint8_t* a, const uint8_t* b, int k, int group, int width, float carry_in) {
    GF vals[33];
    vals[0] = from_f32(carry_in);
    int used = 1;
    for (int s = 0; s < k; s += group) {
        int len = (k - s) < group ? (k - s) : group;
        for (int u = 0; u < len; ++u) vals[1 + u] = product(a[s + u], b[s + u]);
        used = len + 1;
        if (used == group + 1) {
            float collapsed = to_f32(group_sum(vals, used, width));
            vals[0] = from_f32(collapsed);
            used = 1;
        }
    }
    return to_f32(group_sum(vals, used, width));  // final (possibly partial) group / renormalization
}

// Windowed replay: every 128 products restart a local accumulator at +0,
// chain groups of `group` products, then add the local result to the
// running FP32 total with one round-to-nearest-even addition.
// H100 official = windowed(group 32, width 14). Ada (pips#16) = windowed(group 16, width 14).
inline float windowed_cell(const uint8_t* a, const uint8_t* b, int k, int group, int width, int window = 128) {
    if (k <= 0 || k % 32) throw std::runtime_error("k must be a positive multiple of 32");
    float total = 0.0f;
    GF vals[33];
    for (int ws = 0; ws < k; ws += window) {
        int we = ws + window < k ? ws + window : k;
        float local = 0.0f;
        for (int gs = ws; gs < we; gs += group) {
            vals[0] = from_f32(local);
            for (int u = 0; u < group; ++u) vals[1 + u] = product(a[gs + u], b[gs + u]);
            local = to_f32(group_sum(vals, group + 1, width));
        }
        volatile float t = total + local;  // FP32 RNE add (no FMA, no x87: SSE on x86-64)
        total = t;
        if (((f2u(total) >> 23) & 0xFF) == 0xFF) throw std::runtime_error("total overflow");
        if (total == 0.0f) total = 0.0f;
    }
    return total;
}

enum class Model { B200, H100, AdaWindowed, AdaChain, B200Windowed };

inline const char* model_name(Model m) {
    switch (m) {
        case Model::B200: return "B200 (Device=1)";
        case Model::H100: return "H100 (Device=0)";
        case Model::AdaWindowed: return "Ada windowed (pips#16)";
        case Model::AdaChain: return "Ada chain";
        case Model::B200Windowed: return "B200 windowed";
    }
    return "?";
}

inline float cell(Model model, const uint8_t* a, const uint8_t* b, int k, float carry = 0.0f) {
    switch (model) {
        case Model::B200: return chain_cell(a, b, k, 32, 26, carry);
        case Model::H100: return windowed_cell(a, b, k, 32, 14);
        case Model::AdaWindowed: return windowed_cell(a, b, k, 16, 14);
        case Model::AdaChain: return chain_cell(a, b, k, 16, 14, carry);
        case Model::B200Windowed: return windowed_cell(a, b, k, 32, 26);
    }
    return 0.0f;
}

// a: m x k row-major, b: n x k row-major (b holds the transposed operand).
inline std::vector<float> matmul(Model model, const std::vector<uint8_t>& a, const std::vector<uint8_t>& b,
                                 int m, int n, int k, const std::vector<float>* carry = nullptr) {
    std::vector<float> out(size_t(m) * n);
    for (int i = 0; i < m; ++i)
        for (int j = 0; j < n; ++j)
            out[size_t(i) * n + j] = cell(model, &a[size_t(i) * k], &b[size_t(j) * k], k,
                                          carry ? (*carry)[size_t(i) * n + j] : 0.0f);
    return out;
}

// Exact E4M3FN decode / round-to-nearest-even encode (finite values only).
inline double decode_e4m3(uint8_t c) {
    int e = (c >> 3) & 0xF, m = c & 7;
    double mag = e == 0 ? m * (1.0 / 512) : (8 + m) * std::ldexp(1.0, e - 10);
    return (c & 0x80) ? -mag : mag;
}

}  // namespace fp8
