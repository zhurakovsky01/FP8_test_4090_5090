#include "emu_math.cuh"
#include "pearl_like.hpp"
#include <cstdio>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>
static std::vector<uint8_t> rd(const std::string& p){std::ifstream f(p,std::ios::binary);return std::vector<uint8_t>((std::istreambuf_iterator<char>(f)),std::istreambuf_iterator<char>());}
struct Res { long long groups=0, pathA=0, pathB=0, slow=0, cands=0, bad=0; };
static Res run(const std::vector<uint8_t>& A, const std::vector<uint8_t>& B, int M, int N, int K) {
    Res r; int G = K/32;
    std::vector<uint8_t> sa(size_t(M)*G), sb(size_t(N)*G); std::vector<uint32_t> ma(size_t(M)*G*16), mb(size_t(N)*G*16);
    for (int i=0;i<M;++i) for(int g=0;g<G;++g){ sa[size_t(i)*G+g]=group_summary(&A[size_t(i)*K+32*g]); group_masks(&A[size_t(i)*K+32*g], &ma[(size_t(i)*G+g)*16]); }
    for (int j=0;j<N;++j) for(int g=0;g<G;++g){ sb[size_t(j)*G+g]=group_summary(&B[size_t(j)*K+32*g]); group_masks(&B[size_t(j)*K+32*g], &mb[(size_t(j)*G+g)*16]); }
    for (int i=0;i<M;++i) for (int j=0;j<N;++j) {
        float carry = 0.0f;
        for (int g=0; g<G; ++g) {
            const uint8_t* ag=&A[size_t(i)*K+32*g]; const uint8_t* bg=&B[size_t(j)*K+32*g];
            int64_t T=0; for(int u=0;u<32;++u) T += int64_t(code_I(ag[u]))*code_I(bg[u]);
            float exact = b200_group_exact(carry, ag, bg), got; ++r.groups;
            uint8_t a8=sa[size_t(i)*G+g], b8=sb[size_t(j)*G+g]; int ec, nc;
            if (carry_anchored(a8, b8, carry, &ec)) {
                int64_t corr = truncation_correction(ag, bg, a8, b8, &ma[(size_t(i)*G+g)*16], &mb[(size_t(j)*G+g)*16], ec, &nc);
                r.cands += nc; ++r.pathB; got = fast_result(T - corr, carry);
            } else if (fast_ok(a8, b8, carry)) { ++r.pathA; got = fast_result(T, carry); }
            else { ++r.slow; got = exact; }
            r.bad += emu_f2u(got) != emu_f2u(exact);
            carry = exact;
        }
    }
    return r;
}
int main() {
    std::string dir="/tmp/claude-0/work/pkg/data";
    struct S { const char* name; int M,N,K; } suites[] = {{"gauss_sigma100_k4096",128,128,4096},{"gauss_sigma100_k16384",64,64,16384},{"uniform_codes_k4096",64,64,4096},{"gauss_sigma1_k4096",64,64,4096}};
    for (auto& s: suites) {
        auto A=rd(dir+"/"+s.name+".a"), B=rd(dir+"/"+s.name+".b"); int M=std::min(s.M,64), N=std::min(s.N,64);
        Res r=run(A,B,M,N,s.K);
        std::printf("%-24s pathA %.2f%%  pathB %.2f%% (cand/group %.2f)  slow %.3f%%  bad %lld\n", s.name, 100.0*r.pathA/r.groups, 100.0*r.pathB/r.groups, double(r.cands)/r.groups, 100.0*r.slow/r.groups, r.bad);
    }
    for (int K : {4096, 16384}) {
        auto A = pearl_like::operand(64, K, 101), B = pearl_like::operand(64, K, 202);
        Res r=run(A,B,64,64,K);
        int small=0; for (auto c: A) small += (c&0x78)==0x20; 
        std::printf("pearl_like_k%-12d pathA %.2f%%  pathB %.2f%% (cand/group %.2f)  slow %.3f%%  bad %lld   (E=4 codes: %.2f%%)\n", K, 100.0*r.pathA/r.groups, 100.0*r.pathB/r.groups, double(r.cands)/r.groups, 100.0*r.slow/r.groups, r.bad, 100.0*small/A.size());
    }
}
