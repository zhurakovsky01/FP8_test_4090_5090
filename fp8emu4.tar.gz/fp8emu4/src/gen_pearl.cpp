#include "pearl_like.hpp"
#include <cstdio>
#include <fstream>
static void wr(const std::string& p, const void* d, size_t n){ std::ofstream f(p, std::ios::binary); f.write((const char*)d, n); }
int main(int argc, char** argv) {
    std::string out = argv[1];
    { // test suite with expected B200 outputs
        int M = 64, N = 64, K = 4096;
        auto A = pearl_like::operand(M, K, 0xA11CE), B = pearl_like::operand(N, K, 0xB0B);
        std::vector<float> C(size_t(M) * N);
        #pragma omp parallel for
        for (int i = 0; i < M; ++i) for (int j = 0; j < N; ++j) C[size_t(i) * N + j] = fp8::cell(fp8::Model::B200, &A[size_t(i) * K], &B[size_t(j) * K], K);
        wr(out + "/pearl_like_k4096.a", A.data(), A.size()); wr(out + "/pearl_like_k4096.b", B.data(), B.size());
        wr(out + "/pearl_like_k4096.b200.f32", C.data(), C.size() * 4);
    }
    { // bench operands
        int R = 256, K = 4096;
        auto A = pearl_like::operand(R, K, 0x5EED1), B = pearl_like::operand(R, K, 0x5EED2);
        wr(out + "/bench_pearl_like_k4096.a", A.data(), A.size()); wr(out + "/bench_pearl_like_k4096.b", B.data(), B.size());
    }
    std::puts("ok");
}
