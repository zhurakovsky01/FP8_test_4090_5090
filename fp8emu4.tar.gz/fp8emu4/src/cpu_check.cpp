// CPU check of the emulation math: for every suite, emulate the B200 chain the way the GPU
// kernel will (limb dot products -> buckets -> fast path, else exact slow path) and compare
// bit-for-bit with the expected B200 outputs. Also checks fast path == exact on every group
// where the fast path is taken, and reports how often the slow path is needed.
#include "emu_math.cuh"
#include <cstdio>
#include <cstring>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

static std::vector<uint8_t> rd(const std::string& p) {
    std::ifstream f(p, std::ios::binary);
    return std::vector<uint8_t>((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
}

int main(int argc, char** argv) {
    std::string dir = argc > 1 ? argv[1] : "/tmp/claude-0/work/pkg/data";
    std::ifstream man(dir + "/manifest.txt");
    std::string line;
    long long total_bad = 0, total_cells = 0;
    while (std::getline(man, line)) {
        if (line.empty() || line[0] == '#') continue;
        std::istringstream is(line);
        std::string name; int M, N, K, mv, nv; is >> name >> M >> N >> K >> mv >> nv;
        auto A = rd(dir + "/" + name + ".a"), B = rd(dir + "/" + name + ".b"), E = rd(dir + "/" + name + ".b200.f32");
        int G = K / 32;
        std::vector<uint8_t> sa(size_t(M) * G), sb(size_t(N) * G);
        for (int i = 0; i < M; ++i) for (int g = 0; g < G; ++g) sa[size_t(i) * G + g] = group_summary(&A[size_t(i) * K + 32 * g]);
        for (int j = 0; j < N; ++j) for (int g = 0; g < G; ++g) sb[size_t(j) * G + g] = group_summary(&B[size_t(j) * K + 32 * g]);
        long long groups = 0, slow = 0, mismatch_fast = 0, bad = 0;
        for (int i = 0; i < mv; ++i)
            for (int j = 0; j < nv; ++j) {
                float carry = 0.0f;
                const uint8_t* a = &A[size_t(i) * K];
                const uint8_t* b = &B[size_t(j) * K];
                for (int g = 0; g < G; ++g) {
                    const uint8_t* ag = a + 32 * g; const uint8_t* bg = b + 32 * g;
                    int s[5] = {0, 0, 0, 0, 0};
                    for (int li = 0; li < 3; ++li)
                        for (int lj = 0; lj < 3; ++lj) {
                            int dot = 0;
                            for (int u = 0; u < 32; ++u) dot += int(code_limb(ag[u], li)) * int(code_limb(bg[u], lj));
                            s[li + lj] += dot;
                        }
                    int64_t T = combine_buckets(s[0], s[1], s[2], s[3], s[4]);
                    // sanity: buckets reproduce the exact integer dot product
                    int64_t T2 = 0; for (int u = 0; u < 32; ++u) T2 += int64_t(code_I(ag[u])) * code_I(bg[u]);
                    if (T != T2) { std::printf("limb error\n"); return 1; }
                    float exact = b200_group_exact(carry, ag, bg);
                    ++groups;
                    if (fast_ok(sa[size_t(i) * G + g], sb[size_t(j) * G + g], carry)) {
                        float f = fast_result(T, carry);
                        if (emu_f2u(f) != emu_f2u(exact)) ++mismatch_fast;
                        carry = f;
                    } else { ++slow; carry = exact; }
                }
                float out = (emu_f2u(carry) & 0x7FFFFFFF) ? carry : 0.0f;   // final re-sum: -0 -> +0
                uint32_t want; std::memcpy(&want, &E[(size_t(i) * N + j) * 4], 4);
                bad += emu_f2u(out) != want;
            }
        std::printf("%-30s cells %5d  bad %lld  fast!=exact %lld  slow path %.3f%% of groups\n",
                    name.c_str(), mv * nv, bad, mismatch_fast, 100.0 * slow / groups);
        total_bad += bad; total_cells += mv * nv;
    }
    std::printf("TOTAL: %lld cells, %lld mismatches\n", total_cells, total_bad);
    return total_bad ? 1 : 0;
}
