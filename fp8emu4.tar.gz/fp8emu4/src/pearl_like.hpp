// Pearl-like FP8 mining operands, following the PIP-3 input preparation as implemented in
// Cyberminer host_math.py (unit_scale_norms, row_parameters, noise_lines, mix_codes) for the
// B200 device. Random bytes come from a seeded PRNG instead of BLAKE3, which does not change
// the value distribution. The rank-32 noise product uses the B200 model, as in the protocol.
#pragma once
#include "fp8models.hpp"
#include <algorithm>
#include <cmath>
#include <random>
#include <vector>

namespace pearl_like {

inline float bf16(float x) {  // round-to-nearest-even to bfloat16
    uint32_t u = fp8::f2u(x);
    u = (u + 0x7FFF + ((u >> 16) & 1)) & 0xFFFF0000u;
    return fp8::u2f(u);
}

inline uint8_t encode_e4m3(double x) {  // RNE, saturating at 448
    static double lv[127];
    static bool init = false;
    if (!init) { for (int c = 0; c < 127; ++c) lv[c] = fp8::decode_e4m3(uint8_t(c)); init = true; }
    double mag = std::fabs(x);
    uint8_t code;
    if (mag >= lv[126]) code = 126;
    else {
        int lo = int(std::upper_bound(lv, lv + 127, mag) - lv) - 1;
        double mid = 0.5 * (lv[lo] + lv[lo + 1]);
        code = mag < mid ? uint8_t(lo) : mag > mid ? uint8_t(lo + 1) : uint8_t((lo & 1) ? lo + 1 : lo);
    }
    if (std::signbit(x) && code != 0) code |= 0x80;
    return code;
}

// One noise line of 32 e4m3 values (noise_lines in host_math.py).
inline void noise_line(std::mt19937_64& rng, uint8_t* out) {
    int x[32];
    int64_t sum = 0;
    for (int r = 0; r < 32; ++r) { uint8_t u = uint8_t(rng()); x[r] = (1 - 2 * (u >> 7)) * ((u & 127) + 1); sum += int64_t(x[r]) * x[r]; }
    float denom = bf16(float((int64_t)std::sqrt(double(sum) * 1024.0)));
    float gain = bf16(8192.0f / denom);
    for (int r = 0; r < 32; ++r) out[r] = encode_e4m3(bf16(float(x[r]) * gain));
}

// rows x k operand (one side of the matmul), B200 parameters.
inline std::vector<uint8_t> operand(int rows, int k, uint64_t seed) {
    std::mt19937_64 rng(seed);
    std::vector<uint8_t> out(size_t(rows) * k);
    std::vector<uint8_t> F(size_t(k) * 32);                    // shared factor lines (side factor 1)
    for (int c = 0; c < k; ++c) noise_line(rng, &F[size_t(c) * 32]);
    const float delta_r = bf16(std::sqrt(32.0f) * 0.5f);
    const float delta_std = bf16(std::sqrt(32.0f) * 0.5f / 65536.0f);
    std::vector<int8_t> codes(k);
    std::vector<float> mixed(k);
    uint8_t e[32];
    for (int i = 0; i < rows; ++i) {
        int64_t sq = 0; int peak = 0;
        for (int c = 0; c < k; ++c) { codes[c] = int8_t(rng()); sq += int(codes[c]) * codes[c]; peak = std::max(peak, std::abs(int(codes[c]))); }
        float rms = bf16(float(std::sqrt(double(sq) / k)));   // unit_scale_norms (close enough: RNE bf16 of the RMS)
        rms = std::max(rms, std::ldexp(1.0f, -32));
        float pk = std::max(float(peak), std::ldexp(1.0f, -32));
        float alpha = bf16(448.0f / bf16(delta_r * rms + pk));
        float beta = bf16(bf16(alpha * rms) * delta_std);
        float scaled_rms = alpha * rms;
        int high = int(std::ilogb(scaled_rms)) - 9 + 7;     // frexp exponent - 1 == ilogb
        uint8_t strip_exp = uint8_t((high << 3) & 0x78);
        float g = scaled_rms < 8 ? 0.1f : 0.08f;
        uint8_t threshold = encode_e4m3(g * scaled_rms);
        noise_line(rng, e);                                  // row factor line (side factor 0)
        for (int c = 0; c < k; ++c) {
            float noise = fp8::chain_cell(e, &F[size_t(c) * 32], 32, 32, 26, 0.0f);   // B200 rank-32 noise atom
            mixed[c] = float(double(noise) * beta + double(alpha * float(codes[c])));
        }
        for (int c = 0; c < k; ++c) {
            uint8_t raw = encode_e4m3(mixed[c]);
            uint8_t safe = uint8_t((raw & 0x80) | strip_exp | ((raw & 7) | 1));
            bool below = (raw & 127) < threshold;
            bool coin = ((fp8::f2u(mixed[c - c % 4]) >> 8) & 127) < 112;
            out[size_t(i) * k + c] = (below && coin) ? safe : raw;
        }
    }
    return out;
}

}  // namespace pearl_like
