// Oracle vs record-based tests on PIP-3-like inputs: how many cell-groups could stay on the cheap path?
#include "emu2_math.cuh"
#include <cstdio>
#include <fstream>
#include <vector>
static std::vector<uint8_t> rd(const char* p){std::ifstream f(p,std::ios::binary);return std::vector<uint8_t>((std::istreambuf_iterator<char>(f)),std::istreambuf_iterator<char>());}
int main(int argc,char**argv){
  const char* base=argc>1?argv[1]:"/tmp/w_emu/fp8emu/data/bench_pearl_like_k4096";
  std::string a_=std::string(base)+".a", b_=std::string(base)+".b";
  const int K=4096,R=64,G=K/32; auto A=rd(a_.c_str()),B=rd(b_.c_str());
  long long n=0, rec_fast=0, orc_anch=0, orc_fast=0, rec_anch=0, top_anch=0, carry_sub=0, cand_real=0, cand_maybe_n=0, cand_any=0;
  for(int i=0;i<R;++i)for(int j=0;j<R;++j){float c=0;for(int g=0;g<G;++g){const uint8_t*a=&A[i*K+32*g],*b=&B[j*K+32*g];
    uint64_t ra=make_rec(a),rb=make_rec(b); int64_t T=0; int maxS=-1;
    for(int u=0;u<32;++u){T+=int64_t(code_I(a[u]))*code_I(b[u]); if(code_m(a[u])&&code_m(b[u])){int S=code_E(a[u])+code_E(b[u]); if(S>maxS)maxS=S;}}
    uint32_t bits=emu_f2u(c); int ef=(bits>>23)&255; int ec=ef-127; ++n;
    if(ef==0){++carry_sub;}
    else{
      int mA=rec_max(ra),mB=rec_max(rb);
      bool ranch=(!mA||!mB||mA+mB-14<=ec); bool oanch=(maxS<0||maxS-14<=ec);
      rec_anch+=ranch; orc_anch+=oanch;
      // top-level masks: positions at maxE
      uint32_t tA=0,tB=0; for(int u=0;u<32;++u){if(code_m(a[u])&&code_E(a[u])==mA)tA|=1u<<u; if(code_m(b[u])&&code_E(b[u])==mB)tB|=1u<<u;}
      bool tanch = ranch || ((tA&tB)==0 && mA+mB-15<=ec);
      top_anch+=tanch;
      if(oanch){int thr=ec-5; int gu=thr-2; int64_t corr=0; bool any=false;
        for(int u=0;u<32;++u) if(code_m(a[u])&&code_m(b[u])&&code_E(a[u])+code_E(b[u])<thr){any=true; if(gu>0){int64_t p=int64_t(code_m(a[u])<<(code_E(a[u])-1))*(code_m(b[u])<<(code_E(b[u])-1)); corr+=p&((1LL<<gu)-1);} }
        cand_any+=any; cand_real+=corr!=0; orc_fast+=corr==0;
        bool mb=mA&&mB&&cand_maybe(ra,rb,thr); cand_maybe_n+=mb; rec_fast+=ranch&&!mb;}
    }
    // advance with exact
    c=b200_group_exact(c,a,b);}}
  printf("cell-groups %lld\n carry zero/subnormal: %.2f%%\n anchored: by record %.2f%%  with top masks %.2f%%  true %.2f%%\n",n,100.0*carry_sub/n,100.0*rec_anch/n,100.0*top_anch/n,100.0*orc_anch/n);
  printf(" among truly anchored: any candidate %.2f%%, real nonzero correction %.2f%%, record test says maybe %.2f%%\n",100.0*cand_any/n,100.0*cand_real/n,100.0*cand_maybe_n/n);
  printf(" cheap path possible: record-based %.2f%%   oracle (anchored, correction 0) %.2f%%\n",100.0*rec_fast/n,100.0*orc_fast/n);
}
