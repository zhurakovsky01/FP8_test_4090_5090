// How often does at least one lane of a warp leave the cheap path (v2/12 layout: warp 16 x 16 cells)?
#include "emu2_math.cuh"
#include "fp8models.hpp"
#include <cstdio>
#include <fstream>
#include <vector>
static std::vector<uint8_t> rd(const char* p){std::ifstream f(p,std::ios::binary);return std::vector<uint8_t>((std::istreambuf_iterator<char>(f)),std::istreambuf_iterator<char>());}
int main(){
  const int K=4096,R=64,G=K/32; auto A=rd("/tmp/w_emu/fp8emu/data/bench_pearl_like_k4096.a"),B=rd("/tmp/w_emu/fp8emu/data/bench_pearl_like_k4096.b");
  std::vector<uint64_t> ra(R*G),rb(R*G); std::vector<uint32_t> ma(R*G*16),mb(R*G*16); std::vector<uint8_t> ea(R*K),eb(R*K);
  for(int i=0;i<R;++i)for(int g=0;g<G;++g){const uint8_t*a=&A[i*K+32*g],*b=&B[i*K+32*g];ra[i*G+g]=make_rec(a);rb[i*G+g]=make_rec(b);group_masks(a,&ma[(i*G+g)*16]);group_masks(b,&mb[(i*G+g)*16]);for(int u=0;u<32;++u){ea[i*K+32*g+u]=code_eb(a[u]);eb[i*K+32*g+u]=code_eb(b[u]);}}
  std::vector<int> path(size_t(R)*R*G); std::vector<char> realcorr(size_t(R)*R*G);
  for(int i=0;i<R;++i)for(int j=0;j<R;++j){float c=0;for(int g=0;g<G;++g){const uint8_t*a=&A[i*K+32*g],*b=&B[j*K+32*g];int64_t T=0;for(int u=0;u<32;++u)T+=int64_t(code_I(a[u]))*code_I(b[u]);
    int p;CellSrc s{A.data(),B.data(),ma.data(),mb.data(),ea.data(),eb.data(),i,j,g,K,G};
    uint32_t bits=emu_f2u(c);int thr=((bits>>23)&255)-127-5; int64_t corr=0;
    if(((bits>>23)&255) && rec_max(ra[i*G+g]) && rec_max(rb[j*G+g]) && cand_maybe(ra[i*G+g],rb[j*G+g],thr)) corr=cand_correction(a,b,ra[i*G+g],rb[j*G+g],&ma[(i*G+g)*16],&mb[(j*G+g)*16],thr);
    c=cell_step_src(c,T,ra[i*G+g],rb[j*G+g],s,&p);size_t k=(size_t(i)*R+j)*G+g;path[k]=p;realcorr[k]=corr!=0;}}
  long long cells=0,p1=0,p2=0,real=0, slots=0,anyslow=0,anyp2=0; long long byg_p2[8]={0};
  for(size_t k=0;k<path.size();++k){++cells;p1+=path[k]==1;p2+=path[k]==2;real+=path[k]==1&&realcorr[k];if(path[k]==2&&k%G<8)++byg_p2[k%G];}
  // warps: rows w*16.., cols c*16..; lane g,t: rows g,g+8 ; cols cb*8+2t, +1 ; slot = (cb, v)
  for(int wr=0;wr<R;wr+=16)for(int wc=0;wc<R;wc+=16)for(int g=0;g<G;++g)for(int cb=0;cb<2;++cb)for(int v=0;v<4;++v){
    bool s=false,s2=false; for(int gg=0;gg<8;++gg)for(int t=0;t<4;++t){int i=wr+gg+8*(v>>1),j=wc+cb*8+2*t+(v&1);int p=path[(size_t(i)*R+j)*G+g];s|=p!=0;s2|=p==2;}
    ++slots;anyslow+=s;anyp2+=s2;}
  printf("cell-groups: P1+scan %.2f%% (of them with real correction %.1f%%), P2 %.2f%%\n",100.0*p1/cells,100.0*real/std::max(1LL,p1),100.0*p2/cells);
  printf("P2 share of first 8 groups of the chain: "); for(int g=0;g<8;++g)printf("g%d %.0f%%  ",g,100.0*byg_p2[g]/(R*R)); printf("\n");
  printf("warp slots where >=1 of 32 lanes leaves the cheap path: %.1f%%  (takes P2: %.1f%%)\n",100.0*anyslow/slots,100.0*anyp2/slots);
}
