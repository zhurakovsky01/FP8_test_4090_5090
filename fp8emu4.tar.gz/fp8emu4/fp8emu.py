#!/usr/bin/env python3
"""Bit-exact B200 (Pearl Device = 1) FP8 emulation on RTX 40 (sm_89): is it correct, and how fast?

v4 (alex_kodiaq, with Claude): next to v1, the best v2 and the best v3 runs v4 in three tile sizes,
plus two diagnostics: v3 without B200 rounding (ceiling) and v4 with the cheap path only.

1. Correctness: every output value of every test suite is compared bit-for-bit with the B200 model
   (the same expected files as fp8check), for v1 and for each v2 tile size.
2. Speed on 2048 x 2048 x 4096 for three input kinds, next to the card's native INT8 and native FP8
   tensor-core rates. Stop the miner first. Needs only the NVIDIA driver and Python 3.6+; nothing is written.
"""
import ctypes
import hashlib
import io
import os
import struct
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data")
ATTR_CC_MAJOR, ATTR_CC_MINOR, ATTR_SMS = 75, 76, 16
V2 = (("v2/12", "emu2_12", 1, 2), ("v3/12", "emu3_12", 1, 2),
      ("v4/11", "emu4_11", 1, 1), ("v4/12", "emu4_12", 1, 2), ("v4/21", "emu4_21", 2, 1))   # (label, kernel, WM, WN)
CEIL = (("v3/12 no rounding", "emu3_12_noround", 1, 2), ("v4/12 cheap path only", "emu4_12_cheaponly", 1, 2))
# CEIL: diagnostics, NOT bit-exact: no B200 rounding at all / every cell on the cheap path
PAD = 64                     # rows of A and B are padded to a multiple of the largest CTA tile
SIZE = int(os.environ.get("FP8EMU_SIZE", "2048"))   # speed test: SIZE x SIZE outputs, K = 4096


class Cuda:
    def __init__(self, path="libcuda.so.1"):
        self.lib = ctypes.CDLL(path)
        vp, sz, i32, u32, P = ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int, ctypes.c_uint, ctypes.POINTER
        sig = {
            "cuInit": [u32], "cuDriverGetVersion": [P(i32)], "cuDeviceGetCount": [P(i32)],
            "cuDeviceGet": [P(i32), i32], "cuDeviceGetName": [ctypes.c_char_p, i32, i32],
            "cuDeviceGetAttribute": [P(i32), i32, i32], "cuDevicePrimaryCtxRetain": [P(vp), i32],
            "cuDevicePrimaryCtxRelease_v2": [i32], "cuCtxSetCurrent": [vp], "cuCtxSynchronize": [],
            "cuModuleLoadData": [P(vp), ctypes.c_char_p], "cuModuleUnload": [vp],
            "cuModuleGetFunction": [P(vp), vp, ctypes.c_char_p],
            "cuMemAlloc_v2": [P(ctypes.c_uint64), sz], "cuMemFree_v2": [ctypes.c_uint64],
            "cuMemcpyHtoD_v2": [ctypes.c_uint64, vp, sz], "cuMemcpyDtoH_v2": [vp, ctypes.c_uint64, sz],
            "cuMemsetD8_v2": [ctypes.c_uint64, ctypes.c_ubyte, sz],
            "cuLaunchKernel": [vp, u32, u32, u32, u32, u32, u32, u32, vp, P(vp), P(vp)],
            "cuEventCreate": [P(vp), u32], "cuEventRecord": [vp, vp], "cuEventSynchronize": [vp],
            "cuEventElapsedTime": [P(ctypes.c_float), vp, vp], "cuEventDestroy_v2": [vp],
            "cuGetErrorString": [i32, P(ctypes.c_char_p)],
        }
        for name, args in sig.items():
            fn = getattr(self.lib, name)
            fn.argtypes = args
            fn.restype = i32

    def __getattr__(self, name):
        fn = getattr(self.lib, name)

        def call(*args):
            res = fn(*args)
            if res != 0:
                msg = ctypes.c_char_p()
                self.lib.cuGetErrorString(res, ctypes.byref(msg))
                raise RuntimeError("%s failed: CUDA error %d (%s)" % (name, res, (msg.value or b"?").decode()))
        return call


def read(path):
    with open(path, "rb") as f:
        return f.read()


def u64(d):
    return ctypes.c_uint64(d.value)


class Gpu:
    def __init__(self, cu, mod):
        self.cu, self.fn = cu, {}
        for name in ("prep", "emu_b200", "bench_int8", "bench_fp8", "prep2") + tuple(v[1] for v in V2 + CEIL):
            f = ctypes.c_void_p()
            cu.cuModuleGetFunction(ctypes.byref(f), mod, name.encode())
            self.fn[name] = f

    def alloc(self, n, data=None):
        d = ctypes.c_uint64()
        self.cu.cuMemAlloc_v2(ctypes.byref(d), max(n, 4))
        if data is not None:
            self.cu.cuMemcpyHtoD_v2(d, data, n)
        return d

    def free(self, *ds):
        for d in ds:
            self.cu.cuMemFree_v2(d)

    def launch(self, name, grid, block, args):
        params = (ctypes.c_void_p * len(args))(*[ctypes.cast(ctypes.pointer(x), ctypes.c_void_p) for x in args])
        self.cu.cuLaunchKernel(self.fn[name], grid[0], grid[1], 1, block, 1, 1, 0, None, params, None)

    def prepare(self, codes, rows, K, blk):
        """Upload an operand; build v1 limbs/summaries/masks and v2 limbs/records/block limb counts/exponents."""
        G = K // 32
        o = {"codes": self.alloc(rows * K, codes),
             "limbs": self.alloc(3 * rows * K), "summ": self.alloc(rows * G), "masks": self.alloc(rows * G * 16 * 4),
             "limbs2": self.alloc(3 * rows * K), "rec": self.alloc(rows * G * 8), "blkL": self.alloc((rows // blk) * G),
             "masks2": self.alloc(rows * G * 16 * 4), "eb": self.alloc(rows * K)}
        n = rows * G
        self.launch("prep", ((n + 127) // 128, 1), 128,
                    [u64(o["codes"]), ctypes.c_int(rows), ctypes.c_int(K), u64(o["limbs"]), u64(o["summ"]), u64(o["masks"])])
        n2 = (rows // blk) * G
        self.launch("prep2", ((n2 + 127) // 128, 1), 128,
                    [u64(o["codes"]), ctypes.c_int(rows), ctypes.c_int(K), ctypes.c_int(blk), u64(o["limbs2"]),
                     u64(o["rec"]), u64(o["blkL"]), u64(o["masks2"]), u64(o["eb"])])
        self.cu.cuCtxSynchronize()
        return o

    def release(self, o):
        self.free(*o.values())

    def emu1(self, A, B, M, N, K, d_out):
        args = [u64(A["codes"]), u64(B["codes"]), u64(A["limbs"]), u64(B["limbs"]), u64(A["summ"]), u64(B["summ"]),
                u64(A["masks"]), u64(B["masks"]), u64(d_out), ctypes.c_int(M), ctypes.c_int(N), ctypes.c_int(K), ctypes.c_int(0)]
        self.launch("emu_b200", (N // 32, M // 32), 128, args)

    def emu2(self, variant, A, B, M, N, K, d_out):
        label, name, wm, wn = variant
        args = [u64(A["codes"]), u64(B["codes"]), u64(A["limbs2"]), u64(B["limbs2"]), u64(A["rec"]), u64(B["rec"]),
                u64(A["blkL"]), u64(B["blkL"]), u64(A["masks2"]), u64(B["masks2"]), u64(A["eb"]), u64(B["eb"]),
                u64(d_out), ctypes.c_int(M), ctypes.c_int(N), ctypes.c_int(K)]
        self.launch(name, (N // (16 * wn), M // (32 * wm)), 128, args)

    def timed(self, fn, repeats=3):
        e0, e1 = ctypes.c_void_p(), ctypes.c_void_p()
        self.cu.cuEventCreate(ctypes.byref(e0), 0)
        self.cu.cuEventCreate(ctypes.byref(e1), 0)
        fn()
        self.cu.cuCtxSynchronize()
        best = None
        for _ in range(repeats):
            self.cu.cuEventRecord(e0, None)
            fn()
            self.cu.cuEventRecord(e1, None)
            self.cu.cuEventSynchronize(e1)
            ms = ctypes.c_float()
            self.cu.cuEventElapsedTime(ctypes.byref(ms), e0, e1)
            best = ms.value if best is None else min(best, ms.value)
        self.cu.cuEventDestroy_v2(e0)
        self.cu.cuEventDestroy_v2(e1)
        return best


def pad_rows(codes, rows, K, to):
    """Zero-pad an operand to a multiple of `to` rows (zero rows give +0 outputs)."""
    padded = -(-rows // to) * to
    return codes + bytes((padded - rows) * K), padded


def tile_rows(codes, rows, K, to_rows):
    if to_rows <= rows:
        return codes[:to_rows * K]
    return codes * (to_rows // rows)


def main():
    if (sys.stdout.encoding or "").lower().replace("-", "") != "utf8":
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace", line_buffering=True)
    print("B200 (Device=1) bit-exact FP8 emulation on RTX 40, v1 + v2 + v3 + v4.  Python %s" % sys.version.split()[0])
    sums = os.path.join(HERE, "SHA256SUMS.txt")
    if os.path.exists(sums):
        bad = [l.split(None, 1)[1].lstrip("*") for l in read(sums).decode().splitlines()
               if hashlib.sha256(read(os.path.join(HERE, l.split(None, 1)[1].lstrip("*")))).hexdigest() != l.split()[0]]
        print("  files: " + ("SHA256 OK" if not bad else "CHANGED: %s" % ", ".join(bad)))
    cu = Cuda(os.environ.get("FP8EMU_LIBCUDA", "libcuda.so.1"))
    cu.cuInit(0)
    count = ctypes.c_int()
    cu.cuDeviceGetCount(ctypes.byref(count))
    suites = []
    for line in read(os.path.join(DATA, "manifest.txt")).decode().splitlines():
        if line and not line.startswith("#"):
            name, M, N, K, mv, nv, note = line.split(" ", 6)
            suites.append((name, int(M), int(N), int(K), int(mv), int(nv)))
    labels = ["v1"] + [v[0] for v in V2]
    for idx in range(count.value):
        dev = ctypes.c_int()
        cu.cuDeviceGet(ctypes.byref(dev), idx)
        nm = ctypes.create_string_buffer(256)
        cu.cuDeviceGetName(nm, 256, dev.value)
        a = ctypes.c_int()
        cu.cuDeviceGetAttribute(ctypes.byref(a), ATTR_CC_MAJOR, dev.value); major = a.value
        cu.cuDeviceGetAttribute(ctypes.byref(a), ATTR_CC_MINOR, dev.value); minor = a.value
        cu.cuDeviceGetAttribute(ctypes.byref(a), ATTR_SMS, dev.value); sms = a.value
        name = nm.value.decode(errors="replace")
        print("\n=== GPU %d: %s (sm_%d%d, %d SM) ===" % (idx, name, major, minor, sms))
        if (major, minor) != (8, 9):
            print("  skipped: this emulator is for RTX 40 (sm_89)")
            continue
        ctx = ctypes.c_void_p()
        cu.cuDevicePrimaryCtxRetain(ctypes.byref(ctx), dev.value)
        cu.cuCtxSetCurrent(ctx)
        mod = ctypes.c_void_p()
        cu.cuModuleLoadData(ctypes.byref(mod), read(os.path.join(HERE, "fp8emu_sm89.cubin")))
        gpu = Gpu(cu, mod)

        # ---- 1. correctness ----
        print("\n  1) bit-exactness against the B200 model (every value of every suite):")
        print("    %-30s %6s  %s" % ("", "values", "  ".join("%-8s" % l for l in labels)))
        ok = dict((l, True) for l in labels)
        for (sname, M0, N0, K, mv, nv) in suites:
            a_codes, M = pad_rows(read(os.path.join(DATA, sname + ".a"))[:mv * K], mv, K, PAD)
            b_codes, N = pad_rows(read(os.path.join(DATA, sname + ".b"))[:nv * K], nv, K, PAD)
            want = struct.unpack("<%dI" % (M0 * N0), read(os.path.join(DATA, sname + ".b200.f32")))
            A = gpu.prepare(a_codes, M, K, 16)
            B = gpu.prepare(b_codes, N, K, 8)
            out = gpu.alloc(M * N * 4)
            cells = []
            runs = [lambda: gpu.emu1(A, B, M, N, K, out)] + [(lambda v=v: gpu.emu2(v, A, B, M, N, K, out)) for v in V2]
            for label, run in zip(labels, runs):
                cu.cuMemsetD8_v2(out, 0xFF, M * N * 4)
                run()
                cu.cuCtxSynchronize()
                buf = ctypes.create_string_buffer(M * N * 4)
                cu.cuMemcpyDtoH_v2(buf, out, M * N * 4)
                got = struct.unpack("<%dI" % (M * N), buf.raw)
                wrong = mv * nv - sum(1 for i in range(mv) for j in range(nv) if got[i * N + j] == want[i * N0 + j])
                ok[label] &= wrong == 0
                cells.append("OK" if wrong == 0 else "%d wrong" % wrong)
            print("    %-30s %6d  %s" % (sname, mv * nv, "  ".join("%-8s" % c for c in cells)))
            gpu.free(out)
            gpu.release(A)
            gpu.release(B)
        good = [l for l in labels if ok[l]]
        print("    => " + ("всё бит в бит совпало с B200: эмуляция корректна (v1, v2, v3 и все варианты v4)" if len(good) == len(labels)
                         else "ЕСТЬ РАСХОЖДЕНИЯ у: %s — пришлите весь вывод; скорость этих вариантов не в счёт"
                         % ", ".join(l for l in labels if not ok[l])))

        # ---- 2. speed ----
        print("\n  2) speed, T MAC/s (1 MAC = 2 ops; the miner should be stopped), %d x %d x 4096:" % (SIZE, SIZE))
        out = gpu.alloc(4)
        cu.cuMemsetD8_v2(out, 0, 4)
        iters = 1 << 18
        blocks = sms * 8
        macs_bench = blocks * 4 * iters * 8 * 4096
        rate = {}
        for kname in ("bench_int8", "bench_fp8"):
            ms = gpu.timed(lambda: gpu.launch(kname, (blocks, 1), 128,
                                              [ctypes.c_uint32(iters), ctypes.c_uint32(0x01020304), ctypes.c_uint64(out.value)]))
            rate[kname] = macs_bench / (ms * 1e-3) / 1e12
        gpu.free(out)
        i8 = rate["bench_int8"]
        print("    %-40s %9s  %9s" % ("", "T MAC/s", "% of INT8"))
        print("    %-40s %9.1f  %8.1f%%" % ("native INT8 (today's mining math)", i8, 100.0))
        print("    %-40s %9.1f  %8.1f%%  <- fast, but wrong bits" % ("native FP8 (Ada arithmetic)", rate["bench_fp8"], 100 * rate["bench_fp8"] / i8))
        K = 4096
        summary = []
        for bname, rows in (("pearl_like_k4096", 256), ("gauss_sigma100_k4096", 128), ("uniform_codes_k4096", 64)):
            a_codes = tile_rows(read(os.path.join(DATA, "bench_" + bname + ".a"))[:rows * K], rows, K, SIZE)
            b_codes = tile_rows(read(os.path.join(DATA, "bench_" + bname + ".b"))[:rows * K], rows, K, SIZE)
            A = gpu.prepare(a_codes, SIZE, K, 16)
            B = gpu.prepare(b_codes, SIZE, K, 8)
            o = gpu.alloc(SIZE * SIZE * 4)
            short = bname.replace("_k4096", "")
            res = {}
            runs = [("v1", lambda: gpu.emu1(A, B, SIZE, SIZE, K, o))] + \
                   [(v[0], (lambda v=v: gpu.emu2(v, A, B, SIZE, SIZE, K, o))) for v in V2]
            for label, run in runs:
                ms = gpu.timed(run, repeats=3)
                r = SIZE * SIZE * K / (ms * 1e-3) / 1e12
                res[label] = r
                flag = "" if ok[label] else "  (не прошёл проверку, не в счёт)"
                print("    %-40s %9.2f  %8.2f%%%s" % ("B200 emu %-6s %s" % (label, short), r, 100 * r / i8, flag))
            if short == "pearl_like":
                for v in CEIL:
                    ms = gpu.timed(lambda v=v: gpu.emu2(v, A, B, SIZE, SIZE, K, o), repeats=3)
                    r = SIZE * SIZE * K / (ms * 1e-3) / 1e12
                    note = "потолок: без округления B200" if "no rounding" in v[0] else "только дешёвый путь"
                    print("    %-40s %9.2f  %8.2f%%  <- %s (не бит в бит)" % ("%s %s" % (v[0], short), r, 100 * r / i8, note))
            best = max((l for l in res if l.startswith("v4") and ok[l]), key=lambda l: res[l], default=None)
            if best:
                summary.append((short, best, res[best], res[best] / res["v1"], res[best] / res["v3/12"]))
            gpu.free(o)
            gpu.release(A)
            gpu.release(B)
        print("\n  ИТОГ v4 (лучший размер тайла, только прошедшие проверку):")
        for short, best, r, x, x2 in summary:
            print("    %-20s %-7s %6.2f T MAC/s = %5.2f%% of INT8, быстрее v1 в %.1f раза, v3/12 в %.1f раза"
                  % (short, best, r, 100 * r / i8, x, x2))
        print("    (inputs: pearl_like = PIP-3 input preparation as in Cyberminer; gauss/uniform = synthetic)")
        cu.cuModuleUnload(mod)
        cu.cuDevicePrimaryCtxRelease_v2(dev.value)
    return 0


if __name__ == "__main__":
    sys.exit(main())
