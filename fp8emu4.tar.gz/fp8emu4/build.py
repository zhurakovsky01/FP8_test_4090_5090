#!/usr/bin/env python3
"""Build fp8emu_sm89.cubin: NVRTC 12.8 (CUDA C++ -> PTX for compute_89), then ptxas -arch=sm_89 -O3 -v."""
import ctypes, glob, os, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "src")
NV = "/usr/local/lib/python3.13/dist-packages/nvidia"
out_cubin = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "fp8emu_sm89.cubin")
log_path = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "build_log.txt")

lib = ctypes.CDLL(glob.glob(NV + "/cuda_nvrtc/lib/libnvrtc.so.12")[0])
prog = ctypes.c_void_p()
src = open(os.path.join(SRC, "emu.cu"), "rb").read()
r = lib.nvrtcCreateProgram(ctypes.byref(prog), src, b"emu.cu", 0, None, None)
assert r == 0, r
opts = [b"--gpu-architecture=compute_89", b"-std=c++17", b"-default-device", b"--use_fast_math=false",
        ("-I" + SRC).encode(), ("-I" + os.path.join(HERE, "shim")).encode(), ("-I" + NV + "/cuda_runtime/include").encode(), ("-I" + NV + "/cuda_nvcc/include").encode()]
opts = [o for o in opts if o != b"--use_fast_math=false"]
arr = (ctypes.c_char_p * len(opts))(*opts)
r = lib.nvrtcCompileProgram(prog, len(opts), arr)
n = ctypes.c_size_t()
lib.nvrtcGetProgramLogSize(prog, ctypes.byref(n))
buf = ctypes.create_string_buffer(n.value)
lib.nvrtcGetProgramLog(prog, buf)
nvrtc_log = buf.value.decode(errors="replace")
if r != 0:
    print(nvrtc_log)
    sys.exit("NVRTC failed: %d" % r)
lib.nvrtcGetPTXSize(prog, ctypes.byref(n))
ptx = ctypes.create_string_buffer(n.value)
lib.nvrtcGetPTX(prog, ptx)
ptx_path = os.path.join(HERE, "emu_sm89.ptx")
open(ptx_path, "wb").write(ptx.value)
vr, vmin = ctypes.c_int(), ctypes.c_int()
lib.nvrtcVersion(ctypes.byref(vr), ctypes.byref(vmin))
p = subprocess.run([NV + "/cuda_nvcc/bin/ptxas", "-arch=sm_89", "-O3", "-v", ptx_path, "-o", out_cubin],
                   capture_output=True, text=True)
log = "NVRTC %d.%d -> PTX (compute_89); ptxas -arch=sm_89 -O3\n%s%s%s" % (vr.value, vmin.value, nvrtc_log, p.stdout, p.stderr)
open(log_path, "w").write(log)
print(log)
sys.exit(p.returncode)
