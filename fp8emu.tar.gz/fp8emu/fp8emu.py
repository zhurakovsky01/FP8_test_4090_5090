#!/usr/bin/env python3
"""Bit-exact B200 (Pearl Device = 1) FP8 emulation on RTX 40 (sm_89): is it correct, and how fast?

1. Correctness: runs the emulator on every test suite and compares each output value bit-for-bit
   with the B200 model (the same expected files as fp8check), in both modes:
     hybrid : INT8 tensor cores for exact sums + B200 rounding on CUDA cores (fast paths + exact
              fallback for groups where B200 truncates something it cannot predict cheaply)
     plain  : the exact per-term B200 algorithm on CUDA cores for every value
2. Speed: times both modes on 1024 x 1024 x 4096 (plain: 256 x 256 x 4096) for three input
   kinds, next to the card's native INT8 and native FP8 tensor-core rates.
   Stop the miner first. Needs only the NVIDIA driver and Python 3.6+; nothing is written.
"""
import ctypes
import hashlib
import io
import os
import struct
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data")
ATTR_CC_MAJOR, ATTR_CC_MINOR, ATTR_SMS = 75, 76, 16


class Cuda:
    def __init__(self, path="libcuda.so.1"):
        self.lib = ctypes.CDLL(path)
        vp, sz, i32, u32, P = ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int, ctypes.c_uint, ctypes.POINTER
        sig = {
            "cuInit": [u32], "cuDriverGetVersion": [P(i32)], "cuDeviceGetCount": [P(i32)],
            "cuDeviceGet": [P(i32), i32], "cuDeviceGetName": [ctypes.c_char_p, i32, i32],
            "cuDeviceGetAttribute": [P(i32), i32, i32], "cuDevicePrimaryCtxRetain": [P(vp), i32],
            "cuDevicePrimaryCtxRelease_v2": [i32], "cuCtxSetCurrent": [vp], "cuCtxSynchronize": [],
            "cuModuleLoadData": [P(vp), ctypes.c_char_p], "cuModuleUnload": [vp],
            "cuModuleGetFunction": [P(vp), vp, ctypes.c_char_p],
            "cuMemAlloc_v2": [P(ctypes.c_uint64), sz], "cuMemFree_v2": [ctypes.c_uint64],
            "cuMemcpyHtoD_v2": [ctypes.c_uint64, vp, sz], "cuMemcpyDtoH_v2": [vp, ctypes.c_uint64, sz],
            "cuMemsetD8_v2": [ctypes.c_uint64, ctypes.c_ubyte, sz],
            "cuLaunchKernel": [vp, u32, u32, u32, u32, u32, u32, u32, vp, P(vp), P(vp)],
            "cuEventCreate": [P(vp), u32], "cuEventRecord": [vp, vp], "cuEventSynchronize": [vp],
            "cuEventElapsedTime": [P(ctypes.c_float), vp, vp], "cuEventDestroy_v2": [vp],
            "cuGetErrorString": [i32, P(ctypes.c_char_p)],
        }
        for name, args in sig.items():
            fn = getattr(self.lib, name)
            fn.argtypes = args
            fn.restype = i32

    def __getattr__(self, name):
        fn = getattr(self.lib, name)

        def call(*args):
            res = fn(*args)
            if res != 0:
                msg = ctypes.c_char_p()
                self.lib.cuGetErrorString(res, ctypes.byref(msg))
                raise RuntimeError("%s failed: CUDA error %d (%s)" % (name, res, (msg.value or b"?").decode()))
        return call


def read(path):
    with open(path, "rb") as f:
        return f.read()


class Gpu:
    def __init__(self, cu, mod):
        self.cu, self.fn = cu, {}
        for name in ("prep", "emu_b200", "bench_int8", "bench_fp8"):
            f = ctypes.c_void_p()
            cu.cuModuleGetFunction(ctypes.byref(f), mod, name.encode())
            self.fn[name] = f

    def alloc(self, n, data=None):
        d = ctypes.c_uint64()
        self.cu.cuMemAlloc_v2(ctypes.byref(d), max(n, 4))
        if data is not None:
            self.cu.cuMemcpyHtoD_v2(d, data, n)
        return d

    def free(self, *ds):
        for d in ds:
            self.cu.cuMemFree_v2(d)

    def launch(self, name, grid, block, args):
        params = (ctypes.c_void_p * len(args))(*[ctypes.cast(ctypes.pointer(x), ctypes.c_void_p) for x in args])
        self.cu.cuLaunchKernel(self.fn[name], grid[0], grid[1], 1, block, 1, 1, 0, None, params, None)

    def prepare(self, codes, rows, K):
        """Upload an operand and build its limb planes, group summaries and masks."""
        G = K // 32
        d_codes = self.alloc(rows * K, codes)
        d_limbs = self.alloc(3 * rows * K)
        d_summ = self.alloc(rows * G)
        d_masks = self.alloc(rows * G * 16 * 4)
        n = rows * G
        self.launch("prep", ((n + 127) // 128, 1), 128,
                    [ctypes.c_uint64(d_codes.value), ctypes.c_int(rows), ctypes.c_int(K), ctypes.c_uint64(d_limbs.value),
                     ctypes.c_uint64(d_summ.value), ctypes.c_uint64(d_masks.value)])
        self.cu.cuCtxSynchronize()
        return (d_codes, d_limbs, d_summ, d_masks)

    def emu(self, A, B, M, N, K, mode, d_out):
        args = [ctypes.c_uint64(A[0].value), ctypes.c_uint64(B[0].value), ctypes.c_uint64(A[1].value), ctypes.c_uint64(B[1].value),
                ctypes.c_uint64(A[2].value), ctypes.c_uint64(B[2].value), ctypes.c_uint64(A[3].value), ctypes.c_uint64(B[3].value),
                ctypes.c_uint64(d_out.value), ctypes.c_int(M), ctypes.c_int(N), ctypes.c_int(K), ctypes.c_int(mode)]
        self.launch("emu_b200", (N // 32, M // 32), 128, args)

    def timed(self, fn, repeats=3):
        e0, e1 = ctypes.c_void_p(), ctypes.c_void_p()
        self.cu.cuEventCreate(ctypes.byref(e0), 0)
        self.cu.cuEventCreate(ctypes.byref(e1), 0)
        fn()
        self.cu.cuCtxSynchronize()
        best = None
        for _ in range(repeats):
            self.cu.cuEventRecord(e0, None)
            fn()
            self.cu.cuEventRecord(e1, None)
            self.cu.cuEventSynchronize(e1)
            ms = ctypes.c_float()
            self.cu.cuEventElapsedTime(ctypes.byref(ms), e0, e1)
            best = ms.value if best is None else min(best, ms.value)
        self.cu.cuEventDestroy_v2(e0)
        self.cu.cuEventDestroy_v2(e1)
        return best


def pad_rows(codes, rows, K, to):
    """Zero-pad an operand to a multiple of `to` rows (zero rows give +0 outputs)."""
    padded = -(-rows // to) * to
    return codes + bytes((padded - rows) * K), padded


def tile_rows(codes, rows, K, to_rows):
    reps = to_rows // rows
    return codes * reps


def main():
    if (sys.stdout.encoding or "").lower().replace("-", "") != "utf8":
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace", line_buffering=True)
    print("B200 (Device=1) bit-exact FP8 emulation on RTX 40.  Python %s" % sys.version.split()[0])
    sums = os.path.join(HERE, "SHA256SUMS.txt")
    if os.path.exists(sums):
        bad = [l.split(None, 1)[1].lstrip("*") for l in read(sums).decode().splitlines()
               if hashlib.sha256(read(os.path.join(HERE, l.split(None, 1)[1].lstrip("*")))).hexdigest() != l.split()[0]]
        print("  files: " + ("SHA256 OK" if not bad else "CHANGED: %s" % ", ".join(bad)))
    cu = Cuda(os.environ.get("FP8EMU_LIBCUDA", "libcuda.so.1"))
    cu.cuInit(0)
    count = ctypes.c_int()
    cu.cuDeviceGetCount(ctypes.byref(count))
    suites = []
    for line in read(os.path.join(DATA, "manifest.txt")).decode().splitlines():
        if line and not line.startswith("#"):
            name, M, N, K, mv, nv, note = line.split(" ", 6)
            suites.append((name, int(M), int(N), int(K), int(mv), int(nv)))
    for idx in range(count.value):
        dev = ctypes.c_int()
        cu.cuDeviceGet(ctypes.byref(dev), idx)
        nm = ctypes.create_string_buffer(256)
        cu.cuDeviceGetName(nm, 256, dev.value)
        a = ctypes.c_int()
        cu.cuDeviceGetAttribute(ctypes.byref(a), ATTR_CC_MAJOR, dev.value); major = a.value
        cu.cuDeviceGetAttribute(ctypes.byref(a), ATTR_CC_MINOR, dev.value); minor = a.value
        cu.cuDeviceGetAttribute(ctypes.byref(a), ATTR_SMS, dev.value); sms = a.value
        name = nm.value.decode(errors="replace")
        print("\n=== GPU %d: %s (sm_%d%d, %d SM) ===" % (idx, name, major, minor, sms))
        if (major, minor) != (8, 9):
            print("  skipped: this emulator is for RTX 40 (sm_89)")
            continue
        ctx = ctypes.c_void_p()
        cu.cuDevicePrimaryCtxRetain(ctypes.byref(ctx), dev.value)
        cu.cuCtxSetCurrent(ctx)
        mod = ctypes.c_void_p()
        cu.cuModuleLoadData(ctypes.byref(mod), read(os.path.join(HERE, "fp8emu_sm89.cubin")))
        gpu = Gpu(cu, mod)

        # ---- 1. correctness ----
        print("\n  1) bit-exactness against the B200 model (every value of every suite):")
        all_ok = True
        for (sname, M0, N0, K, mv, nv) in suites:
            a_codes = read(os.path.join(DATA, sname + ".a"))[:mv * K]
            b_codes = read(os.path.join(DATA, sname + ".b"))[:nv * K]
            a_codes, M = pad_rows(a_codes, mv, K, 32)
            b_codes, N = pad_rows(b_codes, nv, K, 32)
            want = struct.unpack("<%dI" % (M0 * N0), read(os.path.join(DATA, sname + ".b200.f32")))
            A = gpu.prepare(a_codes, M, K)
            B = gpu.prepare(b_codes, N, K)
            out = gpu.alloc(M * N * 4)
            res = []
            for mode in (0, 1):
                cu.cuMemsetD8_v2(out, 0xFF, M * N * 4)
                gpu.emu(A, B, M, N, K, mode, out)
                cu.cuCtxSynchronize()
                buf = ctypes.create_string_buffer(M * N * 4)
                cu.cuMemcpyDtoH_v2(buf, out, M * N * 4)
                got = struct.unpack("<%dI" % (M * N), buf.raw)
                eq = sum(1 for i in range(mv) for j in range(nv) if got[i * N + j] == want[i * N0 + j])
                res.append(eq)
                all_ok &= eq == mv * nv
            print("    %-30s %6d values  hybrid %s  plain %s" % (sname, mv * nv,
                  "OK" if res[0] == mv * nv else "%d wrong" % (mv * nv - res[0]),
                  "OK" if res[1] == mv * nv else "%d wrong" % (mv * nv - res[1])))
            gpu.free(out, *A)
            gpu.free(*B)
        print("    => " + ("всё бит в бит совпало с B200: эмуляция корректна" if all_ok
                         else "ЕСТЬ РАСХОЖДЕНИЯ: пришлите весь вывод, замер скорости ниже не показателен"))

        # ---- 2. speed ----
        print("\n  2) speed, T MAC/s (1 MAC = 2 ops; the miner should be stopped):")
        out = gpu.alloc(4)
        cu.cuMemsetD8_v2(out, 0, 4)
        iters = 1 << 18
        blocks = sms * 8
        macs_bench = blocks * 4 * iters * 8 * 4096
        rate = {}
        for kname in ("bench_int8", "bench_fp8"):
            ms = gpu.timed(lambda: gpu.launch(kname, (blocks, 1), 128,
                                              [ctypes.c_uint32(iters), ctypes.c_uint32(0x01020304), ctypes.c_uint64(out.value)]))
            rate[kname] = macs_bench / (ms * 1e-3) / 1e12
        gpu.free(out)
        i8 = rate["bench_int8"]
        print("    %-46s %9s  %s" % ("", "T MAC/s", "% of INT8"))
        print("    %-46s %9.1f  %6.1f%%" % ("native INT8 (today's mining math)", i8, 100.0))
        print("    %-46s %9.1f  %6.1f%%  <- fast, but wrong bits" % ("native FP8 (Ada arithmetic)", rate["bench_fp8"], 100 * rate["bench_fp8"] / i8))
        for bname, rows in (("pearl_like_k4096", 256), ("gauss_sigma100_k4096", 128), ("uniform_codes_k4096", 64)):
            K = 4096
            a_codes = read(os.path.join(DATA, "bench_" + bname + ".a"))[:rows * K]
            b_codes = read(os.path.join(DATA, "bench_" + bname + ".b"))[:rows * K]
            for mode, size in ((0, 1024), (1, 256)):
                Ad = gpu.prepare(tile_rows(a_codes, rows, K, size) if size >= rows else a_codes[:size * K], size, K)
                Bd = gpu.prepare(tile_rows(b_codes, rows, K, size) if size >= rows else b_codes[:size * K], size, K)
                o = gpu.alloc(size * size * 4)
                ms = gpu.timed(lambda: gpu.emu(Ad, Bd, size, size, K, mode, o), repeats=3 if mode == 0 else 1)
                r = size * size * K / (ms * 1e-3) / 1e12
                label = "B200 emu %s, %s" % ("hybrid" if mode == 0 else "plain ", bname.replace("_k4096", ""))
                print("    %-46s %9.2f  %6.2f%%" % (label, r, 100 * r / i8))
                gpu.free(o, *Ad)
                gpu.free(*Bd)
        print("    (inputs: pearl_like = PIP-3 input preparation as in Cyberminer; gauss/uniform = synthetic)")
        cu.cuModuleUnload(mod)
        cu.cuDevicePrimaryCtxRelease_v2(dev.value)
    return 0


if __name__ == "__main__":
    sys.exit(main())
