// Bit-exact B200 (Pearl Device = 1) FP8 matmul emulator for RTX 40 (sm_89), plus reference
// tensor-core throughput kernels. Build: nvcc -cubin -arch=sm_89 -O3 emu.cu -o fp8emu_sm89.cubin
//
// emu_b200: C[i][j] = B200 chain over k of A row i and B row j (both e4m3, k-contiguous).
//   1) INT8 tensor cores compute the exact integer dot product of every 32-group
//      (3 x 3 signed 6-bit limbs per value, 9 IMMA per 16x8 tile, accumulated in 5 buckets).
//   2) CUDA cores apply B200's per-group rounding: fast path 2 (carry is the anchor, subtract
//      the remainders of small products), fast path 1 (nothing can be truncated), otherwise the
//      exact per-term algorithm. Slow cells are queued per warp and processed lane-parallel.
//   mode = 1 forces the exact per-term algorithm for every cell (a plain CUDA-core emulator).
#include "emu_math.cuh"

extern "C" __global__ void prep(const uint8_t* __restrict__ codes, int rows, int K,
                                int8_t* __restrict__ limbs, uint8_t* __restrict__ summ, uint32_t* __restrict__ masks) {
    int G = K / 32;
    long long idx = (long long)blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= (long long)rows * G) return;
    int row = (int)(idx / G), grp = (int)(idx % G);
    const uint8_t* c = codes + (size_t)row * K + 32 * grp;
    uint8_t loc[32];
    for (int u = 0; u < 32; ++u) loc[u] = c[u];
    size_t plane = (size_t)rows * K;
    for (int l = 0; l < 3; ++l)
        for (int u = 0; u < 32; ++u) limbs[l * plane + (size_t)row * K + 32 * grp + u] = code_limb(loc[u], l);
    summ[idx] = group_summary(loc);
    uint32_t m[16];
    group_masks(loc, m);
    for (int t = 0; t < 16; ++t) masks[idx * 16 + t] = m[t];
}

__device__ __forceinline__ void imma(int (&d)[4], const uint32_t (&a)[4], uint32_t b0, uint32_t b1) {
    asm volatile("mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
                 : "+r"(d[0]), "+r"(d[1]), "+r"(d[2]), "+r"(d[3])
                 : "r"(a[0]), "r"(a[1]), "r"(a[2]), "r"(a[3]), "r"(b0), "r"(b1));
}

__device__ __forceinline__ uint32_t ld32(const void* p) { return __ldg(reinterpret_cast<const unsigned int*>(p)); }

// CTA: 4 warps, 32 x 32 output tile; warp (wm, wn) owns rows 16*wm.., columns 16*wn.. (two 16x8 mma tiles).
extern "C" __global__ void __launch_bounds__(128) emu_b200(
        const uint8_t* __restrict__ A, const uint8_t* __restrict__ B,
        const int8_t* __restrict__ AL, const int8_t* __restrict__ BL,
        const uint8_t* __restrict__ SA, const uint8_t* __restrict__ SB,
        const uint32_t* __restrict__ MA, const uint32_t* __restrict__ MB,
        float* __restrict__ C, int M, int N, int K, int mode) {
    __shared__ float qcarry[4][256];
    __shared__ unsigned short qitem[4][256];
    const int lane = threadIdx.x & 31, warp = threadIdx.x >> 5;
    const int g = lane >> 2, t = lane & 3;
    const int row0 = blockIdx.y * 32 + (warp >> 1) * 16;
    const int col0 = blockIdx.x * 32 + (warp & 1) * 16;
    const int G = K / 32;
    const size_t planeA = (size_t)M * K, planeB = (size_t)N * K;
    // the 8 cells of this lane: slot = nt*4 + v ; v: 0 (g, 2t) 1 (g, 2t+1) 2 (g+8, 2t) 3 (g+8, 2t+1)
    int crow[8], ccol[8];
    for (int nt = 0; nt < 2; ++nt)
        for (int v = 0; v < 4; ++v) {
            crow[nt * 4 + v] = row0 + g + (v >> 1) * 8;
            ccol[nt * 4 + v] = col0 + nt * 8 + 2 * t + (v & 1);
        }
    float carry[8];
    for (int s = 0; s < 8; ++s) carry[s] = 0.0f;

    for (int grp = 0; grp < G; ++grp) {
        const int k0 = grp * 32;
        uint32_t a[3][4];
        for (int l = 0; l < 3; ++l) {
            const int8_t* p0 = AL + l * planeA + (size_t)(row0 + g) * K + k0 + t * 4;
            const int8_t* p1 = p0 + (size_t)8 * K;
            a[l][0] = ld32(p0); a[l][1] = ld32(p1); a[l][2] = ld32(p0 + 16); a[l][3] = ld32(p1 + 16);
        }
        int s[2][5][4];
        for (int nt = 0; nt < 2; ++nt) {
            uint32_t b[3][2];
            for (int l = 0; l < 3; ++l) {
                const int8_t* q = BL + l * planeB + (size_t)(col0 + nt * 8 + g) * K + k0 + t * 4;
                b[l][0] = ld32(q); b[l][1] = ld32(q + 16);
            }
            for (int x = 0; x < 5; ++x) for (int v = 0; v < 4; ++v) s[nt][x][v] = 0;
            for (int i = 0; i < 3; ++i)
                for (int j = 0; j < 3; ++j) imma(s[nt][i + j], a[i], b[j][0], b[j][1]);
        }
        unsigned slow = 0;
#pragma unroll
        for (int slot = 0; slot < 8; ++slot) {
            const int nt = slot >> 2, v = slot & 3;
            const int r = crow[slot], c = ccol[slot];
            const float cy = carry[slot];
            if (mode == 1) { slow |= 1u << slot; continue; }
            const uint8_t sa = __ldg(SA + (size_t)r * G + grp), sb = __ldg(SB + (size_t)c * G + grp);
            const int64_t T = combine_buckets(s[nt][0][v], s[nt][1][v], s[nt][2][v], s[nt][3][v], s[nt][4][v]);
            int ec, nc = 0;
            if (carry_anchored(sa, sb, cy, &ec)) {
                int64_t corr = 0;
                if (sa && sb && ec > 7 && (sa & 15) + (sb & 15) < ec - 5)
                    corr = truncation_correction(A + (size_t)r * K + k0, B + (size_t)c * K + k0, sa, sb,
                                                 MA + ((size_t)r * G + grp) * 16, MB + ((size_t)c * G + grp) * 16, ec, &nc);
                carry[slot] = fast_result(T - corr, cy);
            } else if (fast_ok(sa, sb, cy)) {
                carry[slot] = fast_result(T, cy);
            } else {
                slow |= 1u << slot;
            }
        }
        // ---- queue the slow cells of the whole warp and process them lane-parallel ----
        int cnt = __popc(slow), off = cnt;
        for (int d = 1; d < 32; d <<= 1) { int x = __shfl_up_sync(0xffffffffu, off, d); if (lane >= d) off += x; }
        int total = __shfl_sync(0xffffffffu, off, 31);
        off -= cnt;
        if (total) {
            int w = off;
#pragma unroll
            for (int slot = 0; slot < 8; ++slot)
                if (slow & (1u << slot)) { qitem[warp][w] = (unsigned short)((lane << 3) | slot); qcarry[warp][w] = carry[slot]; ++w; }
            __syncwarp();
            for (int idx = lane; idx < total; idx += 32) {
                const int it = qitem[warp][idx], src = it >> 3, slot = it & 7;
                const int sg = src >> 2, st = src & 3, nt = slot >> 2, v = slot & 3;
                const int r = row0 + sg + (v >> 1) * 8, c = col0 + nt * 8 + 2 * st + (v & 1);
                uint32_t aw[8], bw[8];
                const uint8_t* pa = A + (size_t)r * K + k0;
                const uint8_t* pb = B + (size_t)c * K + k0;
                for (int x = 0; x < 8; ++x) { aw[x] = ld32(pa + 4 * x); bw[x] = ld32(pb + 4 * x); }
                qcarry[warp][idx] = b200_group_exact(qcarry[warp][idx], reinterpret_cast<const uint8_t*>(aw),
                                                     reinterpret_cast<const uint8_t*>(bw));
            }
            __syncwarp();
            w = off;
#pragma unroll
            for (int slot = 0; slot < 8; ++slot)
                if (slow & (1u << slot)) carry[slot] = qcarry[warp][w++];
            __syncwarp();
        }
    }
    for (int slot = 0; slot < 8; ++slot) {
        float out = (emu_f2u(carry[slot]) & 0x7FFFFFFF) ? carry[slot] : 0.0f;   // final re-sum: -0 -> +0
        C[(size_t)crow[slot] * N + ccol[slot]] = out;
    }
}

// ---- reference throughput: native INT8 and native (non-bit-exact) FP8 tensor cores ----
extern "C" __global__ void __launch_bounds__(128) bench_int8(unsigned iters, unsigned seed, unsigned* out) {
    uint32_t a = (seed & 0x07070707u) | 0x30303030u;
    int acc[8][4];
    for (int s = 0; s < 8; ++s) for (int v = 0; v < 4; ++v) acc[s][v] = 0;
    for (unsigned it = 0; it < iters; ++it) {
#pragma unroll
        for (int s = 0; s < 8; ++s)
            asm volatile("mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32 {%0,%1,%2,%3}, {%4,%4,%4,%4}, {%4,%4}, {%0,%1,%2,%3};"
                         : "+r"(acc[s][0]), "+r"(acc[s][1]), "+r"(acc[s][2]), "+r"(acc[s][3]) : "r"(a));
    }
    int x = 0;
    for (int s = 0; s < 8; ++s) for (int v = 0; v < 4; ++v) x ^= acc[s][v];
    atomicXor(out, (unsigned)x);
}
extern "C" __global__ void __launch_bounds__(128) bench_fp8(unsigned iters, unsigned seed, unsigned* out) {
    uint32_t a = (seed & 0x07070707u) | 0x30303030u;
    float acc[8][4];
    for (int s = 0; s < 8; ++s) for (int v = 0; v < 4; ++v) acc[s][v] = 0.0f;
    for (unsigned it = 0; it < iters; ++it) {
#pragma unroll
        for (int s = 0; s < 8; ++s)
            asm volatile("mma.sync.aligned.m16n8k32.row.col.f32.e4m3.e4m3.f32 {%0,%1,%2,%3}, {%4,%4,%4,%4}, {%4,%4}, {%0,%1,%2,%3};"
                         : "+f"(acc[s][0]), "+f"(acc[s][1]), "+f"(acc[s][2]), "+f"(acc[s][3]) : "r"(a));
    }
    unsigned x = 0;
    for (int s = 0; s < 8; ++s) for (int v = 0; v < 4; ++v) x ^= __float_as_uint(acc[s][v]);
    atomicXor(out, x);
}
